#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * Converts millimeters to inches
   * @param [in] value value in millimeters
   * @return value in inches
   */
  VPD_SDK_API double __stdcall mm2inch(double value);

  /**
   * Convertes inches to millimeters
   * @param [in] value value in inches
   * @return value in millimeters
   */
  VPD_SDK_API double __stdcall inch2mm(double value);

  /**
   * Generates UUID
   * @return UUID
   */
  VPD_SDK_API std::wstring __stdcall generateUUID(void);

  /**
   * Releases VPD SDK dll objects
   */
  VPD_SDK_API void __stdcall release(void *ptr);

  /*! @} */
} // namespace vpd
