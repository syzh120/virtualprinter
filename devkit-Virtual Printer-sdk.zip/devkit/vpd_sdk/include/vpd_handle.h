#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * @brief Helpfull class for HANDLE objects
   */
  class VPD_SDK_API Handle{
  public:
    Handle(void);
    explicit Handle(HANDLE handle);
    Handle(HANDLE handle, BOOL (WINAPI *cleanFunc)(HANDLE));
    ~Handle(void);

    operator HANDLE(void) const;
    operator bool(void) const;
    HANDLE *operator&(void);
    void reset(HANDLE handle); /**< reset object to another HANDLE value */
    void reset(HANDLE handle, BOOL (WINAPI *cleanFunc)(HANDLE)); /**< reset object to another HANDLE value*/

    /**
     * Releases the object
     * @return Handle to the handled object
     */
    HANDLE release(void);

  private:
    Handle(Handle const &);
    Handle &operator=(Handle const &);

  private:
    HANDLE mHandle;
    BOOL (WINAPI *mCleanFunc)(HANDLE);
  };

  template <typename T, typename Deleter>
  class GenericHandle{
  public:
    GenericHandle(void) : mHandle(NULL), mDeleter() {}
    explicit GenericHandle(T handle) : mHandle(handle), mDeleter() {}

    ~GenericHandle(void) throw(){
      if (mHandle)
        mDeleter(mHandle);
    }

    operator T(void) const {return mHandle;}

    operator bool(void) const {return mHandle != NULL;}

    T *operator&(void) {return &mHandle;}

    void reset(T handle){ /**< reset object to another handle value */
      if (mHandle)
        mDeleter(mHandle);

      mHandle = handle;
    }

    /**
     * Releases the object
     * @return Handle to the handled object
     */
    T release(void){
      T tmp = mHandle;
      mHandle = NULL;
      return tmp;
    }

  private:
    GenericHandle(Handle const &);
    GenericHandle &operator=(Handle const &);

  private:
    T mHandle;
    Deleter mDeleter;
  };

  /*! @} */
}
