#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * Starts the specified service
   * @param serviceName service name
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall startService(std::wstring const &serviceName);

  /**
   * Stops the specified service
   * @param serviceName service name
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall stopService(std::wstring const &serviceName);

  /**
   Gets service current state.
   @param serviceName name of a service
   @param state service state, can be one of the following values
   *
   *           SERVICE_CONTINUE_PENDING (0x00000005) - The service continue is pending.
   *           SERVICE_PAUSE_PENDING (0x00000006) - The service pause is pending.
   *           SERVICE_PAUSED (0x00000007) - The service is paused.
   *           SERVICE_RUNNING (0x00000004) - The service is running.
   *           SERVICE_START_PENDING (0x00000002) - The service is starting.
   *           SERVICE_STOP_PENDING (0x00000003) - The service is stopping.
   *           SERVICE_STOPPED (0x00000001) - The service is not running.
   *
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getServiceCurrentState(std::wstring const &serviceName, unsigned long &state);

  /**
   * @brief Device info
   */
  struct ServiceInfo{
    static std::size_t const nameSize = 256; /**< max length for service name */
    WCHAR mName[nameSize];                   /**< service name */
  };

  /**
   * Enumerates name of services that depends on the specified service
   * @param [in] serviceName service name
   * @param [out] dependentServices dependent service names
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumDependentServices(std::wstring const &serviceName, ServiceInfo *&dependentServices, std::size_t &count);

  /*! @} */
} // namespace vpd
