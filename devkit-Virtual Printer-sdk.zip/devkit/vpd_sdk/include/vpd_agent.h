#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Agent
   * @brief Agent settings
   * @{
   */

  /**
   * @brief General Agent settings
   */
  struct AgentSettings{
    unsigned long mAllowGuestSession; /**< allow guest session on target machine */
    unsigned long mAllowDomainSession;/**< allow domain session on target machine */
    unsigned long mAllowSelfSession;  /**< allow self session on target machine */
    unsigned long mPoolSize;          /**< thread pool size for simultaneous printing processes */
  };

  /**
   * Gets Agent settings from the registry
   * @param [out] settings set of Agent settings
   * @param [in] registryKey registry entry
   * @return  If the function succeeds, the return value is non-zero.
   * @return  If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getAgentSettings(AgentSettings &settings, std::wstring const &registryKey);

  /**
   * Sets Agent settings
   * @param [in] settings set of Agent settings
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setAgentSettings(AgentSettings const &settings, std::wstring const &registryKey);

  /**
   * Removes Agent settings from the registry
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeAgentSettings(std::wstring const &registryKey);

  /*! @} */
}
