#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * @brief Helpfull class for critical section objects
   */
  class VPD_SDK_API CriticalSection{
  public:
    CriticalSection(void) throw();
    ~CriticalSection(void) throw();

    void lock(void); /**< lock a critical section */
    void unlock(void); /**< unlock a critical section */

  private:
    // deny
    CriticalSection(CriticalSection const &) throw();
    CriticalSection &operator=(CriticalSection const &) throw();

  private:
    CRITICAL_SECTION mCS;
  };// class CriticalSection

  /**
   * @brief Helpfull class for auto-unlocking CriticalSection objects
   */
  class VPD_SDK_API AutoReleaseCS{
  public:
    AutoReleaseCS(CriticalSection *cs) throw();
    ~AutoReleaseCS(void) throw();

    void release(void) throw(); /**< release an object manually */

  private:
    // deny
    AutoReleaseCS(AutoReleaseCS const &) throw();
    AutoReleaseCS &operator=(AutoReleaseCS const &) throw();

  private:
    CriticalSection *mCS;
  };// class AutoReleaseCS

  /*! @} */
}
