#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Device
   * @brief Paper orientation, paper size, paper bin and print resolution settings
   * @{
   */

  /**
   * @brief Paper orientation
   */
  enum PaperOrientation{
    PaperOrientationPortrait,       /**< Portrait paper orientation */
    PaperOrientationLandscape       /**< Landscape paper orientation */
  };

  /**
   * Gets a paper orientation for the specified printer
   * @param [in] pname printer name
   * @param [out] orientation paper orientation
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPaperOrientation(std::wstring const &pname, PaperOrientation &orientation);

  /**
   * Sets a paper orientation for the specified printer
   * @param [in] pname printer name
   * @param [in]  orientation paper orientation, the value must be one of the following values:
   *
   *                 PaperOrientationPortrait - portrait orientation;
   *                 PaperOrientationLandscape - landscape orientation.
   *
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setPaperOrientation(std::wstring const &pname, PaperOrientation orientation);

  /**
   * @brief Print resolution
   */
  struct VPD_SDK_API PrintResolution{
    LONG mDpiX;   /**< Resolution for DPI X */
    LONG mDpiY;   /**< Resolution for DPI Y */

    PrintResolution(void)
      : mDpiX(0),
      mDpiY(0){
    }

    PrintResolution(LONG dpiX, LONG dpiY)
      : mDpiX(dpiX),
      mDpiY(dpiY){
    }

    bool operator==(PrintResolution const &rhs) const {
      return (mDpiX == rhs.mDpiX)
              && (mDpiY == rhs.mDpiY);
    }
  };

  /**
   * Gets all available resolutions for the specified printer
   * @param [in] pname printer name
   * @param [out] resolutions set of available print resolutions. To free memory call vpd::release()
   * @param count count of elements
   * @return If the function succeeds, the return value is non-zero
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumPrintResolutions(std::wstring const &pname, PrintResolution *&resolutions, std::size_t &count);

  /**
   * Gets a current print resolution for the specified printer
   * @param [in] pname printer name
   * @param [out] resolution print resolution
   * @return If the function succeeds, the return value is non-zero
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPrintResolution(std::wstring const &pname, PrintResolution &resolution);

  /**
   * Sets a print resolution for the specified printer
   * @param [in] pname printer name
   * @param [in] resolution print resolution
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   * @remark Unsupported resolution does not rise an error.
   */
  VPD_SDK_API int __stdcall setPrintResolution(std::wstring const &pname, PrintResolution const &resolution);

  /**
   * @brief Paper size measure
   */
  enum PaperSizeMeasure{
    PaperSizeMeasureMetrics = 0x1, /**< Paper size measured in millimeters */
    PaperSizeMeasureEnglish        /**< Paper size measured in inches */
  };

  /**
   * @brief Paper size precision
   */
  enum PaperSizePrecision{
    PaperSizePrecisionNormal = 0x1, /**< Paper size precision in millimeters or inches */
    PaperSizePrecisionThousandths   /**< Paper size precision in thousandths of millimeters or inches */
  };

  /**
   * @brief Paper form
   */
  struct VPD_SDK_API PaperForm{
    double mWidth;                               /**< paper form width */
    double mHeight;                              /**< paper form height */
    PaperSizeMeasure mMeasure;                   /**< measure */
    PaperSizePrecision mPrecision;               /**< precision */
    WORD mId;                                    /**< form ID */

    static std::size_t const paperFormSize = 33; /**< max length for paper form name*/
    WCHAR mName[paperFormSize];                  /**< paper form name */

    PaperForm(void)
      : mWidth(0.f),
      mHeight(0.f),
      mMeasure(PaperSizeMeasureMetrics),
      mPrecision(PaperSizePrecisionThousandths){
    }

    PaperForm(std::wstring const &name, double width, double height, PaperSizeMeasure measure, PaperSizePrecision precision)
      : mWidth(width),
      mHeight(height),
      mMeasure(measure),
      mPrecision(precision){

      wcsncpy_s(mName, name.c_str(), paperFormSize - 1);
    }

    PaperForm &operator=(PaperForm const &rhs){
      if (this != &rhs){
        memcpy(mName, rhs.mName, PaperForm::paperFormSize * sizeof(WCHAR));
        mWidth = rhs.mWidth;
        mHeight = rhs.mHeight;
        mMeasure = rhs.mMeasure;
        mPrecision = rhs.mPrecision;
      }
      return *this;
    }

    bool operator==(PaperForm const &rhs) const{
      return (wcsncmp(mName, rhs.mName, PaperForm::paperFormSize - 1) == 0)
              && (mWidth == rhs.mWidth)
              && (mHeight == rhs.mHeight)
              && (mMeasure == rhs.mMeasure)
              && (mPrecision == rhs.mPrecision);
    }
  };

  /**
   * Gets all available paper forms for the specified printer
   * @param [in] pname printer name
   * @param [out] forms set of available paper forms. To free memory call vpd::release()
   * @param [out] count count of elements
   * @param [in] measure measure of a paper size
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumPaperForms(std::wstring const &pname, PaperForm *&forms, std::size_t &count, PaperSizeMeasure measure = PaperSizeMeasureMetrics, PaperSizePrecision precision = PaperSizePrecisionNormal);

  /**
   * Gets a selected paper form for the specified printer
   * @param [in] pname printer name
   * @param [out] paperForm paper form
   * @param [in] measure measure of a paper size
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPaperForm(std::wstring const &pname, PaperForm &paperForm, PaperSizeMeasure measure = PaperSizeMeasureMetrics, PaperSizePrecision precision = PaperSizePrecisionNormal);

  /**
   * Sets a paper form for the specified printer
   * @param [in] pname printer name
   * @param [in] paperForm paper form
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setPaperForm(std::wstring const &pname, PaperForm const &paperForm);

  /**
   * Adds a new paper form for the specified printer
   * @param [in] pname printer name
   * @param [in] paperForm paper form in millimeters or inches
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zeron and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall addPaperForm(std::wstring const &pname, PaperForm const &paperForm);

  /**
   * Removes a paper form from the specified printer
   * @param [in] pname printer name
   * @param [in] paperForm paper form
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removePaperForm(std::wstring const &pname, PaperForm const &paperForm);

  /**
   * @brief Paper bin
   */
  struct PaperBin{
    static std::size_t const paperBinSize = 25; /**< max length for paper bin name */
    WCHAR mBinName[paperBinSize];               /**< paper bin name */
    WORD mBin;                                  /**< paper bin ID */
  };

  /**
   * Gets all available paper bins for the specified printer
   * @param [in] pname printer name
   * @param [out] paperBins set of available paper bins. To free memory call vpd::release()
   * @param [out] count count of elements
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumPaperBins(std::wstring const &pname, PaperBin *&paperBins, std::size_t &count);

  /**
   * Gets a paper bin for the specified printer
   * @param [in] pname printer name
   * @param [in] paperBin paper bin ID
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPaperBin(std::wstring const &pname, WORD &paperBin);

  /**
   * Sets a paper bin for the specified printer
   * @param [in] pname printer name
   * @param [in] paperBin paper bin ID
   * @return If the function succeeds, the result value is non-zero
   * @return If the function fails, the result value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setPaperBin(std::wstring const &pname, WORD paperBin);

  /**
    * Gets all supported paper forms info for specified printer
    * @param [in] pname printer name
    * @param [out] info set of supported FORM_INFO_1. To free memory call vpd::release()
    * @param [out] count count of elements
    * @return If the function succeeds, the result value is non-zero
    * @return If the function fails, the result value is zero and GetLastError() will return the error code.
    */
  VPD_SDK_API int __stdcall enumFormInfo(std::wstring const &pname, FORM_INFO_1 *&info, std::size_t &count);

  /*! @} */
} // namespace vpd
