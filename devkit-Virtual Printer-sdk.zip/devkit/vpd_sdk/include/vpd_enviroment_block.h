#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * @brief Helpfull class for enviroment block data
   */
  class VPD_SDK_API EnvironmentBlock{
  public:
    EnvironmentBlock(void);
    explicit EnvironmentBlock(void *envBlock);

    ~EnvironmentBlock(void);

    operator bool(void) const;
    operator void *(void) const;
    void **operator&(void);

    /**
     * Gets a value for the specified variable name
     * @param [in] name environment variable name
     * @param [out] value environment variable value
     * @return If the function succeeds, the return value is true
     * @return If the function fails, the return value is false
     */
    bool get_variable(std::wstring const &name, std::wstring &value) const;

  private:
    EnvironmentBlock(EnvironmentBlock const &);
    EnvironmentBlock &operator=(EnvironmentBlock const &);

  private:
    void *mEnvBlock;
  };

  /*! @} */
}
