#pragma once

#include <vpd.h>
#include <vpd_tools.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @brief Helpfull classes and functions
   * @{
   */

  /**
   * @brief Helpfull class for releasing VPD SDK dll objects
   */
  template<typename T>
  class AutoReleasePtr{
  public:
    explicit AutoReleasePtr(T *obj)
      : mObj(obj){
    }

    ~AutoReleasePtr(void){
      vpd::release(mObj);
    }

    operator bool(void) const{
      return mObj != 0;
    }

    T const &operator[](std::size_t i) const{
      return mObj[i];
    }

    T *get(void) const{
      return mObj;
    }

    T *&getRef(void){
      return mObj;
    }

    T *release(void){
      T *tmp = mObj;
      mObj = 0;
      return tmp;
    }

    void reset(T *obj = 0){
      vpd::release(mObj);
      mObj = obj;
    }

  private:
    AutoReleasePtr(AutoReleasePtr<T> const &obj);
    AutoReleasePtr<T> &operator=(AutoReleasePtr<T> const &obj);

  private:
    T *mObj;
  };

  /*! @} */
} // namespace vpd
