#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Redirect
   * @brief Redirect settings
   * @{
   */

  /**
   * @brief General redirect settings
   */
  struct RedirectSettings{
    unsigned long mEnable;             /**< enable or disable REDIRECT */
    unsigned long mRedirectSpool;      /**< redirect spool file */
    unsigned long mRedirectPos;        /**< redirect pos file */

    static unsigned int const printerNameSize = 256; /**< max length for printer name */
    WCHAR mPrinter[printerNameSize];   /**< printer name where to redirect */

    static unsigned int const trayNameSize = 256; /**< max length for printer tray name */
    WCHAR mTrayName[trayNameSize];    /**< printer tray name */

    unsigned long mRedirectWatermarks; /**< redirect watermarks */
    unsigned long mLeftCorrection;     /**< left corrections for a left margin of the target printer */
    unsigned long mTopCorrection;      /**< top corrections for a top margin of the target printer */
    unsigned long mRightCorrection;    /**< right corrections for a right margin of the target printer */
    unsigned long mBottomCorrection;   /**< bottom corrections for a bottom margin of the target printer */
  };

  /**
   * Gets REDIRECT settings from the specified registry hive
   * @param [out] settings set of REDIRECT settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getRedirectSettings(RedirectSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets REDIRECT settings for the specified registry hive
   * @param [in] settings set of REDIRECT settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setRedirectSettings(RedirectSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes REDIRECT settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeRedirectSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
