#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * Gets a DEVMODE for the specified printer
   * @param [in] pname printer name
   * @return If the function succeeds, the return value is a pointer to DEVMODE structure
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   * @attention When you finish with the DEVMODE* object, pass it the the releaseDevmode() function to release memory.
   */
  VPD_SDK_API DEVMODE * __stdcall getDevmode(std::wstring const &pname);

  /**
   * Sets a DEVMODE for the specified printer
   * @param [in] pname printer name
   * @param [in] devmode pointer to DEVMODE structure
   * @return If the function succeeds, the return value is non-zero
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   * @attention When you finish with the DEVMODE* object, pass it the the releaseDevmode() function to release memory.
   */
  VPD_SDK_API int __stdcall setDevmode(std::wstring const &pname, DEVMODE *devmode);

  /**
   * Releases a DEVMODE pointer returned from the getDevmode() function.
   * @param [in] devmode pointer to DEVMODE structure
   */
  VPD_SDK_API void __stdcall releaseDevmode(DEVMODE *&devmode);

  /**
   * @brief Helpfull class for auto-releasing DEVMODE* data
   */
  class VPD_SDK_API Devmode{
  public:
    explicit Devmode(DEVMODE *devmode)
      : mDevmode(devmode){
    }

    explicit Devmode(std::wstring const &pname)
      : mDevmode(getDevmode(pname)){
    }

    ~Devmode(void){
      releaseDevmode(mDevmode);
    }

    DEVMODE *operator->(void) const{
      return mDevmode;
    }

    operator DEVMODE *(void) const{
      return mDevmode;
    }

    operator bool(void) const{
      return mDevmode != NULL;
    }

  private:
    DEVMODE *mDevmode;
  };

  /*! @} */
} // namespace vpd
