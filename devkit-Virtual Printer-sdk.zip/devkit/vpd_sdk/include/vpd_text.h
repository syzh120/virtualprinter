#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Text
   * @brief Text settings
   * @{
   */

  /**
   * Text encoding
   */
  enum TextEncoding{
    TextEncodingANSI = 0,    /**< ANSI encoding */
    TextEncodingUnicode = 1, /**< Unicode encoding */
    TextEncodingUTF8 = 2     /**< UTF-8 encoding*/
  };

  /**
   * @brief General text  settings
   */
  struct TextSettings{
    unsigned long mEnable;                        /**< enable or disable TEXT file format */
    unsigned long mMultipage;                     /**< enable or disable multipage */
    TextEncoding mEncoding;                       /**< text encoding */
    unsigned long mWriteBOM;                      /**< enable or disable BOM in text files */
    unsigned long mSingleLineInterval;            /**< set width of an interval on axis OY in which two words are in single line */
    unsigned long mSingleWordInterval;            /**< distance between two words which should be in the one word */
    unsigned long mDebug;                         /**< enable or disable debug output in text files */
    unsigned long mKeepFormatting;                /**< enable or disable text formated output */
    unsigned long mDefaultBidirectionalAlgorithm; /**< use default bidirectional algorithm */
    unsigned long mCleanup;                       /**< remove TEXT files after processing */
  };

  /**
   * Gets TEXT settings from the specified registry hive
   * @param [out] settings set of TEXT settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getTextSettings(TextSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets TEXT settings for the specified registry hive
   * @param [in] settings set of TEXT settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setTextSettings(TextSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes TEXT settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeTextSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
