#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  enum PrinterLocation{
    PrinterLocationLocal = 0,  /**< enumerate all installer printers */
    PrinterLocationNetwork = 1 /**< enumerates network printers in the computer's domain */
  };

  /**
   * @brief Device info
   */
  struct PrinterInfo{
    static std::size_t const nameSize = 256; /**< max length for printer name */
    WCHAR mName[nameSize];                   /**< printer name */
  };

  /**
   * Enumerates all available printers
   * @param [in] type printer location
   * @param [out] printers set of available printers. To free memory call vpd::release()
   * @param [out] count count of elements
   * @return If the function succeeds, the return value is non-zero
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumPrinters(PrinterLocation location, PrinterInfo *&printers, std::size_t &count);

  /**
   * @brief Helpfull class for printer HANDLE
   */
  class VPD_SDK_API Printer{
  public:
    explicit Printer(HANDLE handle);
    explicit Printer(std::wstring const &pname, DWORD accessMask = PRINTER_ACCESS_USE, DEVMODE *devmode = nullptr);
    ~Printer(void);

    operator HANDLE(void) const;
    operator bool(void) const;

    void reset(HANDLE handle);
    void reset(std::wstring const &pname, DWORD accessMask = PRINTER_ACCESS_USE, DEVMODE *devmode = nullptr);

    HANDLE release(void);

  private:
    Printer(Printer const &);
    Printer &operator=(Printer const &);

  private:
    HANDLE mHandle;
  };

  /*! @} */
} // namespace vpd
