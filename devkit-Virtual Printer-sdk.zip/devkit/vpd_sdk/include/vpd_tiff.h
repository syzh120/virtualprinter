#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup TIFF
   * @brief TIFF settings
   * @{
   */

  /**
   * @brief General TIFF settings
   */
  struct TiffSettings{
    unsigned long mEnable;         /**< enable or disable TIFF file format */
    ImageBpp mBpp;                 /**< bits per pixel */
    unsigned long mGrayscale;      /**< enable or disable Grayscale */
    ImageDithering mDithering;     /**< dithering algorithm */
    unsigned long mMultipage;      /**< enable or disable multipage */
    ImageCompression mCompression; /**< file compression */
    unsigned long mCleanup;        /**< remove TIFF files after processing */
  };

  /**
   * Gets TIFF settings from the specified registry hive
   * @param [out] settings set of TIFF settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getTiffSettings(TiffSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets TIFF settings for the specified registry hive
   * @param [in] settings set of TIFF settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setTiffSettings(TiffSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes TIFF settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeTiffSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
