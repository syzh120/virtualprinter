#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Watermark
   * @brief Watermark settings
   * @{
   */

  /**
   * @brief Image fill mode
   */
  enum FillMode{
    FillModeNone = 0, /** None */
    FillModeFill,     /** Fill */
    FillModeFit,      /** Fit */
    FillModeStretch,  /** Stretch*/
    FillModeTitle,    /** Title */
    FillModeCenter    /** Center */
  };

  /**
   * @brief Origin position
   */
  enum PosMode{
    PosModeLT = 0, /** origin at the left-top corner of a page */
    PosModeLB,     /** origin at the left-bottom corner of a page */
    PosModeRT,     /** origin at the right-top corner of a page */
    PosModeRB,     /** origin at the right-bottom corner of a page */
    PosModeC       /** origin at the center of a page */
  };

  /**
   * @brief General image watermark info
   */
  struct ImageWatermarkInfo{
    static unsigned int const nameSize = 32; /**< max length for watermark name */
    WCHAR mName[nameSize];       /**< watermark ID */

    static unsigned int const pathSize = 1024; /**< max length for watermark image path */
    WCHAR mPath[pathSize];       /**< image path */

    unsigned long mLeftOffset;   /**< left offset */
    unsigned long mRightOffset;  /**< right offset */
    unsigned long mTopOffset;    /**< top offset */
    unsigned long mBottomOffset; /**< bottom offset */
    FillMode mFillMode;          /**< fill mode */
    PosMode mPosMode;            /**< position mode */

    ImageWatermarkInfo(void){
    }

    ImageWatermarkInfo(std::wstring const &name,
                       std::wstring const &path,
                       unsigned long leftOffset,
                       unsigned long rightOffset,
                       unsigned long topOffset,
                       unsigned long bottomOffset,
                       FillMode fillmode,
                       PosMode posmode)
      : mLeftOffset(leftOffset),
      mRightOffset(rightOffset),
      mTopOffset(topOffset),
      mBottomOffset(bottomOffset),
      mFillMode(fillmode),
      mPosMode(posmode){

      wcsncpy_s(mName, name.c_str(), ImageWatermarkInfo::nameSize - 1);
      wcsncpy_s(mPath, path.c_str(), ImageWatermarkInfo::pathSize - 1);
    }

    bool operator==(ImageWatermarkInfo const &rhs) const{
      return (wcscmp(mName, rhs.mName) == 0)
             && (wcscmp(mPath, rhs.mPath) == 0)
             && (mLeftOffset == rhs.mLeftOffset)
             && (mRightOffset == rhs.mRightOffset)
             && (mTopOffset == rhs.mTopOffset)
             && (mBottomOffset == rhs.mBottomOffset)
             && (mFillMode == rhs.mFillMode)
             && (mPosMode == rhs.mPosMode);
    }

  };


  /**
   * @brief Text horizontal alignment
   */
  enum HorizontalAlignment{
    HorizontalAlignmentLeft = 0, /**< left alignment */
    HorizontalAlignmentCenter,   /**< center alignment */
    HorizontalAlignmentRight     /**< right alignment */
  };

  /**
   * @brief Text vertical alignment
   */
  enum VerticalAlignment{
    VerticalAlignmentTop = 0, /**< top alignment */
    VerticalAlignmentCenter,  /**< center alignment */
    VerticalAlignmentBottom   /**< bottom alignment */
  };


  /**
   * @brief General textual watermark info
   */
  struct TextWatermarkInfo{
    static unsigned int const nameSize = 32; /**< max length for watermark name */
    WCHAR mName[nameSize];               /**< watermark ID */

    static unsigned int const textSize = 256; /**< max length for watermark text */
    WCHAR mText[textSize];              /**< text message */

    static unsigned int const fontNameSize = 33; /**< max length for font name */
    WCHAR mFontName[fontNameSize];      /**< text font name */

    unsigned long mLeftOffset;          /**< left offset */
    unsigned long mRightOffset;         /**< right offset */
    unsigned long mTopOffset;           /**< top offset */
    unsigned long mBottomOffset;        /**< bottom offset */
    PosMode mPosMode;                   /**< position mode */
    HorizontalAlignment mHorzAlignment; /**< text horizontal alignment */
    VerticalAlignment mVertAlignment;   /**< text vertical alignment */
    COLORREF mColor;                    /**< text color */

    int mFontHeight;                    /**< text font  height */
    int mFontWidth;                     /**< text font width */
    int mRotation;                      /**< text rotation angel */

    TextWatermarkInfo(void){
    }

    TextWatermarkInfo(std::wstring const &name,
                      std::wstring const &text,
                      unsigned long leftOffset,
                      unsigned long rightOffset,
                      unsigned long topOffset,
                      unsigned long bottomOffset,
                      PosMode posMode,
                      HorizontalAlignment horzAlignment,
                      VerticalAlignment vertAlignment,
                      COLORREF color,
                      std::wstring const &fontName,
                      int fontHeight,
                      int fontWidth,
                      int rotation)
      : mLeftOffset(leftOffset),
      mRightOffset(rightOffset),
      mTopOffset(topOffset),
      mBottomOffset(bottomOffset),
      mPosMode(posMode),
      mHorzAlignment(horzAlignment),
      mVertAlignment(vertAlignment),
      mColor(color),
      mFontHeight(fontHeight),
      mFontWidth(fontWidth),
      mRotation(rotation){

      wcsncpy_s(mName, name.c_str(), TextWatermarkInfo::nameSize - 1);
      wcsncpy_s(mText, text.c_str(), TextWatermarkInfo::textSize - 1);
      wcsncpy_s(mFontName, fontName.c_str(), TextWatermarkInfo::fontNameSize - 1);
    }

    bool operator==(TextWatermarkInfo const &rhs) const{
      return (wcscmp(mName, rhs.mName) == 0)
             && (wcscmp(mText, rhs.mText) == 0)
             && (mLeftOffset == rhs.mLeftOffset)
             && (mRightOffset == rhs.mRightOffset)
             && (mTopOffset == rhs.mTopOffset)
             && (mBottomOffset == rhs.mBottomOffset)
             && (mPosMode == rhs.mPosMode)
             && (mHorzAlignment == rhs.mHorzAlignment)
             && (mVertAlignment == rhs.mVertAlignment)
             && (mColor == rhs.mColor)
             && (wcscmp(mFontName, rhs.mFontName) == 0)
             && (mFontHeight == rhs.mFontHeight)
             && (mFontWidth == rhs.mFontWidth)
             && (mRotation == rhs.mRotation);
    }

  };

  /**
   * @brief General watermark settings
   */
  struct WatermarkSettings{
    unsigned long mEnable; /**< enable or disable watermarks */
    unsigned long mQuality; /**< watermark quality */
  };

  /**
   * Gets Watermark settings from the specified registry hive
   * @param [out] settings set of watermark settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getWatermarkSettings(WatermarkSettings &settings, unsigned int hive, std::wstring const &registryKey, unsigned int &currentHive);

  /**
   * Sets Watermark settings for the specified registry hive
   * @param [in] settings set of watermark settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setWatermarkSettings(WatermarkSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes Watermark settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeWatermarkSettings(unsigned int hive, std::wstring const &registryKey);

  /**
   * Adds image watermark
   * @param [in] id watermark ID
   * @param [in] watermark watermark info
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall addImageWatermark(std::wstring const &id, ImageWatermarkInfo const &watermark, unsigned int hive, std::wstring const &registryKey);

  /**
   * Adds image watermark
   * @param [in] id watermark ID
   * @param [in] watermark watermark info
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getImageWatermark(std::wstring const &id, ImageWatermarkInfo &watermark, unsigned int hive, std::wstring const &registryKey);

  /**
   * Enumerates image watermarks
   * @param [out] watermark set of available watermarks. To free memory call vpd::release()
   * @param [out] count count of elements
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumImageWatermarks(ImageWatermarkInfo *&watermarks, std::size_t &count, unsigned int hive, std::wstring const &registryKey);

  /**
   * Adds text watermark
   * @param [in] id watermark ID
   * @param [in] watermark watermark info
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall addTextWatermark(std::wstring const &id, TextWatermarkInfo const &watermark, unsigned int hive, std::wstring const &registryKey);

  /**
   * Adds text watermark
   * @param [in] id watermark ID
   * @param [in] watermark watermark info
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getTextWatermark(std::wstring const &id, TextWatermarkInfo &watermark, unsigned int hive, std::wstring const &registryKey);

  /**
   * Enumerates text watermarks
   * @param [out] watermark set of available watermarks. To free memory call vpd::release()
   * @param [out] count count of elements
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall enumTextWatermarks(TextWatermarkInfo *&watermarks, std::size_t &count, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes image or text watermark
   * @param [in] id watermark ID
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeWatermark(std::wstring const &id, unsigned int hive, std::wstring const &registryKey);

  /*! @}  */
} // namespace vpd
