#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup PDF
   * @brief PDF settings
   * @{
   */

  /**
   * @brief Timezone
   */
  enum Timezone{
    TimezoneUTC = 0,  /**< UTC */
    TimezoneLocal = 1 /**< Localtime */
  };

  /**
   * @brief PDF page layout
   */
  enum PageLayout{
    PageLayoutSinglePage = 0,     /**< Single page */
    PageLayoutOneColumn = 1,      /**< One column */
    PageLayoutTwoColumnLeft = 2,  /**< Two column left */
    PageLayoutTwoColumnRight = 3, /**< Two column right */
    PageLayoutTwoPageLeft = 4,    /**< Two page left */
    PageLayoutTwoPageRight = 5    /**< Two page right */
  };

  /**
   * @biref PDF page mode
   */
  enum PageMode{
    PageModeNone = 0,       /**< None */
    PageModeOutlines = 1,   /**< Outlines */
    PageModeThumbs = 2,     /**< Thumbnail */
    PageModeFullScreen = 3, /**< Full screen */
    PageModeOC = 4,         /**< Optional content */
    PageModeAttachments = 5 /**< Attachments */
  };

  /**
   * @brief PDF encryption algorithm
   */
  enum EncryptionLevel{
    EncryptionLevelNone = 0,      /**< None */
    EncryptionLevel40bitRC4 = 1,  /**< 40-bit RC4 */
    EncryptionLevel128bitRC4 = 2, /**< 128-bit RC4 */
    EncryptionLevel128bitAES = 3, /**< 128-bit AES */
    EncryptionLevel256bitAES = 4  /**< 256-bit AES */
  };

  /**
   * @brief General PDF settings
   */
  struct PdfSettings{
    unsigned long mEnable;       /**< enable PDF file format */
    unsigned long mMultipage;    /**< enable multipage */
    unsigned long mProducePdfA;  /**< produce PDFA format */
    Timezone mTimezone;          /**< produce date timezone */
    int mUseMthread;             /**< use multithreaded converter */
    PageLayout mPageLayout;      /**< page layout */
    PageMode mPageMode;          /**< page mode */
    unsigned long mSecured;      /**< enable password authentication */
    EncryptionLevel  mEncryptionLevel; /**< encryption algorithm */
    unsigned long mEnableUserPassword; /**< enable user password */
    unsigned long mEnableOwnerPassword;/**< enable owner password */
    unsigned long mAllowCopying;       /**< allow document copying */
    unsigned long mAllowCommenting;    /**< allow document commenting */
    unsigned long mAllowChanging;      /**< allow document changing */
    unsigned long mAllowPrinting;      /**< allow document printing */
    unsigned long mCleanup;            /**< remove PDF files after processing */
    unsigned long mUseDocumentName;    /**< use a document name as a file name */

    static unsigned int const titleSize = 256;         /**< max length for title field */
    WCHAR mTitle[titleSize];                           /**< document title */
                                                       
    static unsigned int const authorSize = 64;         /**< max length for author field */
    WCHAR mAuthor[authorSize];                         /**< document author */
                                                       
    static unsigned int const producerSize = 64;       /**< max length for producer field */
    WCHAR mProducer[producerSize];                     /**< document producer */
                                                       
    static unsigned int const creatorSize = 64;        /**< max length for creator field */
    WCHAR mCreator[creatorSize];                       /**< document creator */
                                                       
    static unsigned int const subjectSize = 64;        /**< max length for subject field */
    WCHAR mSubject[subjectSize];                       /**< document subject */
                                                       
    static unsigned int const keywordsSize = 256;      /**< max length for keywords field */
    WCHAR mKeywords[keywordsSize];                     /**< document keywords */

    static unsigned int const userPasswordSize = 256;  /**< max length for user password */
    WCHAR mUserPassword[userPasswordSize];             /**< user password */

    static unsigned int const ownerPasswordSize = 256; /**< max length for owner password */
    WCHAR mOwnerPassword[ownerPasswordSize];           /**< owner password */

    unsigned long mImageQuality;                       /**< image quality */
    unsigned long mBlackAndWhite;                      /**< produce Black and White non-searchable PDF */

    unsigned long mNonChunked;                         /**< append each EMF page to the end of PDF document (no chunks) */
  };

  /**
   * Gets PDF settings from the specified registry hive
   * @param [out] settings set of PDF settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPdfSettings(PdfSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets PDF settings for the specified registry hive
   * @param [in] settings set of PDF settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setPdfSettings(PdfSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes PDF settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removePdfSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
