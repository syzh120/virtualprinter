#pragma once

#ifdef VPD_SDK_DLL_PROJ
  #ifdef VPD_SDK_EXPORTS
    #define VPD_SDK_API __declspec(dllexport)
  #else
    #define VPD_SDK_API __declspec(dllimport)
  #endif
#else
  #define VPD_SDK_API
#endif

#include <Windows.h>
#include <UserEnv.h>
#include <string>
#include <vector>
#include <queue>
#include <list>

/*! @file */

namespace vpd{
  /**
   * @addtogroup Tools
   * @{
   */

  /**
   * Image bits per pixel values
   */
  enum ImageBpp{
    ImageBpp1 = 1,  /**< black-and-white image */
    ImageBpp4 = 4,  /**< 4-bit image */
    ImageBpp8 = 8,  /**< 8-bit image */
    ImageBpp24 = 24 /**< 24-bit image */
  };

  /**
   * Image dithering algorithm
   */
  enum ImageDithering{
    ImageDitheringFloydSteinberg = 0, /**< Floyd-Steinberg algorithm */
    ImageDitheringOrderedDithering,   /**< Ordered dithering algorithm */
    ImageDitheringBurkes,             /**< Burkes algorithm */
    ImageDitheringStucki,             /**< Stucki algorithm */
    ImageDitheringJarvisJudiceNinke,  /**< Jarvis-Judice-Ninke algorithm */
    ImageDitheringSierra,             /**< Sierra algorithm */
    ImageDitheringStevensonArce,      /**< Stevenson-Arce algorithm */
    ImageDitheringBayer               /**< Bayer algorithm */
  };

  /**
   * Image compression algorithm
   */
  enum ImageCompression{
    ImageCompressionAutomatic = 0,              /**< Automatic */
    ImageCompressionNone = 1,                   /**< None */
    ImageCompressionCCITTHuffmanRLE = 2,        /**< CCITT Huffman RLE */
    ImageCompressionCCITTGroup3FaxEncoding = 3, /**< CCITT Group 3 Fax Encoding */
    ImageCompressionCCITTGroup4FaxEncoding = 4, /**< CCITT Group 4 Fax Encoding */
    ImageCompressionLZW = 5,                    /**< LZW */
    ImageCompressionJpegDCT = 7,                /**< Jpeg DCT */
    ImageCompressionAdobeDeflate = 8,           /**< Adobe deflate */
    ImageCompressionMacintoshRLE = 32773,       /**< Macintosh RLE */
    ImageCompressionDeflate = 32946             /**< Deflate */
  };

  unsigned int const REGISTRY_HKLM = 0x1; /**< registry settings for HKEY_LOCAL_MACHINE hive */
  unsigned int const REGISTRY_HKCU = 0x2; /**< registry settings for HKEY_CURRENT_USER hive */
  unsigned int const REGISTRY_HKU  = 0x4; /**< registry settings for HKEY_USERS hive */

} // namespace vpd
