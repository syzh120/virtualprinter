#pragma once

#include <vpd.h>
/*! @file */

namespace vpd{
  /**
   * @addtogroup Application
   * @brief Preprocessor, preconverter and postconverter settings
   * @{
   */

  /**
   * @brief Format skip mode
   */
  enum SkipMode{
    SkipModeNone = 0, /**< call an application for both formats */
    SkipModeEmf = 1,  /**< do not call an application for EMF format */
    SkipModeRaw = 2   /**< do not call an application for RAW format */
  };

  /**
   * @brief Transfer mode
   */
  enum TransferMode{
    TransferModeCmd = 0,        /**< send data to an application through a command line */
    TransferModeCopydata = 1,   /**< send data to an application through a WM_COPYDATA message */
    TransferModeNone = 2,       /**< do not call an application */
    TransferModePipe = 3        /**< send data to an application through a named pipe */
  };

  /**
   * @brief Appliation type
   */
  enum ApplicationType{
    ApplicationTypePreprocessor = 0, /**< preprocessor */
    ApplicationTypePreconverter = 1, /**< preconverter */
    ApplicationTypePostconverter = 2 /**< postconverter */
  };

  /**
   * @brief General application settings
   */
  struct ApplicationSettings{
    unsigned long mEnabled; /**< enable an application call */
    unsigned long mEarlyAccess; /**< enable early access to the converted files */

    static unsigned int const pathSize = 1024; /**< max lenght of an application path */
    WCHAR mPath[pathSize]; /**< path to an executable application */

    SkipMode mSkipMode;
    TransferMode mTransferMode;
    unsigned long mTimeout; /**< timeout for an application initialization or response */

    static unsigned int const nameSize = 256; /**< max length of a name */
    WCHAR mWindowTitle[nameSize];   /**< window title for a WM_COPYDATA message */
    WCHAR mWindowClass[nameSize];   /**< window class name for a WM_COPYDATA message */
    unsigned long mMessageId;       /**< message ID for a WM_COPYDATA message */
    unsigned long mNotifyAll;       /**< notify all windows with required window title and class */

    WCHAR mPipeName[nameSize];            /**< pipe name */
    unsigned long mPipeMessageSize;       /**< pipe message size */
    unsigned long mPipeLaunchApplication; /**< launch an application before sending data through a pipe */
  };

  /**
   * Gets application settings from the specified registry hive
   * @param [in] type application type
   * @param [out] settings set of application settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *          REGISTRY_HKU  - read settings from HKEY_USERS hive, DO NOT USE WITH OTHER VALUES
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getApplicationSettings(ApplicationType type, ApplicationSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets application settings for the specified registry hive
   * @param [in] type application type
   * @param [in] settings set of application settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setApplicationSettings(ApplicationType type, ApplicationSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes application settings from the specified registry hive
   * @param [in] type application type
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeApplicationSettings(ApplicationType type, unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
