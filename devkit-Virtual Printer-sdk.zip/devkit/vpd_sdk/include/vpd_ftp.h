#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup FTP
   * @brief FTP settings
   * @{
   */

  /**
   * @brief General FTP settings
   */
  struct FtpSettings{
    unsigned long mEnable;      /**< enable or disable FTP/SFTP/FTPS */

    static unsigned int const urlSize = 256;  /**< max length of URL */
    WCHAR mUrl[urlSize];                      /**< server URL */

    static unsigned int const userNameSize = 32; /**< max length for user name */
    WCHAR mUserName[userNameSize];               /**< user name */

    static unsigned int const passwordSize = 128; /**< max lenth for user password */
    WCHAR mPassword[passwordSize];                /**< user password */

    static unsigned int const uploadConfigSize = 1024; /**< max length for upload config */

    /**
     * set of tokens "TYPE:PATH;" where TYPE one of {EMF, BMP, PNG, TIFF, JPEG, TXT, PDF}
     * and PATH is a relative path from root directory of a FTP server. Example: "BMP:.;JPEG:jpeg;PNG:other/png"
     */
    WCHAR mUploadConfig[uploadConfigSize]; 

    unsigned long mEncrypted;       /**< is user credentials encrypted with using AES_Encryptor tool or not */
    unsigned long mAttempts;        /**< count of attempts for uploading files to the server */
    unsigned long mIgnoreCertError; /**< ignore SSL certificate error */
  };

  /**
   * Gets FTP settings from the specified registry hive
   * @param [out] settings set of FTP settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getFtpSettings(FtpSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets FTP settings for the specified registry hive
   * @param [in] settings set of FTP settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setFtpSettings(FtpSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes FTP settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removeFtpSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
