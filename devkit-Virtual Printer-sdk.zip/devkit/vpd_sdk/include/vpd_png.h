#pragma once

#include <vpd.h>

/*! @file */

namespace vpd{
  /**
   * @addtogroup PNG
   * @brief PNG settings
   * @{
   */

  /**
   * @brief General PNG settings
   */
  struct PngSettings{
    unsigned long mEnable;     /**< enable or disable PNG file format */
    ImageBpp mBpp;             /**< bits per pixel */
    unsigned long mGrayscale;  /**< enable or disable Grayscale */
    ImageDithering mDithering; /**< dithering algorithm */
    unsigned long mCleanup;    /**< remove PNG files after processing */
  };

  /**
   * Gets PNG settings from the specified registry hive
   * @param [out] settings set of PNG settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - read settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - read settings from HKEY_CURRENT_USER hive, HKCU hive is preffer than HKLM
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall getPngSettings(PngSettings &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Sets PNG settings for the specified registry hive
   * @param [in] settings set of PNG settings
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - save settings in HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - save settings in HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall setPngSettings(PngSettings const &settings, unsigned int hive, std::wstring const &registryKey);

  /**
   * Removes PNG settings from the specified registry hive
   * @param [in] hive registry hive, can be one or more of the following values
   *
   *          REGISTRY_HKLM - remove settings from HKEY_LOCAL_MACHINE hive
   *          REGISTRY_HKCU - remove settings from HKEY_CURRENT_USER hive
   *
   * @param [in] registryKey registry entry
   * @return If the function succeeds, the return value is non-zero.
   * @return If the function fails, the return value is zero and GetLastError() will return the error code.
   */
  VPD_SDK_API int __stdcall removePngSettings(unsigned int hive, std::wstring const &registryKey);

  /*! @} */
} // namespace vpd
