#include <vpd_converter.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const converterRoot = L"Converter";
    std::wstring const converterThreads = L"Threads";
    std::wstring const converterCleanupOutput = L"Cleanup Output";
    std::wstring const converterShowProgress = L"Show Progress";
    std::wstring const converterOutputDir = L"Output Directory";
    std::wstring const converterPagesPerSheet = L"Pages Per Sheet";
    std::wstring const converterDrawBorders = L"Draw Borders";
  }

  using namespace vpd::tools;

  int __stdcall getConverterSettings(ConverterSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring converterEntry = registryKey + L"\\" + converterRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord converterThreadsRecord(converterEntry, converterThreads, 1);
    RegistryRecord converterShowProgressRecord(converterEntry, converterShowProgress, 1);
    RegistryRecord converterOutputDirRecord(converterEntry, converterOutputDir, L"");
    RegistryRecord converterCleanupOutputRecord(converterEntry, converterCleanupOutput, 0);
    RegistryRecord converterPagesPerSheetRecord(converterEntry, converterPagesPerSheet, 1);
    RegistryRecord converterDrawBordersRecord(converterEntry, converterDrawBorders, 0);

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(converterOutputDirRecord, HKEY_CURRENT_USER)){
    }
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(converterOutputDirRecord, HKEY_LOCAL_MACHINE)){
    }
    else if ((hive & REGISTRY_HKU) && getRegistryRecord(converterOutputDirRecord, HKEY_USERS)){
    }
    else
      return 0;

    std::vector<RegistryRecord*> records;
    records.push_back(&converterThreadsRecord);
    records.push_back(&converterShowProgressRecord);
    records.push_back(&converterCleanupOutputRecord);
    records.push_back(&converterPagesPerSheetRecord);
    records.push_back(&converterDrawBordersRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && getRegistryRecord(*records[i], HKEY_CURRENT_USER)){
      }
      else if ((hive & REGISTRY_HKLM) && getRegistryRecord(*records[i], HKEY_LOCAL_MACHINE)){
      }
      else if ((hive & REGISTRY_HKU) && getRegistryRecord(*records[i], HKEY_USERS)){
      }
      else if (GetLastError() != ERROR_FILE_NOT_FOUND)
        return 0;
    }

    settings.mThreads = converterThreadsRecord.DData;
    settings.mShowProgressBar = converterShowProgressRecord.DData;
    wcsncpy_s(settings.mOutputDir, converterOutputDirRecord.SData.c_str(), ConverterSettings::directorySize - 1);
    settings.mCleanupOutput = converterCleanupOutputRecord.DData;

    if (wcslen(settings.mOutputDir)){
      if (ExpandEnvironmentStrings(settings.mOutputDir, settings.mExpandedOutputDir, ConverterSettings::directorySize) > ConverterSettings::directorySize)
        return 0;
    }
    else
      settings.mExpandedOutputDir[0] = 0;

    settings.mPagesPerSheet = converterPagesPerSheetRecord.DData;
    settings.mDrawBorders = converterDrawBordersRecord.DData;

    return 1;
  }

  int __stdcall setConverterSettings(ConverterSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring converterEntry = registryKey + L"\\" + converterRoot;

    RegistryRecord converterThreadsRecord(converterEntry, converterThreads, settings.mThreads);
    RegistryRecord converterShowProgressRecord(converterEntry, converterShowProgress, settings.mShowProgressBar);
    RegistryRecord converterOutputDirRecord(converterEntry, converterOutputDir, settings.mOutputDir);
    RegistryRecord converterCleanupOutputRecord(converterEntry, converterCleanupOutput, settings.mCleanupOutput);
    RegistryRecord converterPagesPerSheetRecord(converterEntry, converterPagesPerSheet, settings.mPagesPerSheet);
    RegistryRecord converterDrawBordersRecord(converterEntry, converterDrawBorders, settings.mDrawBorders);

    std::vector<RegistryRecord*> records;
    records.push_back(&converterThreadsRecord);
    records.push_back(&converterShowProgressRecord);
    records.push_back(&converterOutputDirRecord);
    records.push_back(&converterCleanupOutputRecord);
    records.push_back(&converterPagesPerSheetRecord);
    records.push_back(&converterDrawBordersRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeConverterSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring converterEntry = registryKey + L"\\" + converterRoot;

    RegistryRecord converterThreadsRecord(converterEntry, converterThreads, 1);
    RegistryRecord converterShowProgressRecord(converterEntry, converterShowProgress, 1);
    RegistryRecord converterOutputDirRecord(converterEntry, converterOutputDir, L"");
    RegistryRecord converterCleanupOutputRecord(converterEntry, converterCleanupOutput, 0);
    RegistryRecord converterPagesPerSheetRecord(converterEntry, converterPagesPerSheet, 1);
    RegistryRecord converterDrawBordersRecord(converterEntry, converterDrawBorders, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&converterThreadsRecord);
    records.push_back(&converterShowProgressRecord);
    records.push_back(&converterOutputDirRecord);
    records.push_back(&converterCleanupOutputRecord);
    records.push_back(&converterPagesPerSheetRecord);
    records.push_back(&converterDrawBordersRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
