#include <vpd_watermark.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const watermarksRoot = L"Converter\\Watermarks";
    std::wstring const watermarksEnabled = L"Enabled";
    std::wstring const watermarksQuality = L"Quality";

    std::wstring const watermarkTypeValue = L"Type";
    std::wstring const watermarkLeftOffsetValue = L"Left offset";
    std::wstring const watermarkRightOffsetValue = L"Right offset";
    std::wstring const watermarkTopOffsetValue = L"Top offset";
    std::wstring const watermarkBottomOffsetValue = L"Bottom offset";
    std::wstring const watermarkPosModeValue = L"Position mode";

    std::wstring const imageWtmPathValue = L"Image path";
    std::wstring const imageWtmFillModeValue = L"Fill mode";

    std::wstring const textWtmTextValue = L"Text";
    std::wstring const textWtmHorzAlignmentValue = L"Horizontal Alignment";
    std::wstring const textWtmVertAlignmentValue = L"Vertical Alignment";
    std::wstring const textWtmColorValue = L"Color";
    std::wstring const textWtmFontNameValue = L"Font Name";
    std::wstring const textWtmFontHeightValue = L"Font Height";
    std::wstring const textWtmFontWidthValue = L"Font Width";
    std::wstring const textWtmRotationValue = L"Rotation";

    /**
     * @brief Watermark type
     */
    enum WatermarkType{
      WatermarkTypeImage = 0, /**< Image watermark */
      WatermarkTypeText = 1   /**< Textual watermark */
    };

    bool isRequiredWatermarkType(std::wstring const &id, unsigned int hive, std::wstring const &registryKey, WatermarkType type);
  }

  using namespace vpd::tools;

  int __stdcall getWatermarkSettings(WatermarkSettings &settings, unsigned int hive, std::wstring const &registryKey, unsigned int &currentHive){
    std::wstring watermarkEntry = registryKey + L"\\" + watermarksRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord watermarksEnabledRecord(watermarkEntry, watermarksEnabled, 0);
    RegistryRecord watermarksQualityRecord(watermarkEntry, watermarksQuality, 100);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(watermarksEnabledRecord, HKEY_CURRENT_USER)){
      regHive = HKEY_CURRENT_USER;
      currentHive = REGISTRY_HKCU;
    }
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(watermarksEnabledRecord, HKEY_LOCAL_MACHINE)){
      regHive = HKEY_LOCAL_MACHINE;
      currentHive = REGISTRY_HKLM;
    }
    else
      return 0;

    std::vector<RegistryRecord*> records;
    records.push_back(&watermarksQualityRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = watermarksEnabledRecord.DData;
    settings.mQuality = watermarksQualityRecord.DData;

    return 1;
  }

  int __stdcall setWatermarkSettings(WatermarkSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring watermarksEntry = registryKey + L"\\" + watermarksRoot;

    RegistryRecord watermarksEnabledRecord(watermarksEntry, watermarksEnabled, settings.mEnable);
    RegistryRecord watermarksQualityRecord(watermarksEntry, watermarksQuality, settings.mQuality);

    std::vector<RegistryRecord*> records;
    records.push_back(&watermarksEnabledRecord);
    records.push_back(&watermarksQualityRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeWatermarkSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring watermarksEntry = registryKey + L"\\" + watermarksRoot;

    RegistryRecord watermarksEnabledRecord(watermarksEntry, watermarksEnabled, 0);
    RegistryRecord watermarksQualityRecord(watermarksEntry, watermarksQuality, 100);

    std::vector<RegistryRecord*> records;
    records.push_back(&watermarksEnabledRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

  int __stdcall addImageWatermark(std::wstring const &id, ImageWatermarkInfo const &watermark, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot + L"\\" + id;
    RegistryRecord typeRecord(root, watermarkTypeValue, WatermarkTypeImage);
    RegistryRecord pathRecord(root, imageWtmPathValue, watermark.mPath);
    RegistryRecord leftOffsetRecord(root, watermarkLeftOffsetValue, watermark.mLeftOffset);
    RegistryRecord rightOffsetRecord(root, watermarkRightOffsetValue, watermark.mRightOffset);
    RegistryRecord topOffsetRecord(root, watermarkTopOffsetValue, watermark.mTopOffset);
    RegistryRecord bottomOffsetRecord(root, watermarkBottomOffsetValue, watermark.mBottomOffset);
    RegistryRecord fillModeRecord(root, imageWtmFillModeValue, watermark.mFillMode);
    RegistryRecord posModeRecord(root, watermarkPosModeValue, watermark.mPosMode);

    std::vector<RegistryRecord*> records;
    records.push_back(&typeRecord);
    records.push_back(&pathRecord);
    records.push_back(&leftOffsetRecord);
    records.push_back(&rightOffsetRecord);
    records.push_back(&topOffsetRecord);
    records.push_back(&bottomOffsetRecord);
    records.push_back(&fillModeRecord);
    records.push_back(&posModeRecord);

    for (std::size_t i = 0, size = records.size(); i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall getImageWatermark(std::wstring const &id, ImageWatermarkInfo &watermark, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot + L"\\" + id;
    RegistryRecord typeRecord(root, watermarkTypeValue, WatermarkTypeImage);
    RegistryRecord pathRecord(root, imageWtmPathValue, L"");
    RegistryRecord leftOffsetRecord(root, watermarkLeftOffsetValue, 0);
    RegistryRecord rightOffsetRecord(root, watermarkRightOffsetValue, 0);
    RegistryRecord topOffsetRecord(root, watermarkTopOffsetValue, 0);
    RegistryRecord bottomOffsetRecord(root, watermarkBottomOffsetValue, 0);
    RegistryRecord fillModeRecord(root, imageWtmFillModeValue, FillModeFill);
    RegistryRecord posModeRecord(root, watermarkPosModeValue, PosModeC);

    std::vector<RegistryRecord*> records;
    records.push_back(&typeRecord);
    records.push_back(&pathRecord);
    records.push_back(&leftOffsetRecord);
    records.push_back(&rightOffsetRecord);
    records.push_back(&topOffsetRecord);
    records.push_back(&bottomOffsetRecord);
    records.push_back(&fillModeRecord);
    records.push_back(&posModeRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(typeRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(typeRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    for (std::size_t i = 0, size = records.size(); i < size; ++i){
      if (!getRegistryRecord(*records[i], regHive))
        return 0;
    }

    if (typeRecord.DData != WatermarkTypeImage){
      SetLastError(ERROR_FILE_NOT_FOUND);
      return 0;
    }

    wcsncpy_s(watermark.mName, id.c_str(), ImageWatermarkInfo::nameSize - 1);
    wcsncpy_s(watermark.mPath, pathRecord.SData.c_str(), ImageWatermarkInfo::pathSize - 1);
    watermark.mLeftOffset = leftOffsetRecord.DData;
    watermark.mRightOffset = rightOffsetRecord.DData;
    watermark.mTopOffset = topOffsetRecord.DData;
    watermark.mBottomOffset = bottomOffsetRecord.DData;
    watermark.mFillMode = (FillMode) fillModeRecord.DData;
    watermark.mPosMode = (PosMode) posModeRecord.DData;

    return 1;
  }

  int __stdcall enumImageWatermarks(ImageWatermarkInfo *&watermarks, std::size_t &count, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot;

    std::vector<HKEY> hives;
    if (hive & REGISTRY_HKCU)
      hives.push_back(HKEY_CURRENT_USER);

    if (hive & REGISTRY_HKLM)
      hives.push_back(HKEY_LOCAL_MACHINE);

    std::vector<std::wstring> keys;

    count = 0;
    for (std::size_t i = 0, hives_size = hives.size(); i < hives_size; ++i){
      if (!enumRegistryKeys(root, keys, hives[i]))
        continue;

      for (std::size_t entry = 0, keys_size = keys.size(); entry < keys_size; ++entry)
        if (isRequiredWatermarkType(keys[entry], hives[i] == HKEY_CURRENT_USER ? REGISTRY_HKCU : REGISTRY_HKLM, registryKey, vpd::WatermarkTypeImage))
          ++count;
    }

    try{
      watermarks = new ImageWatermarkInfo[count];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    std::size_t position = 0;
    for (std::size_t i = 0, hives_size = hives.size(); i < hives_size; ++i){
      if (!enumRegistryKeys(root, keys, hives[i]))
        continue;

      for (std::size_t entry = 0, keys_size = keys.size(); entry < keys_size; ++entry){
        if (getImageWatermark(keys[entry], watermarks[position], hives[i] == HKEY_CURRENT_USER ? REGISTRY_HKCU : REGISTRY_HKLM, registryKey))
          ++position;
      }
    }

    return 1;
  }

  int __stdcall addTextWatermark(std::wstring const &id, TextWatermarkInfo const &watermark, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot + L"\\" + id;
    RegistryRecord typeRecord(root, watermarkTypeValue, WatermarkTypeText);
    RegistryRecord textRecord(root, textWtmTextValue, watermark.mText);
    RegistryRecord leftOffsetRecord(root, watermarkLeftOffsetValue, watermark.mLeftOffset);
    RegistryRecord rightOffsetRecord(root, watermarkRightOffsetValue, watermark.mRightOffset);
    RegistryRecord topOffsetRecord(root, watermarkTopOffsetValue, watermark.mTopOffset);
    RegistryRecord bottomOffsetRecord(root, watermarkBottomOffsetValue, watermark.mBottomOffset);
    RegistryRecord posModeRecord(root, watermarkPosModeValue, watermark.mPosMode);
    RegistryRecord horzAlignRecord(root, textWtmHorzAlignmentValue, watermark.mHorzAlignment);
    RegistryRecord vertAlignRecord(root, textWtmVertAlignmentValue, watermark.mVertAlignment);
    RegistryRecord colorRecord(root, textWtmColorValue, watermark.mColor);
    RegistryRecord fontNameRecord(root, textWtmFontNameValue, watermark.mFontName);
    RegistryRecord fontHeightRecord(root, textWtmFontHeightValue, watermark.mFontHeight);
    RegistryRecord fontWidthRecord(root, textWtmFontWidthValue, watermark.mFontWidth);
    RegistryRecord rotationRecord(root, textWtmRotationValue, watermark.mRotation);

    std::vector<RegistryRecord*> records;
    records.push_back(&typeRecord);
    records.push_back(&textRecord);
    records.push_back(&leftOffsetRecord);
    records.push_back(&rightOffsetRecord);
    records.push_back(&topOffsetRecord);
    records.push_back(&bottomOffsetRecord);
    records.push_back(&posModeRecord);
    records.push_back(&horzAlignRecord);
    records.push_back(&vertAlignRecord);
    records.push_back(&colorRecord);
    records.push_back(&fontNameRecord);
    records.push_back(&fontHeightRecord);
    records.push_back(&fontWidthRecord);
    records.push_back(&rotationRecord);

    for (std::size_t i = 0, size = records.size(); i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall getTextWatermark(std::wstring const &id, TextWatermarkInfo &watermark, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot + L"\\" + id;
    RegistryRecord typeRecord(root, watermarkTypeValue, WatermarkTypeText);
    RegistryRecord textRecord(root, textWtmTextValue, L"");
    RegistryRecord leftOffsetRecord(root, watermarkLeftOffsetValue, 0);
    RegistryRecord rightOffsetRecord(root, watermarkRightOffsetValue, 0);
    RegistryRecord topOffsetRecord(root, watermarkTopOffsetValue, 0);
    RegistryRecord bottomOffsetRecord(root, watermarkBottomOffsetValue, 0);
    RegistryRecord posModeRecord(root, watermarkPosModeValue, PosModeC);
    RegistryRecord horzAlignRecord(root, textWtmHorzAlignmentValue, HorizontalAlignmentCenter);
    RegistryRecord vertAlignRecord(root, textWtmVertAlignmentValue, VerticalAlignmentCenter);
    RegistryRecord colorRecord(root, textWtmColorValue, 0);
    RegistryRecord fontNameRecord(root, textWtmFontNameValue, L"Arial");
    RegistryRecord fontHeightRecord(root, textWtmFontHeightValue, 0);
    RegistryRecord fontWidthRecord(root, textWtmFontWidthValue, 0);
    RegistryRecord rotationRecord(root, textWtmRotationValue, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&typeRecord);
    records.push_back(&textRecord);
    records.push_back(&leftOffsetRecord);
    records.push_back(&rightOffsetRecord);
    records.push_back(&topOffsetRecord);
    records.push_back(&bottomOffsetRecord);
    records.push_back(&posModeRecord);
    records.push_back(&horzAlignRecord);
    records.push_back(&vertAlignRecord);
    records.push_back(&colorRecord);
    records.push_back(&fontNameRecord);
    records.push_back(&fontHeightRecord);
    records.push_back(&fontWidthRecord);
    records.push_back(&rotationRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(typeRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(typeRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    for (std::size_t i = 0, size = records.size(); i < size; ++i){
      if (!getRegistryRecord(*records[i], regHive))
        return 0;
    }

    if (typeRecord.DData != WatermarkTypeText){
      SetLastError(ERROR_FILE_NOT_FOUND);
      return 0;
    }

    wcsncpy_s(watermark.mName, id.c_str(), TextWatermarkInfo::nameSize - 1);
    wcsncpy_s(watermark.mText, textRecord.SData.c_str(), TextWatermarkInfo::textSize - 1);
    watermark.mLeftOffset = leftOffsetRecord.DData;
    watermark.mRightOffset = rightOffsetRecord.DData;
    watermark.mTopOffset = topOffsetRecord.DData;
    watermark.mBottomOffset = bottomOffsetRecord.DData;
    watermark.mPosMode = (PosMode) posModeRecord.DData;
    watermark.mHorzAlignment = (HorizontalAlignment) horzAlignRecord.DData;
    watermark.mVertAlignment = (VerticalAlignment) vertAlignRecord.DData;
    watermark.mColor = colorRecord.DData;
    wcsncpy_s(watermark.mFontName, fontNameRecord.SData.c_str(), TextWatermarkInfo::fontNameSize - 1);
    watermark.mFontHeight = fontHeightRecord.DData;
    watermark.mFontWidth = fontWidthRecord.DData;
    watermark.mRotation = rotationRecord.DData;

    return 1;
  }

  int __stdcall enumTextWatermarks(TextWatermarkInfo *&watermarks, std::size_t &count, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot;

    std::vector<HKEY> hives;
    if (hive & REGISTRY_HKCU)
      hives.push_back(HKEY_CURRENT_USER);

    if (hive & REGISTRY_HKLM)
      hives.push_back(HKEY_LOCAL_MACHINE);

    std::vector<std::wstring> keys;


    count = 0;
    for (std::size_t i = 0, hives_size = hives.size(); i < hives_size; ++i){
      if (!enumRegistryKeys(root, keys, hives[i]))
        continue;

      for (std::size_t entry = 0, keys_size = keys.size(); entry < keys_size; ++entry)
        if (isRequiredWatermarkType(keys[entry], hives[i] == HKEY_CURRENT_USER ? REGISTRY_HKCU : REGISTRY_HKLM, registryKey, WatermarkTypeText))
          ++count;
    }

    try{
      watermarks = new TextWatermarkInfo[count];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    std::size_t position = 0;
    for (std::size_t i = 0, hives_size = hives.size(); i < hives_size; ++i){
      if (!enumRegistryKeys(root, keys, hives[i]))
        continue;

      for (std::size_t entry = 0, keys_size = keys.size(); entry < keys_size; ++entry)
        if (getTextWatermark(keys[entry], watermarks[position], hives[i] == HKEY_CURRENT_USER ? REGISTRY_HKCU : REGISTRY_HKLM, registryKey))
          ++position;
    }

    return 1;
  }

  int __stdcall removeWatermark(std::wstring const &id, unsigned int hive, std::wstring const &registryKey){
    std::wstring root = registryKey + L"\\" + watermarksRoot;

    if ((hive & REGISTRY_HKCU) && !removeRegistryKey(root, id,  HKEY_CURRENT_USER))
      return 0;

    if ((hive & REGISTRY_HKLM) && !removeRegistryKey(root, id, HKEY_LOCAL_MACHINE))
        return 0;
    
    return 1;
  }

  namespace{
    bool isRequiredWatermarkType(std::wstring const &id, unsigned int hive, std::wstring const &registryKey, vpd::WatermarkType type){
      std::wstring root = registryKey + L"\\" + watermarksRoot + L"\\" + id;
      vpd::RegistryRecord typeRecord(root, watermarkTypeValue, vpd::WatermarkTypeImage);

      HKEY regHive = NULL;

      if ((hive & vpd::REGISTRY_HKCU) && getRegistryRecord(typeRecord, HKEY_CURRENT_USER))
        regHive = HKEY_CURRENT_USER;
      else if ((hive & vpd::REGISTRY_HKLM) && getRegistryRecord(typeRecord, HKEY_LOCAL_MACHINE))
        regHive = HKEY_LOCAL_MACHINE;
      else
        return false;

      if (!getRegistryRecord(typeRecord, regHive))
        return false;

      if (typeRecord.DData != type)
        return false;

      return true;
    }
  } // namespace
}; // namespace vpd


