#include <vpd_png.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const pngRoot = L"Converter\\PNG";
    std::wstring const pngEnabled = L"Enabled";
    std::wstring const pngBpp = L"Bits per pixel";
    std::wstring const pngGrayscale = L"Grayscale";
    std::wstring const pngDithering = L"Dithering";
    std::wstring const pngCleanup = L"Cleanup";
  }

  using namespace vpd::tools;

  int __stdcall getPngSettings(PngSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring pngEntry = registryKey + L"\\" + pngRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord pngEnabledRecord(pngEntry, pngEnabled, 0);
    RegistryRecord pngBppRecord(pngEntry, pngBpp, 24);
    RegistryRecord pngGrayscaleRecord(pngEntry, pngGrayscale, 0);
    RegistryRecord pngDitheringRecord(pngEntry, pngDithering, 0);
    RegistryRecord pngCleanupRecord(pngEntry, pngCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&pngBppRecord);
    records.push_back(&pngGrayscaleRecord);
    records.push_back(&pngDitheringRecord);
    records.push_back(&pngCleanupRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(pngEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(pngEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = pngEnabledRecord.DData;
    settings.mBpp = (ImageBpp) pngBppRecord.DData;
    settings.mGrayscale = pngGrayscaleRecord.DData;
    settings.mDithering = (ImageDithering) pngDitheringRecord.DData;
    settings.mCleanup = pngCleanupRecord.DData;

    return 1;
  }

  int __stdcall setPngSettings(PngSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring pngEntry = registryKey + L"\\" + pngRoot;

    RegistryRecord pngEnabledRecord(pngEntry, pngEnabled, settings.mEnable);
    RegistryRecord pngBppRecord(pngEntry, pngBpp, settings.mBpp);
    RegistryRecord pngGrayscaleRecord(pngEntry, pngGrayscale, settings.mGrayscale);
    RegistryRecord pngDitheringRecord(pngEntry, pngDithering, settings.mDithering);
    RegistryRecord pngCleanupRecord(pngEntry, pngCleanup, settings.mCleanup);

    std::vector<RegistryRecord*> records;
    records.push_back(&pngEnabledRecord);
    records.push_back(&pngBppRecord);
    records.push_back(&pngGrayscaleRecord);
    records.push_back(&pngDitheringRecord);
    records.push_back(&pngCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removePngSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring pngEntry = registryKey + L"\\" + pngRoot;

    RegistryRecord pngEnabledRecord(pngEntry, pngEnabled, 0);
    RegistryRecord pngBppRecord(pngEntry, pngBpp, 24);
    RegistryRecord pngGrayscaleRecord(pngEntry, pngGrayscale, 0);
    RegistryRecord pngDitheringRecord(pngEntry, pngDithering, 0);
    RegistryRecord pngCleanupRecord(pngEntry, pngCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&pngEnabledRecord);
    records.push_back(&pngBppRecord);
    records.push_back(&pngGrayscaleRecord);
    records.push_back(&pngDitheringRecord);
    records.push_back(&pngCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
