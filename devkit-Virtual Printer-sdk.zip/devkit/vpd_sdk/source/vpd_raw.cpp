#include <vpd_raw.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const rawRoot = L"Converter\\RAW";
    std::wstring const rawEnabled = L"Enabled";
  }

  using namespace vpd::tools;

  int __stdcall getRawSettings(RawSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring rawEntry = registryKey + L"\\" + rawRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord rawEnabledRecord(rawEntry, rawEnabled, 0);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(rawEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(rawEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    settings.mEnable = rawEnabledRecord.DData;

    return 1;
  }

  int __stdcall setRawSettings(RawSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring rawEntry = registryKey + L"\\" + rawRoot;

    RegistryRecord rawEnabledRecord(rawEntry, rawEnabled, settings.mEnable);

    std::vector<RegistryRecord*> records;
    records.push_back(&rawEnabledRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeRawSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring rawEntry = registryKey + L"\\" + rawRoot;

    RegistryRecord rawEnabledRecord(rawEntry, rawEnabled, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&rawEnabledRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
