#include <vpd_printer.h>

namespace vpd{

  int __stdcall enumPrinters(PrinterLocation location, PrinterInfo *&printers, std::size_t &count){

    DWORD flag = 0;
    switch (location){
      case PrinterLocationLocal:
        flag = PRINTER_ENUM_LOCAL;
        break;

      case PrinterLocationNetwork:
        flag = PRINTER_ENUM_NETWORK;
        break;

      default:
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
    }
    
    DWORD needed = 0;
    DWORD elements = 0;

    if (!EnumPrinters(flag, NULL, 1, NULL, 0, &needed, &elements) && GetLastError() != ERROR_INSUFFICIENT_BUFFER)
      return 0;

    if (!needed){
      count = 0;
      return 1;
    }

    std::vector<BYTE> pinfo;

    try{
      pinfo.resize(needed);
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    if (!EnumPrinters(flag, NULL, 1, (BYTE *) &pinfo[0], needed, &needed, &elements))
      return 0;

    try{
      printers = new PrinterInfo[elements];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    PRINTER_INFO_1 *data = (PRINTER_INFO_1 *) &pinfo[0];
		for (std::size_t i = 0; i < elements; ++i)
      wcsncpy_s(printers[i].mName, data[i].pName, vpd::PrinterInfo::nameSize - 1);

    count = elements;

    return 1;
  }

  Printer::Printer(HANDLE handle)
    : mHandle(handle){
  }

  Printer::Printer(std::wstring const &pname, DWORD accessMask, DEVMODE *devmode)
    : mHandle(NULL){
    PRINTER_DEFAULTS pd = {NULL, devmode, accessMask};
    OpenPrinter((LPWSTR)pname.c_str(), &mHandle, &pd);
  }

  Printer::~Printer(void){
    if (mHandle)
      ClosePrinter(mHandle);
  }

  Printer::operator HANDLE(void) const{
    return mHandle;
  }

  Printer::operator bool(void) const{
    return mHandle != NULL;
  }

  void Printer::reset(HANDLE handle){
    if (mHandle)
      ClosePrinter(handle);

    mHandle = handle;
  }

  void Printer::reset(std::wstring const &pname, DWORD accessMask, DEVMODE *devmode){
    if (mHandle)
      ClosePrinter(mHandle);

    mHandle = Printer(pname, accessMask, devmode).release();
  }

  HANDLE Printer::release(void){
    HANDLE tmp = mHandle;
    mHandle = nullptr;
    return tmp;
  }

} // namespace vpd
