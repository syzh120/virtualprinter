#include <vpd_general.h>
#include <vpd_devmode.h>
#include <vpd_printer.h>
#include <vpd_tools.h>
#include <vpd_auto_ptr.h>
#include "vpd_internal_tools.h"

namespace vpd{

  int __stdcall getPaperOrientation(std::wstring const &pname, PaperOrientation &orientation){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    if (devmode->dmFields & DM_ORIENTATION){
      switch (devmode->dmOrientation){
        case DMORIENT_PORTRAIT:
          orientation = PaperOrientationPortrait;
          return 1;

        case DMORIENT_LANDSCAPE:
          orientation = PaperOrientationLandscape;
          return 1;
      }
    }

    SetLastError(ERROR_INVALID_DATA);
    return 0;
  }

  int __stdcall setPaperOrientation(std::wstring const &pname, PaperOrientation orientation){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    devmode->dmFields |= DM_ORIENTATION;
    switch (orientation){
      case PaperOrientationPortrait:
        devmode->dmOrientation = DMORIENT_PORTRAIT;
        break;

      case PaperOrientationLandscape:
        devmode->dmOrientation = DMORIENT_LANDSCAPE;
        break;

      default:
        return 0;
    }

    if (!setDevmode(pname, devmode))
      return 0;

    return 1;
  }

  int __stdcall enumPrintResolutions(std::wstring const &pname, PrintResolution *&resolutions, std::size_t &count){
    int elements = DeviceCapabilitiesW(pname.c_str(), NULL, DC_ENUMRESOLUTIONS, NULL, NULL);
    if (elements > 0){

      try{
        resolutions = new PrintResolution[elements];
        count = (std::size_t) elements;
      }
      catch(std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return 0;
      }

	    DeviceCapabilities(pname.c_str(), NULL, DC_ENUMRESOLUTIONS, (LPWSTR) resolutions, NULL);
      return 1;
    }

    return 0;
  }

  int __stdcall getPrintResolution(std::wstring const &pname, PrintResolution &resolution){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    if ((devmode->dmFields & DM_PRINTQUALITY) && (devmode->dmFields & DM_YRESOLUTION)){
      resolution.mDpiX = devmode->dmPrintQuality;
      resolution.mDpiY = devmode->dmYResolution;
      return 1;
    }
    else
      SetLastError(ERROR_INVALID_DATA);

    return 0;
  }

  int __stdcall setPrintResolution(std::wstring const &pname, PrintResolution const &resolution){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    devmode->dmFields |= (DM_PRINTQUALITY | DM_YRESOLUTION);
    devmode->dmPrintQuality = (short) resolution.mDpiX;
    devmode->dmYResolution = (short) resolution.mDpiY;

    if (!setDevmode(pname, devmode))
      return 0;

    return 1;
  }

  int __stdcall enumPaperForms(std::wstring const &pname, PaperForm *&forms, std::size_t &count, PaperSizeMeasure measure, PaperSizePrecision precision){
    int elements = 0;

    Printer printer(pname);
    if (!printer)
      return 0;

		std::vector<std::wstring> formNames;
    int result = tools::enumFormNames(pname, elements, formNames);
    if (!result)
      return 0;

    std::vector<WORD> formIds;
    result = tools::enumFormIds(pname, formIds);
    if (!result)
      return 0;

    double divider = (precision == PaperSizePrecisionNormal) ? 1000.f : 1.f;

    try{
      forms = new PaperForm[elements];
      count = (std::size_t) elements;
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    std::vector<BYTE> formInfo(128);
    DWORD formSize = 0;
    FORM_INFO_1 *ptr = 0;
    for (std::size_t i = 0; i < elements; ++i){

      if (!GetForm(printer, (LPWSTR) formNames[i].c_str(), 1, &formInfo[0], (DWORD) formInfo.size(), &formSize)){
        if (GetLastError() == ERROR_INSUFFICIENT_BUFFER){
          formInfo.resize(formSize);
          if (!GetForm(printer, (LPWSTR) formNames[i].c_str(), 1, &formInfo[0], (DWORD) formInfo.size(), &formSize))
            return 0;
        }
        else
          return 0;
      }

      if (!formSize)
        continue;

      ptr = (FORM_INFO_1*) &formInfo[0];

      wcsncpy_s(forms[i].mName, formNames[i].c_str(), PaperForm::paperFormSize - 1);
      forms[i].mId = formIds[i];
      if (measure == PaperSizeMeasureMetrics){
        forms[i].mWidth = ptr->Size.cx / divider;
        forms[i].mHeight = ptr->Size.cy / divider;
      }
      else{
        forms[i].mWidth = ptr->Size.cx / (25.4f * divider);
        forms[i].mHeight = ptr->Size.cy / (25.4f * divider);
      }

      forms[i].mMeasure = measure;
    }

    return 1;
  }

  int __stdcall getPaperForm(std::wstring const &pname, PaperForm &paperForm, PaperSizeMeasure measure, PaperSizePrecision precision){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    if ((devmode->dmFields & DM_PAPERSIZE) && (devmode->dmFields & DM_FORMNAME)){
      vpd::AutoReleasePtr<PaperForm> forms(0);
      std::size_t count = 0;
      int result = enumPaperForms(pname, forms.getRef(), count, measure, precision);
      if (!result)
        return 0;

      for (std::size_t i = 0; i < count; ++i)
        if (!wcscmp(forms[i].mName, devmode->dmFormName)){
          paperForm = forms[i];
          return 1;
        }
    }
    else
      SetLastError(ERROR_INVALID_DATA);
    return 0;
  }

  int __stdcall setPaperForm(std::wstring const &pname, PaperForm const &paperForm){
    std::vector<WORD> formIds;
    int result = tools::enumFormIds(pname, formIds);
    if (!result)
      return 0;

    int count = 0;
    std::vector<std::wstring> formNames;
  	result = tools::enumFormNames(pname, count, formNames);
    if (!result)
      return 0;

    WORD formId = 0;
    for (int i = 0; i < count; ++i){
      if (!wcscmp(formNames[i].c_str(), paperForm.mName)){
        formId = formIds[i];
        break;
      }
    }

    if (!formId)
      return 0;

    Devmode devmode(pname);
    if (!devmode)
      return 0;

    devmode->dmFields |= (DM_PAPERSIZE | DM_FORMNAME);
    devmode->dmPaperSize = formId;
    wcscpy_s((WCHAR*) &devmode->dmFormName, CCHFORMNAME, paperForm.mName);

    if (!setDevmode(pname, devmode))
      return 0;

    return 1;
  }

  int __stdcall addPaperForm(std::wstring const &pname, PaperForm const &paperForm){
    Printer printer(pname);
    if (!printer)
      return 0;

    double multiplierMm = (paperForm.mPrecision == PaperSizePrecisionNormal) ? 1000.f: 1.f;
    double multiplierInch = (paperForm.mPrecision == PaperSizePrecisionNormal) ? 25400.f: 25.4f;

    FORM_INFO_1 finfo = {0};
    finfo.pName = (WCHAR*)paperForm.mName;
    if (paperForm.mMeasure == PaperSizeMeasureMetrics){
		  finfo.Size.cx = finfo.ImageableArea.right = (LONG)(paperForm.mWidth * multiplierMm);
		  finfo.Size.cy = finfo.ImageableArea.bottom = (LONG)(paperForm.mHeight * multiplierMm);
    }
    else{
		  finfo.Size.cx = finfo.ImageableArea.right = (LONG)(paperForm.mWidth * multiplierInch);
		  finfo.Size.cy = finfo.ImageableArea.bottom = (LONG)(paperForm.mHeight * multiplierInch);
    }

    if (!AddForm(printer, 1, (BYTE*) &finfo))
      return 0;

    return 1;
  }

  int __stdcall removePaperForm(std::wstring const &pname, PaperForm const &paperForm){
    Printer printer(pname);
    if (!printer)
      return 0;

    if (!DeleteFormW(printer, (LPWSTR)paperForm.mName))
      return 0;

    return 1;
  }

  int __stdcall enumPaperBins(std::wstring const &pname, PaperBin *&paperBins, std::size_t &count){
    DWORD elements = DeviceCapabilities(pname.c_str(), NULL, DC_BINS, NULL, NULL);
    if (elements == -1)
      return 0;

    try{
      paperBins = new PaperBin[elements];
      count = (std::size_t) elements;
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    std::vector<WORD> bins;
    std::vector<WCHAR> binNames;

    if (!count)
      return 1;

    try{
      bins.resize(count);
      binNames.resize(24 * count);
    }
    catch(std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    if (DeviceCapabilities(pname.c_str(), NULL, DC_BINS,(LPTSTR) &bins[0], NULL) == -1
        || DeviceCapabilities(pname.c_str(), NULL, DC_BINNAMES, &binNames[0], NULL) == -1)
      return 0;

    try{
      for (std::size_t i = 0; i < count; ++i){
        paperBins[i].mBin = bins[i];
        wcsncpy_s(paperBins[i].mBinName, &binNames[i * 24], PaperBin::paperBinSize - 1);
      }
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    return 1;
  }

  int __stdcall getPaperBin(std::wstring const &pname, WORD &paperBin){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    if (devmode->dmFields & DM_DEFAULTSOURCE){
      paperBin = devmode->dmDefaultSource;
      return 1;
    }
    else
      SetLastError(ERROR_INVALID_DATA);

    return 0;
  }

  int __stdcall setPaperBin(std::wstring const &pname, WORD paperBin){
    Devmode devmode(pname);
    if (!devmode)
      return 0;

    devmode->dmFields |= DM_DEFAULTSOURCE;
    devmode->dmDefaultSource = paperBin;

    if (!setDevmode(pname, devmode))
      return 0;

    return 1;
  }


  int __stdcall enumFormInfo(std::wstring const &pname, FORM_INFO_1 *&info, std::size_t &count){
    vpd::Printer printer(pname);
    if (!printer)
      return 0;

    count = 0;
    DWORD needed = 0;
    DWORD elements = 0;
	  if (!EnumForms(printer, 1, NULL, 0, &needed, &elements) && GetLastError() != ERROR_INSUFFICIENT_BUFFER)
      return 0;

    if (!needed)
      return 1;

    try{
      info = (FORM_INFO_1*) new BYTE[needed];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    if (!EnumForms(printer, 1, (BYTE*) &info[0], needed, &needed, &elements))
      return 0;

    count = (std::size_t) elements;

    return 1;
  }

} // namespace vpd
