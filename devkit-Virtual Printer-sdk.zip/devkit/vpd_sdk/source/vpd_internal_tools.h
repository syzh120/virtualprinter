#pragma once

#include <Windows.h>
#include <vpd.h>

namespace vpd{

  namespace tools{

    /**
     * Gets supported paper form IDs for the specified printer
     * @param [in] pname printer name
     * @ids: paper form IDs
     * @return If the function succeeds, the result value is non-zero
     * @return If the function fails, the result value is zero and GetLastError() will return the error code.
     */
    int enumFormIds(std::wstring const &pname, std::vector<WORD> &ids);

    /**
     * Gets supported paper form names for the specified printer
     * @param [in] pname printer name
     * @param [out] count count of names
     * @formNames: paper names, each string buffer is 64 characters long
     * @return If the function succeeds, the result value is non-zero
     * @return If the function fails, the result value is zero and GetLastError() will return the error code.
     */
    int enumFormNames(std::wstring const &pname, int &count, std::vector<std::wstring> &formNames);

    /**
     * Gets supported paper form sizes for specified printer
     * @param [in] pname printer name
     * @sizes: paper sizes, in tenths of a millimeter
     * @return If the function succeeds, the result value is non-zero
     * @return If the function fails, the result value is zero and GetLastError() will return the error code.
     */
    int enumFormSizes(std::wstring const &pname, std::vector<POINT> &sizes);

    /**
      
     */

  } // namespace internal

} // namespace vpd
