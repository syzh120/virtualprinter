#include <vpd_devmode.h>
#include <vpd_printer.h>
#include <vpd_auto_ptr.h>
#include <vector>

namespace vpd{

  DEVMODE * __stdcall getDevmode(std::wstring const &pname){
    Printer printer(pname);
    if (!printer)
      return 0;

    DWORD size = 0;
    if (!GetPrinterW(printer, 2, NULL, 0, &size) && GetLastError() != ERROR_INSUFFICIENT_BUFFER || !size)
      return 0;

    std::vector<BYTE> pinfo(size);
    if (!GetPrinterW(printer, 2, &pinfo[0], size, &size))
      return 0;

    PRINTER_INFO_2 *pinfo2 = (PRINTER_INFO_2*)(&pinfo[0]);

    DEVMODE *devmode = 0;
    try{
      devmode = (DEVMODE*) new BYTE[pinfo2->pDevMode->dmSize];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    memcpy(devmode, pinfo2->pDevMode, pinfo2->pDevMode->dmSize);

    return devmode;
  }

  int __stdcall setDevmode(std::wstring const &pname, DEVMODE *devmode){
    vpd::Printer printer(pname);
    if (!printer)
      return 0;

    PRINTER_INFO_9 pinfo = {0};
    pinfo.pDevMode = devmode;

    if (!SetPrinterW(printer, 9, (BYTE*) &pinfo, 0))
      return 0;

    return 1;
  }

  void __stdcall releaseDevmode(DEVMODE *&devmode){
    delete[] devmode;
    devmode = NULL;
  }

} // namespace vpd
