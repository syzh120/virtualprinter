#include <vpd_enviroment_block.h>

namespace vpd{

  EnvironmentBlock::EnvironmentBlock(void)
    : mEnvBlock(0){
  }

  EnvironmentBlock::EnvironmentBlock(void *envBlock)
    : mEnvBlock(envBlock){
  }

  EnvironmentBlock::~EnvironmentBlock(void){
    if (mEnvBlock)
      DestroyEnvironmentBlock(mEnvBlock);
  }

  EnvironmentBlock::operator bool(void) const{
    return mEnvBlock != 0;
  }

  EnvironmentBlock::operator void *(void) const{
    return mEnvBlock;
  }

  void **EnvironmentBlock::operator&(void){
    return &mEnvBlock;
  }

  bool EnvironmentBlock::get_variable(std::wstring const &name, std::wstring &value) const{
    if (!mEnvBlock)
      return false;

    std::wstring str = name + L"=";
    std::size_t const len = str.length();

    WCHAR *ptr = (WCHAR*) mEnvBlock;
    while (wcslen(ptr) > 0){
      if (!wcsncmp(ptr, str.c_str(), len)){
        value = ptr + len;
        return true;
      }

      ptr += wcslen(ptr) + 1;
    }

    return false;
  }
}
