#include <vpd_bmp.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const bmpRoot = L"Converter\\BMP";
    std::wstring const bmpEnabled = L"Enabled";
    std::wstring const bmpBpp = L"Bits per pixel";
    std::wstring const bmpGrayscale = L"Grayscale";
    std::wstring const bmpDithering = L"Dithering";
    std::wstring const bmpCleanup = L"Cleanup";
  }

  using namespace vpd::tools;

  int __stdcall getBmpSettings(BmpSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring bmpEntry = registryKey + L"\\" + bmpRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord bmpEnabledRecord(bmpEntry, bmpEnabled, 0);
    RegistryRecord bmpBppRecord(bmpEntry, bmpBpp, 24);
    RegistryRecord bmpGrayscaleRecord(bmpEntry, bmpGrayscale, 0);
    RegistryRecord bmpDitheringRecord(bmpEntry, bmpDithering, 0);
    RegistryRecord bmpCleanupRecord(bmpEntry, bmpCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&bmpBppRecord);
    records.push_back(&bmpGrayscaleRecord);
    records.push_back(&bmpDitheringRecord);
    records.push_back(&bmpCleanupRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(bmpEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(bmpEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = bmpEnabledRecord.DData;
    settings.mBpp = (ImageBpp) bmpBppRecord.DData;
    settings.mGrayscale = bmpGrayscaleRecord.DData;
    settings.mDithering = (ImageDithering) bmpDitheringRecord.DData;
    settings.mCleanup = bmpCleanupRecord.DData;

    return 1;
  }

  int __stdcall setBmpSettings(BmpSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring bmpEntry = registryKey + L"\\" + bmpRoot;

    RegistryRecord bmpEnabledRecord(bmpEntry, bmpEnabled, settings.mEnable);
    RegistryRecord bmpBppRecord(bmpEntry, bmpBpp, settings.mBpp);
    RegistryRecord bmpGrayscaleRecord(bmpEntry, bmpGrayscale, settings.mGrayscale);
    RegistryRecord bmpDitheringRecord(bmpEntry, bmpDithering, settings.mDithering);
    RegistryRecord bmpCleanupRecord(bmpEntry, bmpCleanup, settings.mCleanup);

    std::vector<RegistryRecord*> records;
    records.push_back(&bmpEnabledRecord);
    records.push_back(&bmpBppRecord);
    records.push_back(&bmpGrayscaleRecord);
    records.push_back(&bmpDitheringRecord);
    records.push_back(&bmpCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeBmpSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring bmpEntry = registryKey + L"\\" + bmpRoot;

    RegistryRecord bmpEnabledRecord(bmpEntry, bmpEnabled, 0);
    RegistryRecord bmpBppRecord(bmpEntry, bmpBpp, 24);
    RegistryRecord bmpGrayscaleRecord(bmpEntry, bmpGrayscale, 0);
    RegistryRecord bmpDitheringRecord(bmpEntry, bmpDithering, 0);
    RegistryRecord bmpCleanupRecord(bmpEntry, bmpCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&bmpEnabledRecord);
    records.push_back(&bmpBppRecord);
    records.push_back(&bmpGrayscaleRecord);
    records.push_back(&bmpDitheringRecord);
    records.push_back(&bmpCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
