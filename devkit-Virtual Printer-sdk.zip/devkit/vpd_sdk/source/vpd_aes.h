#pragma once

#include <string>

namespace vpd{
  namespace tools{

  /**
   * Encrypts an input string with using AES algorithm
   * @input input string
   * @output encoded string with HEX filter
   */
  void aes_encrypt(std::string const &input, std::string &output);
  void aes_encrypt(std::wstring const &input, std::wstring &output);

  /**
   * Decrypts an input string with using AES algorithm
   * @intput input string with HEX filter
   * output decoded string
   */
  void aes_decrypt(std::string const &input, std::string &output);
  void aes_decrypt(std::wstring const &input, std::wstring &output);

  }// namespace tools
}// namespace vpd
