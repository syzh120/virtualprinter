#include <vpd_ini.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const iniRoot = L"Converter\\INI";
    std::wstring const iniEnabled = L"Enabled";
    std::wstring const iniDuplicate = L"Duplicate";
  }

  using namespace vpd::tools;

  int __stdcall getIniSettings(IniSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring iniEntry = registryKey + L"\\" + iniRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord iniEnabledRecord(iniEntry, iniEnabled, 0);
    RegistryRecord iniDuplicateRecord(iniEntry, iniDuplicate, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&iniDuplicateRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(iniEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(iniEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else if ((hive & REGISTRY_HKU) && getRegistryRecord(iniEnabledRecord, HKEY_USERS))
      regHive = HKEY_USERS;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = iniEnabledRecord.DData;
    settings.mDuplicate = iniDuplicateRecord.DData;

    return 1;
  }

  int __stdcall setIniSettings(IniSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring iniEntry = registryKey + L"\\" + iniRoot;

    RegistryRecord iniEnabledRecord(iniEntry, iniEnabled, settings.mEnable);
    RegistryRecord iniDuplicateRecord(iniEntry, iniDuplicate, settings.mDuplicate);

    std::vector<RegistryRecord*> records;
    records.push_back(&iniEnabledRecord);
    records.push_back(&iniDuplicateRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeIniSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring iniEntry = registryKey + L"\\" + iniRoot;

    RegistryRecord iniEnabledRecord(iniEntry, iniEnabled, 0);
    RegistryRecord iniDuplicateRecord(iniEntry, iniDuplicate, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&iniEnabledRecord);
    records.push_back(&iniDuplicateRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
