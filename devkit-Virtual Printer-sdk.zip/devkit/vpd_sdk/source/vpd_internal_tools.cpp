#include "vpd_internal_tools.h"

namespace vpd{

  namespace tools{

    int enumFormIds(std::wstring const &pname, std::vector<WORD> &ids){
      int count = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERS, NULL, NULL);
      if (!count)
        return 0;

      int result = 0;

      try{
        ids.resize(count);
        result = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERS, (LPWSTR) &ids[0], NULL);
        if (result <= 0)
          return 0;
      }
      catch (std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return 0;
      }

      return 1;
    }

    int enumFormNames(std::wstring const &pname, int &count, std::vector<std::wstring> &formNames){
      count = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERS, NULL, NULL);
      if (!count)
        return 0;

      std::vector<WCHAR> names;
      try{
        names.resize(count * 64, 0);
  	    int result = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERNAMES, (LPWSTR) &names[0], NULL);
        if (result <= 0)
          return 0;

        formNames.clear();
        for (std::size_t i = 0; i < count; ++i)
          formNames.push_back(std::wstring(&names[i * 64], &names[i * 64] + __min(wcslen(&names[i * 64]), 64)));
      }
      catch (std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return 0;
      }

      return 1;
    }

    int enumFormSizes(std::wstring const &pname, std::vector<POINT> &sizes){
      int count = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERS, NULL, NULL);
      if (!count)
        return 0;

      try{
		    sizes.resize(count);
		    int result = DeviceCapabilitiesW(pname.c_str(), NULL, DC_PAPERSIZE, (LPWSTR) &sizes[0], NULL);
        if (result <= 0)
          return 0;
      }
      catch (std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return 0;
      }

      return 1;
    }

  } // namespace tools

} // namespace vpd
