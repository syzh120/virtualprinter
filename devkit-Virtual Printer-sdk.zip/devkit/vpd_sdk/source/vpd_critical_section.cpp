#include <vpd_critical_section.h>

namespace vpd{

  CriticalSection::CriticalSection(void) throw(){
    InitializeCriticalSection(&mCS);
  }

  CriticalSection::~CriticalSection(void) throw(){
    DeleteCriticalSection(&mCS);
  }

  void CriticalSection::lock(void){
    EnterCriticalSection(&mCS);
  }

  void CriticalSection::unlock(void){
    LeaveCriticalSection(&mCS);
  }

  AutoReleaseCS::AutoReleaseCS(CriticalSection *cs) throw()
    :mCS(cs){
    if (mCS)
      mCS->lock();
  }

  AutoReleaseCS::~AutoReleaseCS(void) throw(){
    if (mCS)
      mCS->unlock();
  }

  void AutoReleaseCS::release(void) throw(){
    if (mCS)
      mCS->unlock();
    mCS = 0;
  }

}
