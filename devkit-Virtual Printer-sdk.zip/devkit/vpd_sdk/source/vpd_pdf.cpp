#include <vpd_pdf.h>
#include <vpd_regtools.h>
#include "vpd_aes.h"

namespace vpd{

  namespace{
    std::wstring const pdfRoot = L"Converter\\PDF";
    std::wstring const pdfEnabled = L"Enabled";
    std::wstring const pdfMultipage = L"Multipage";
    std::wstring const pdfProducePdfA = L"Produce PDFA";
    std::wstring const pdfTimezone = L"Timezone";
    std::wstring const pdfUseMThread = L"Use mthread";
    std::wstring const pdfPageLayout = L"Page Layout";
    std::wstring const pdfPageMode = L"Page Mode";
    std::wstring const pdfSecurityEnabled = L"Security Enabled";
    std::wstring const pdfEncryptionLevel = L"Encryption Level";
    std::wstring const pdfUserPasswordEnabled = L"User Password Enabled";
    std::wstring const pdfUserPassword = L"User Password";
    std::wstring const pdfOwnerPasswordEnabled = L"Owner Password Enabled";
    std::wstring const pdfOwnerPassword = L"Owner Password";
    std::wstring const pdfAllowCopying = L"Allow Copying";
    std::wstring const pdfAllowCommenting = L"Allow Commenting";
    std::wstring const pdfAllowChanging = L"Allow Changing";
    std::wstring const pdfAllowPrinting = L"Allow Printing";
    std::wstring const pdfTitle = L"Title";
    std::wstring const pdfAuthor = L"Author";
    std::wstring const pdfProducer = L"Producer";
    std::wstring const pdfCreator = L"Creator";
    std::wstring const pdfSubject = L"Subject";
    std::wstring const pdfKeywords = L"Keywords";
    std::wstring const pdfCleanup = L"Cleanup";
    std::wstring const pdfUseDocumentName = L"Use Document Name";
    std::wstring const pdfImageQuality = L"Image Quality";
    std::wstring const pdfBlackAndWhite = L"Black and White";
    std::wstring const pdfNonChunked = L"Non Chunked";
  }

  using namespace vpd::tools;

  int __stdcall getPdfSettings(PdfSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring pdfEntry = registryKey + L"\\" + pdfRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord pdfEnabledRecord(pdfEntry, pdfEnabled, 0);
    RegistryRecord pdfMultipageRecord(pdfEntry, pdfMultipage, 1);
    RegistryRecord pdfProducePdfARecord(pdfEntry, pdfProducePdfA, 0);
    RegistryRecord pdfTimezoneRecord(pdfEntry, pdfTimezone, 0);
    RegistryRecord pdfUseMThreadRecord(pdfEntry, pdfUseMThread, 1);
    RegistryRecord pdfPageLayoutRecord(pdfEntry, pdfPageLayout, 0);
    RegistryRecord pdfPageModeRecord(pdfEntry, pdfPageMode, 0);
    RegistryRecord pdfSecurityEnabledRecord(pdfEntry, pdfSecurityEnabled, 0);
    RegistryRecord pdfEncryptionLevelRecord(pdfEntry, pdfEncryptionLevel, 0);
    RegistryRecord pdfUserPasswordEnabledRecord(pdfEntry, pdfUserPasswordEnabled, 0);
    RegistryRecord pdfUserPasswordRecord(pdfEntry, pdfUserPassword, L"");
    RegistryRecord pdfOwnerPasswordEnabledRecord(pdfEntry, pdfOwnerPasswordEnabled, 0);
    RegistryRecord pdfOwnerPasswordRecord(pdfEntry, pdfOwnerPassword, L"");
    RegistryRecord pdfAllowCopyingRecord(pdfEntry, pdfAllowCopying, 0);
    RegistryRecord pdfAllowCommentingRecord(pdfEntry, pdfAllowCommenting, 0);
    RegistryRecord pdfAllowChangingRecord(pdfEntry, pdfAllowChanging, 0);
    RegistryRecord pdfAllowPrintingRecord(pdfEntry, pdfAllowPrinting, 0);
    RegistryRecord pdfTitleRecord(pdfEntry, pdfTitle, L"");
    RegistryRecord pdfAuthorRecord(pdfEntry, pdfAuthor, L"");
    RegistryRecord pdfProducerRecord(pdfEntry, pdfProducer, L"");
    RegistryRecord pdfCreatorRecord(pdfEntry, pdfCreator, L"");
    RegistryRecord pdfSubjectRecord(pdfEntry, pdfSubject, L"");
    RegistryRecord pdfKeywordsRecord(pdfEntry, pdfKeywords, L"");
    RegistryRecord pdfCleanupRecord(pdfEntry, pdfCleanup, 0);
    RegistryRecord pdfUseDocumentNameRecord(pdfEntry, pdfUseDocumentName, 0);
    RegistryRecord pdfImageQualityRecord(pdfEntry, pdfImageQuality, 80);
    RegistryRecord pdfBlackAndWhiteRecord(pdfEntry, pdfBlackAndWhite, 0);
    RegistryRecord pdfNonChunkedRecord(pdfEntry, pdfNonChunked, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&pdfMultipageRecord);
    records.push_back(&pdfProducePdfARecord);
    records.push_back(&pdfTimezoneRecord);
    records.push_back(&pdfUseMThreadRecord);
    records.push_back(&pdfPageLayoutRecord);
    records.push_back(&pdfPageModeRecord);
    records.push_back(&pdfSecurityEnabledRecord);
    records.push_back(&pdfEncryptionLevelRecord);
    records.push_back(&pdfUserPasswordEnabledRecord);
    records.push_back(&pdfUserPasswordRecord);
    records.push_back(&pdfOwnerPasswordEnabledRecord);
    records.push_back(&pdfOwnerPasswordRecord);
    records.push_back(&pdfAllowCopyingRecord);
    records.push_back(&pdfAllowCommentingRecord);
    records.push_back(&pdfAllowChangingRecord);
    records.push_back(&pdfAllowPrintingRecord);
    records.push_back(&pdfTitleRecord);
    records.push_back(&pdfAuthorRecord);
    records.push_back(&pdfProducerRecord);
    records.push_back(&pdfCreatorRecord);
    records.push_back(&pdfSubjectRecord);
    records.push_back(&pdfKeywordsRecord);
    records.push_back(&pdfCleanupRecord);
    records.push_back(&pdfUseDocumentNameRecord);
    records.push_back(&pdfImageQualityRecord);
    records.push_back(&pdfBlackAndWhiteRecord);
    records.push_back(&pdfNonChunkedRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(pdfEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(pdfEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = pdfEnabledRecord.DData;
    settings.mMultipage = pdfMultipageRecord.DData;
    settings.mProducePdfA = pdfProducePdfARecord.DData;
    settings.mTimezone = (Timezone)pdfTimezoneRecord.DData;
    settings.mUseMthread = pdfUseMThreadRecord.DData;
    settings.mPageLayout = (PageLayout)pdfPageLayoutRecord.DData;
    settings.mPageMode = (PageMode)pdfPageModeRecord.DData;
    settings.mSecured = pdfSecurityEnabledRecord.DData;
    settings.mEncryptionLevel = (EncryptionLevel)pdfEncryptionLevelRecord.DData;
    settings.mEnableUserPassword = pdfUserPasswordEnabledRecord.DData;

    std::wstring userPassword;
    vpd::tools::aes_decrypt(pdfUserPasswordRecord.SData, userPassword);
    wcsncpy_s(settings.mUserPassword, userPassword.c_str(), vpd::PdfSettings::userPasswordSize - 1);

    settings.mEnableOwnerPassword = pdfOwnerPasswordEnabledRecord.DData;

    std::wstring ownerPassword;
    vpd::tools::aes_decrypt(pdfOwnerPasswordRecord.SData, ownerPassword);
    wcsncpy_s(settings.mOwnerPassword, ownerPassword.c_str(), vpd::PdfSettings::ownerPasswordSize - 1);

    settings.mAllowCopying = pdfAllowCopyingRecord.DData;
    settings.mAllowCommenting = pdfAllowCommentingRecord.DData;
    settings.mAllowChanging = pdfAllowChangingRecord.DData;
    settings.mAllowPrinting = pdfAllowPrintingRecord.DData;
    wcsncpy_s(settings.mTitle, pdfTitleRecord.SData.c_str(), PdfSettings::titleSize - 1);
    wcsncpy_s(settings.mAuthor, pdfAuthorRecord.SData.c_str(), PdfSettings::authorSize - 1);
    wcsncpy_s(settings.mProducer, pdfProducerRecord.SData.c_str(), PdfSettings::producerSize - 1);
    wcsncpy_s(settings.mCreator, pdfCreatorRecord.SData.c_str(), PdfSettings::creatorSize - 1);
    wcsncpy_s(settings.mSubject, pdfSubjectRecord.SData.c_str(), PdfSettings::subjectSize - 1);
    wcsncpy_s(settings.mKeywords, pdfKeywordsRecord.SData.c_str(), PdfSettings::keywordsSize - 1);
    settings.mCleanup = pdfCleanupRecord.DData;
    settings.mUseDocumentName = pdfUseDocumentNameRecord.DData;

    settings.mImageQuality = pdfImageQualityRecord.DData;
    settings.mBlackAndWhite = pdfBlackAndWhiteRecord.DData;
    settings.mNonChunked = pdfNonChunkedRecord.DData;

    return 1;
  }

  int __stdcall setPdfSettings(PdfSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring pdfEntry = registryKey + L"\\" + pdfRoot;

    RegistryRecord pdfEnabledRecord(pdfEntry, pdfEnabled, settings.mEnable);
    RegistryRecord pdfMultipageRecord(pdfEntry, pdfMultipage, settings.mMultipage);
    RegistryRecord pdfProducePdfARecord(pdfEntry, pdfProducePdfA, settings.mProducePdfA);
    RegistryRecord pdfTimezoneRecord(pdfEntry, pdfTimezone, settings.mTimezone);
    RegistryRecord pdfUseMThreadRecord(pdfEntry, pdfUseMThread, settings.mUseMthread);
    RegistryRecord pdfPageLayoutRecord(pdfEntry, pdfPageLayout, settings.mPageLayout);
    RegistryRecord pdfPageModeRecord(pdfEntry, pdfPageMode, settings.mPageMode);
    RegistryRecord pdfSecurityEnabledRecord(pdfEntry, pdfSecurityEnabled, settings.mSecured);
    RegistryRecord pdfEncryptionLevelRecord(pdfEntry, pdfEncryptionLevel, settings.mEncryptionLevel);
    RegistryRecord pdfUserPasswordEnabledRecord(pdfEntry, pdfUserPasswordEnabled, settings.mEnableUserPassword);

    std::wstring userPassword;
    vpd::tools::aes_encrypt(settings.mUserPassword, userPassword);
    RegistryRecord pdfUserPasswordRecord(pdfEntry, pdfUserPassword, userPassword);

    RegistryRecord pdfOwnerPasswordEnabledRecord(pdfEntry, pdfOwnerPasswordEnabled, settings.mEnableOwnerPassword);

    std::wstring ownerPassword;
    vpd::tools::aes_encrypt(settings.mOwnerPassword, ownerPassword);
    RegistryRecord pdfOwnerPasswordRecord(pdfEntry, pdfOwnerPassword, ownerPassword);

    RegistryRecord pdfAllowCopyingRecord(pdfEntry, pdfAllowCopying, settings.mAllowCopying);
    RegistryRecord pdfAllowCommentingRecord(pdfEntry, pdfAllowCommenting, settings.mAllowCommenting);
    RegistryRecord pdfAllowChangingRecord(pdfEntry, pdfAllowChanging, settings.mAllowChanging);
    RegistryRecord pdfAllowPrintingRecord(pdfEntry, pdfAllowPrinting, settings.mAllowPrinting);
    RegistryRecord pdfTitleRecord(pdfEntry, pdfTitle, settings.mTitle);
    RegistryRecord pdfAuthorRecord(pdfEntry, pdfAuthor, settings.mAuthor);
    RegistryRecord pdfProducerRecord(pdfEntry, pdfProducer, settings.mProducer);
    RegistryRecord pdfCreatorRecord(pdfEntry, pdfCreator, settings.mCreator);
    RegistryRecord pdfSubjectRecord(pdfEntry, pdfSubject, settings.mSubject);
    RegistryRecord pdfKeywordsRecord(pdfEntry, pdfKeywords, settings.mKeywords);
    RegistryRecord pdfCleanupRecord(pdfEntry, pdfCleanup, settings.mCleanup);
    RegistryRecord pdfUseDocumentNameRecord(pdfEntry, pdfUseDocumentName, settings.mUseDocumentName);

    RegistryRecord pdfImageQualityRecord(pdfEntry, pdfImageQuality, settings.mImageQuality);
    RegistryRecord pdfBlackAndWhiteRecord(pdfEntry, pdfBlackAndWhite, settings.mBlackAndWhite);

    RegistryRecord pdfNonChunkedRecord(pdfEntry, pdfNonChunked, settings.mNonChunked);

    std::vector<RegistryRecord*> records;
    records.push_back(&pdfEnabledRecord);
    records.push_back(&pdfMultipageRecord);
    records.push_back(&pdfProducePdfARecord);
    records.push_back(&pdfTimezoneRecord);
    records.push_back(&pdfUseMThreadRecord);
    records.push_back(&pdfPageLayoutRecord);
    records.push_back(&pdfPageModeRecord);
    records.push_back(&pdfSecurityEnabledRecord);
    records.push_back(&pdfEncryptionLevelRecord);
    records.push_back(&pdfUserPasswordEnabledRecord);
    records.push_back(&pdfUserPasswordRecord);
    records.push_back(&pdfOwnerPasswordEnabledRecord);
    records.push_back(&pdfOwnerPasswordRecord);
    records.push_back(&pdfAllowCopyingRecord);
    records.push_back(&pdfAllowCommentingRecord);
    records.push_back(&pdfAllowChangingRecord);
    records.push_back(&pdfAllowPrintingRecord);
    records.push_back(&pdfTitleRecord);
    records.push_back(&pdfAuthorRecord);
    records.push_back(&pdfProducerRecord);
    records.push_back(&pdfCreatorRecord);
    records.push_back(&pdfSubjectRecord);
    records.push_back(&pdfKeywordsRecord);
    records.push_back(&pdfCleanupRecord);
    records.push_back(&pdfUseDocumentNameRecord);
    records.push_back(&pdfImageQualityRecord);
    records.push_back(&pdfBlackAndWhiteRecord);
    records.push_back(&pdfNonChunkedRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removePdfSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring pdfEntry = registryKey + L"\\" + pdfRoot;

    RegistryRecord pdfEnabledRecord(pdfEntry, pdfEnabled, 0);
    RegistryRecord pdfMultipageRecord(pdfEntry, pdfMultipage, 1);
    RegistryRecord pdfProducePdfARecord(pdfEntry, pdfProducePdfA, 0);
    RegistryRecord pdfTimezoneRecord(pdfEntry, pdfTimezone, 0);
    RegistryRecord pdfUseMThreadRecord(pdfEntry, pdfUseMThread, 1);
    RegistryRecord pdfPageLayoutRecord(pdfEntry, pdfPageLayout, 0);
    RegistryRecord pdfPageModeRecord(pdfEntry, pdfPageMode, 0);
    RegistryRecord pdfSecurityEnabledRecord(pdfEntry, pdfSecurityEnabled, 0);
    RegistryRecord pdfEncryptionLevelRecord(pdfEntry, pdfEncryptionLevel, 0);
    RegistryRecord pdfUserPasswordEnabledRecord(pdfEntry, pdfUserPasswordEnabled, 0);
    RegistryRecord pdfUserPasswordRecord(pdfEntry, pdfUserPassword, L"");
    RegistryRecord pdfOwnerPasswordEnabledRecord(pdfEntry, pdfOwnerPasswordEnabled, 0);
    RegistryRecord pdfOwnerPasswordRecord(pdfEntry, pdfOwnerPassword, L"");
    RegistryRecord pdfAllowCopyingRecord(pdfEntry, pdfAllowCopying, 0);
    RegistryRecord pdfAllowCommentingRecord(pdfEntry, pdfAllowCommenting, 0);
    RegistryRecord pdfAllowChangingRecord(pdfEntry, pdfAllowChanging, 0);
    RegistryRecord pdfAllowPrintingRecord(pdfEntry, pdfAllowPrinting, 0);
    RegistryRecord pdfTitleRecord(pdfEntry, pdfTitle, L"");
    RegistryRecord pdfAuthorRecord(pdfEntry, pdfAuthor, L"");
    RegistryRecord pdfProducerRecord(pdfEntry, pdfProducer, L"");
    RegistryRecord pdfCreatorRecord(pdfEntry, pdfCreator, L"");
    RegistryRecord pdfSubjectRecord(pdfEntry, pdfSubject, L"");
    RegistryRecord pdfKeywordsRecord(pdfEntry, pdfKeywords, L"");
    RegistryRecord pdfCleanupRecord(pdfEntry, pdfCleanup, 0);
    RegistryRecord pdfUseDocumentNameRecord(pdfEntry, pdfUseDocumentName, 0);
    RegistryRecord pdfImageQualityRecord(pdfEntry, pdfImageQuality, 80);
    RegistryRecord pdfBlackAndWhiteRecord(pdfEntry, pdfBlackAndWhite, 0);
    RegistryRecord pdfNonChunkedRecord(pdfEntry, pdfNonChunked, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&pdfEnabledRecord);
    records.push_back(&pdfMultipageRecord);
    records.push_back(&pdfProducePdfARecord);
    records.push_back(&pdfTimezoneRecord);
    records.push_back(&pdfUseMThreadRecord);
    records.push_back(&pdfPageLayoutRecord);
    records.push_back(&pdfPageModeRecord);
    records.push_back(&pdfSecurityEnabledRecord);
    records.push_back(&pdfEncryptionLevelRecord);
    records.push_back(&pdfUserPasswordEnabledRecord);
    records.push_back(&pdfUserPasswordRecord);
    records.push_back(&pdfOwnerPasswordEnabledRecord);
    records.push_back(&pdfOwnerPasswordRecord);
    records.push_back(&pdfAllowCopyingRecord);
    records.push_back(&pdfAllowCommentingRecord);
    records.push_back(&pdfAllowChangingRecord);
    records.push_back(&pdfAllowPrintingRecord);
    records.push_back(&pdfTitleRecord);
    records.push_back(&pdfAuthorRecord);
    records.push_back(&pdfProducerRecord);
    records.push_back(&pdfCreatorRecord);
    records.push_back(&pdfSubjectRecord);
    records.push_back(&pdfKeywordsRecord);
    records.push_back(&pdfCleanupRecord);
    records.push_back(&pdfUseDocumentNameRecord);
    records.push_back(&pdfImageQualityRecord);
    records.push_back(&pdfBlackAndWhiteRecord);
    records.push_back(&pdfNonChunkedRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
