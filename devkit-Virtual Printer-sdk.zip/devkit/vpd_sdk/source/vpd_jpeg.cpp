#include <vpd_jpeg.h>

#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const jpegRoot = L"Converter\\JPEG";
    std::wstring const jpegEnabled = L"Enabled";
    std::wstring const jpegGrayscale = L"Grayscale";
    std::wstring const jpegQuality = L"Quality";
    std::wstring const jpegCleanup = L"Cleanup";
  }

  using namespace vpd::tools;

  int __stdcall getJpegSettings(JpegSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring jpegEntry = registryKey + L"\\" + jpegRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord jpegEnabledRecord(jpegEntry, jpegEnabled, 0);
    RegistryRecord jpegGrayscaleRecord(jpegEntry, jpegGrayscale, 0);
    RegistryRecord jpegQualityRecord(jpegEntry, jpegQuality, 80);
    RegistryRecord jpegCleanupRecord(jpegEntry, jpegCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&jpegGrayscaleRecord);
    records.push_back(&jpegQualityRecord);
    records.push_back(&jpegCleanupRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(jpegEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(jpegEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = jpegEnabledRecord.DData;
    settings.mGrayscale = jpegGrayscaleRecord.DData;
    settings.mQuality = jpegQualityRecord.DData;
    settings.mCleanup = jpegCleanupRecord.DData;

    return 1;
  }

  int __stdcall setJpegSettings(JpegSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring jpegEntry = registryKey + L"\\" + jpegRoot;

    RegistryRecord jpegEnabledRecord(jpegEntry, jpegEnabled, settings.mEnable);
    RegistryRecord jpegGrayscaleRecord(jpegEntry, jpegGrayscale, settings.mGrayscale);
    RegistryRecord jpegQualityRecord(jpegEntry, jpegQuality, settings.mQuality);
    RegistryRecord jpegCleanupRecord(jpegEntry, jpegCleanup, settings.mCleanup);

    std::vector<RegistryRecord*> records;
    records.push_back(&jpegEnabledRecord);
    records.push_back(&jpegGrayscaleRecord);
    records.push_back(&jpegQualityRecord);
    records.push_back(&jpegCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeJpegSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring jpegEntry = registryKey + L"\\" + jpegRoot;

    RegistryRecord jpegEnabledRecord(jpegEntry, jpegEnabled, 0);
    RegistryRecord jpegGrayscaleRecord(jpegEntry, jpegGrayscale, 0);
    RegistryRecord jpegQualityRecord(jpegEntry, jpegQuality, 0);
    RegistryRecord jpegCleanupRecord(jpegEntry, jpegCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&jpegEnabledRecord);
    records.push_back(&jpegGrayscaleRecord);
    records.push_back(&jpegQualityRecord);
    records.push_back(&jpegCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
