#include <vpd_ftp.h>
#include <vpd_regtools.h>
#include "vpd_aes.h"

namespace vpd{

  namespace{
    std::wstring const ftpRoot = L"Converter\\FTP";
    std::wstring const ftpEnabled = L"Enabled";
    std::wstring const ftpUrl = L"Url";
    std::wstring const ftpUname = L"User Name";
    std::wstring const ftpPassword = L"Password";
    std::wstring const ftpUploadConfig = L"Upload";
    std::wstring const ftpEncrypted = L"Encrypted";
    std::wstring const ftpAttempts = L"Attempts";
    std::wstring const ftpIgnoreCertError = L"Ignore certificate error";
  }

  using namespace vpd::tools;

  int __stdcall getFtpSettings(FtpSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring ftpEntry = registryKey + L"\\" + ftpRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord ftpEnabledRecord(ftpEntry, ftpEnabled, 0);
    RegistryRecord ftpUrlRecord(ftpEntry, ftpUrl, L"");
    RegistryRecord ftpUnameRecord(ftpEntry, ftpUname, L"");
    RegistryRecord ftpPasswordRecord(ftpEntry, ftpPassword, L"");
    RegistryRecord ftpUploadConfigRecord(ftpEntry, ftpUploadConfig, L"");
    RegistryRecord ftpEncryptedRecord(ftpEntry, ftpEncrypted, 0);
    RegistryRecord ftpAttemptsRecord(ftpEntry, ftpAttempts, 1);
    RegistryRecord ftpIgnoreCertErrorRecord(ftpEntry, ftpIgnoreCertError, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&ftpUrlRecord);
    records.push_back(&ftpUnameRecord);
    records.push_back(&ftpPasswordRecord);
    records.push_back(&ftpUploadConfigRecord);
    records.push_back(&ftpEncryptedRecord);
    records.push_back(&ftpAttemptsRecord);
    records.push_back(&ftpIgnoreCertErrorRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(ftpEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(ftpEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = ftpEnabledRecord.DData;
    wcsncpy_s(settings.mUrl, ftpUrlRecord.SData.c_str(), FtpSettings::urlSize - 1);
    wcsncpy_s(settings.mUploadConfig, ftpUploadConfigRecord.SData.c_str(), FtpSettings::uploadConfigSize - 1);
    settings.mEncrypted = ftpEncryptedRecord.DData;

    if (settings.mEncrypted){
      std::wstring userName;
      vpd::tools::aes_decrypt(ftpUnameRecord.SData, userName);
      wcsncpy_s(settings.mUserName, userName.c_str(), FtpSettings::userNameSize - 1);

      std::wstring userPassword;
      vpd::tools::aes_decrypt(ftpPasswordRecord.SData, userPassword);
      wcsncpy_s(settings.mPassword, userPassword.c_str(), FtpSettings::passwordSize - 1);
    }
    else{
      wcsncpy_s(settings.mUserName, ftpUnameRecord.SData.c_str(), FtpSettings::userNameSize - 1);
      wcsncpy_s(settings.mPassword, ftpPasswordRecord.SData.c_str(), FtpSettings::passwordSize - 1);
    }

    settings.mAttempts = ftpAttemptsRecord.DData;
    settings.mIgnoreCertError = ftpIgnoreCertErrorRecord.DData;
    return 1;
  }

  int __stdcall setFtpSettings(FtpSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring ftpEntry = registryKey + L"\\" + ftpRoot;

    RegistryRecord ftpEnabledRecord(ftpEntry, ftpEnabled, settings.mEnable);
    RegistryRecord ftpUrlRecord(ftpEntry, ftpUrl, settings.mUrl);
    RegistryRecord ftpUploadConfigRecord(ftpEntry, ftpUploadConfig, settings.mUploadConfig);
    RegistryRecord ftpEncryptedRecord(ftpEntry, ftpEncrypted, settings.mEncrypted);
    RegistryRecord ftpAttemptsRecord(ftpEntry, ftpAttempts, settings.mAttempts);
    RegistryRecord ftpIgnoreCertErrorRecord(ftpEntry, ftpIgnoreCertError, settings.mIgnoreCertError);

    std::wstring userName = settings.mUserName;
    std::wstring userPassword = settings.mPassword;

    if (settings.mEncrypted){
      vpd::tools::aes_encrypt(settings.mUserName, userName);
      vpd::tools::aes_encrypt(settings.mPassword, userPassword);
    }

    RegistryRecord ftpUnameRecord(ftpEntry, ftpUname, userName);
    RegistryRecord ftpPasswordRecord(ftpEntry, ftpPassword, userPassword);

    std::vector<RegistryRecord*> records;
    records.push_back(&ftpEnabledRecord);
    records.push_back(&ftpUrlRecord);
    records.push_back(&ftpUnameRecord);
    records.push_back(&ftpPasswordRecord);
    records.push_back(&ftpUploadConfigRecord);
    records.push_back(&ftpEncryptedRecord);
    records.push_back(&ftpAttemptsRecord);
    records.push_back(&ftpIgnoreCertErrorRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeFtpSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring ftpEntry = registryKey + L"\\" + ftpRoot;

    RegistryRecord ftpEnabledRecord(ftpEntry, ftpEnabled, 0);
    RegistryRecord ftpUrlRecord(ftpEntry, ftpUrl, L"");
    RegistryRecord ftpUnameRecord(ftpEntry, ftpUname, L"");
    RegistryRecord ftpPasswordRecord(ftpEntry, ftpPassword, L"");
    RegistryRecord ftpUploadConfigRecord(ftpEntry, ftpUploadConfig, L"");
    RegistryRecord ftpEncryptedRecord(ftpEntry, ftpEncrypted, 0);
    RegistryRecord ftpAttemptsRecord(ftpEntry, ftpAttempts, 0);
    RegistryRecord ftpIgnoreCertErrorRecord(ftpEntry, ftpIgnoreCertError, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&ftpEnabledRecord);
    records.push_back(&ftpUrlRecord);
    records.push_back(&ftpUnameRecord);
    records.push_back(&ftpPasswordRecord);
    records.push_back(&ftpUploadConfigRecord);
    records.push_back(&ftpEncryptedRecord);
    records.push_back(&ftpAttemptsRecord);
    records.push_back(&ftpIgnoreCertErrorRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
