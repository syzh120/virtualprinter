#include <vpd_Application.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const preprocessorRoot = L"Application\\Preprocessor";
    std::wstring const preconverterRoot = L"Application\\Preconverter";
    std::wstring const postconverterRoot = L"Application\\Postconverter";

    std::wstring const applicationEnabled = L"Enabled";
    std::wstring const applicationEarlyAccess = L"Early Access";
    std::wstring const applicationPath = L"Executable File";
    std::wstring const applicationSkipMode = L"Skip Mode";
    std::wstring const applicationTimeout = L"Timeout";
    std::wstring const applicationTransferMode = L"Transfer Mode";
    std::wstring const applicationWindowTitle = L"Window Title";
    std::wstring const applicationWindowClass = L"Window Class";
    std::wstring const applicationMessageId = L"Message Id";
    std::wstring const applicationNotifyAll = L"Notify All";
    std::wstring const applicationPipeName = L"Pipe Name";
    std::wstring const applicationPipeMessageSize = L"Pipe Message Size";
    std::wstring const applicationPipeLaunchApplication = L"Pipe Launch Application";
  }

  using namespace vpd::tools;

  int __stdcall getApplicationSettings(ApplicationType type, ApplicationSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring applicationEntry = registryKey + L"\\";
    switch (type){
      case ApplicationTypePreprocessor:
        applicationEntry += preprocessorRoot;
        break;

      case ApplicationTypePreconverter:
        applicationEntry += preconverterRoot;
        break;

      case ApplicationTypePostconverter:
        applicationEntry += postconverterRoot;
        break;
    }

    memset(&settings, 0, sizeof(settings));

    RegistryRecord applicationEnabledRecord(applicationEntry, applicationEnabled, 0);
    RegistryRecord applicationEarlyAccessRecord(applicationEntry, applicationEarlyAccess, 0);
    RegistryRecord applicationPathRecord(applicationEntry, applicationPath, L"");
    RegistryRecord applicationSkipModeRecord(applicationEntry, applicationSkipMode, 0);
    RegistryRecord applicationTransferModeRecord(applicationEntry, applicationTransferMode, 0);
    RegistryRecord applicationWindowTitleRecord(applicationEntry, applicationWindowTitle, L"");
    RegistryRecord applicationWindowClassRecord(applicationEntry, applicationWindowClass, L"");
    RegistryRecord applicationMessageIdRecord(applicationEntry, applicationMessageId, 0);
    RegistryRecord applicationNotifyAllRecord(applicationEntry, applicationNotifyAll, 0);
    RegistryRecord applicationPipeNameRecord(applicationEntry, applicationPipeName, L"");
    RegistryRecord applicationPipeMessageSizeRecord(applicationEntry, applicationPipeMessageSize, 0);
    RegistryRecord applicationPipeLaunchApplicationRecord(applicationEntry, applicationPipeLaunchApplication, 0);
    RegistryRecord applicationTimeoutRecord(applicationEntry, applicationTimeout, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&applicationEnabledRecord);
    records.push_back(&applicationEarlyAccessRecord);
    records.push_back(&applicationPathRecord);
    records.push_back(&applicationSkipModeRecord);
    records.push_back(&applicationTransferModeRecord);
    records.push_back(&applicationWindowTitleRecord);
    records.push_back(&applicationWindowClassRecord);
    records.push_back(&applicationMessageIdRecord);
    records.push_back(&applicationNotifyAllRecord);
    records.push_back(&applicationPipeNameRecord);
    records.push_back(&applicationPipeMessageSizeRecord);
    records.push_back(&applicationPipeLaunchApplicationRecord);
    records.push_back(&applicationTimeoutRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(applicationEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(applicationEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else if ((hive & REGISTRY_HKU) && getRegistryRecord(applicationEnabledRecord, HKEY_USERS))
      regHive = HKEY_USERS;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnabled = applicationEnabledRecord.DData;
    settings.mEarlyAccess = applicationEarlyAccessRecord.DData;
    wcsncpy_s(settings.mPath, applicationPathRecord.SData.c_str(), ApplicationSettings::pathSize - 1);
    settings.mSkipMode = (SkipMode) applicationSkipModeRecord.DData;
    settings.mTransferMode = (TransferMode) applicationTransferModeRecord.DData;
    wcsncpy_s(settings.mWindowTitle, applicationWindowTitleRecord.SData.c_str(), ApplicationSettings::nameSize - 1);
    wcsncpy_s(settings.mWindowClass, applicationWindowClassRecord.SData.c_str(), ApplicationSettings::nameSize - 1);
    settings.mMessageId = applicationMessageIdRecord.DData;
    settings.mNotifyAll = applicationNotifyAllRecord.DData;
    wcsncpy_s(settings.mPipeName, applicationPipeNameRecord.SData.c_str(), ApplicationSettings::nameSize - 1);
    settings.mPipeMessageSize = applicationPipeMessageSizeRecord.DData;
    settings.mPipeLaunchApplication = applicationPipeLaunchApplicationRecord.DData;
    settings.mTimeout = applicationTimeoutRecord.DData;

    return 1;
  }

  int __stdcall setApplicationSettings(ApplicationType type, ApplicationSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring applicationEntry = registryKey + L"\\";
    switch (type){
      case ApplicationTypePreprocessor:
        applicationEntry += preprocessorRoot;
        break;

      case ApplicationTypePreconverter:
        applicationEntry += preconverterRoot;
        break;

      case ApplicationTypePostconverter:
        applicationEntry += postconverterRoot;
        break;
    }

    RegistryRecord applicationEnabledRecord(applicationEntry, applicationEnabled, settings.mEnabled);
    RegistryRecord applicationEarlyAccessRecord(applicationEntry, applicationEarlyAccess, settings.mEarlyAccess);
    RegistryRecord applicationPathRecord(applicationEntry, applicationPath, settings.mPath);
    RegistryRecord applicationSkipModeRecord(applicationEntry, applicationSkipMode, settings.mSkipMode);
    RegistryRecord applicationTransferModeRecord(applicationEntry, applicationTransferMode, settings.mTransferMode);
    RegistryRecord applicationWindowTitleRecord(applicationEntry, applicationWindowTitle, settings.mWindowTitle);
    RegistryRecord applicationWindowClassRecord(applicationEntry, applicationWindowClass, settings.mWindowClass);
    RegistryRecord applicationNotifyAllRecord(applicationEntry, applicationNotifyAll, settings.mNotifyAll);
    RegistryRecord applicationMessageIdRecord(applicationEntry, applicationMessageId, settings.mMessageId);
    RegistryRecord applicationPipeNameRecord(applicationEntry, applicationPipeName, settings.mPipeName);
    RegistryRecord applicationPipeMessageSizeRecord(applicationEntry, applicationPipeMessageSize, settings.mPipeMessageSize);
    RegistryRecord applicationPipeLaunchApplicationRecord(applicationEntry, applicationPipeLaunchApplication, settings.mPipeLaunchApplication);
    RegistryRecord applicationTimeoutRecord(applicationEntry, applicationTimeout, settings.mTimeout);

    std::vector<RegistryRecord*> records;
    records.push_back(&applicationEnabledRecord);
    records.push_back(&applicationEarlyAccessRecord);
    records.push_back(&applicationPathRecord);
    records.push_back(&applicationSkipModeRecord);
    records.push_back(&applicationTransferModeRecord);
    records.push_back(&applicationWindowTitleRecord);
    records.push_back(&applicationWindowClassRecord);
    records.push_back(&applicationMessageIdRecord);
    records.push_back(&applicationNotifyAllRecord);
    records.push_back(&applicationPipeNameRecord);
    records.push_back(&applicationPipeMessageSizeRecord);
    records.push_back(&applicationPipeLaunchApplicationRecord);
    records.push_back(&applicationTimeoutRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeApplicationSettings(ApplicationType type, unsigned int hive, std::wstring const &registryKey){
    std::wstring applicationEntry = registryKey + L"\\";
    switch (type){
      case ApplicationTypePreprocessor:
        applicationEntry += preprocessorRoot;
        break;

      case ApplicationTypePreconverter:
        applicationEntry += preconverterRoot;
        break;

      case ApplicationTypePostconverter:
        applicationEntry += postconverterRoot;
        break;
    }

    RegistryRecord applicationEnabledRecord(applicationEntry, applicationEnabled, 0);
    RegistryRecord applicationEarlyAccessRecord(applicationEntry, applicationEarlyAccess, 0);
    RegistryRecord applicationPathRecord(applicationEntry, applicationPath, L"");
    RegistryRecord applicationSkipModeRecord(applicationEntry, applicationSkipMode, 0);
    RegistryRecord applicationTransferModeRecord(applicationEntry, applicationTransferMode, 0);
    RegistryRecord applicationWindowTitleRecord(applicationEntry, applicationWindowTitle, L"");
    RegistryRecord applicationWindowClassRecord(applicationEntry, applicationWindowClass, L"");
    RegistryRecord applicationNotifyAllRecord(applicationEntry, applicationNotifyAll, 0);
    RegistryRecord applicationMessageIdRecord(applicationEntry, applicationMessageId, 0);
    RegistryRecord applicationPipeNameRecord(applicationEntry, applicationPipeName, L"");
    RegistryRecord applicationPipeMessageSizeRecord(applicationEntry, applicationPipeMessageSize, 0);
    RegistryRecord applicationPipeLaunchApplicationRecord(applicationEntry, applicationPipeLaunchApplication, 0);
    RegistryRecord applicationTimeoutRecord(applicationEntry, applicationTimeout, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&applicationEnabledRecord);
    records.push_back(&applicationEarlyAccessRecord);
    records.push_back(&applicationPathRecord);
    records.push_back(&applicationSkipModeRecord);
    records.push_back(&applicationTransferModeRecord);
    records.push_back(&applicationWindowTitleRecord);
    records.push_back(&applicationWindowClassRecord);
    records.push_back(&applicationMessageIdRecord);
    records.push_back(&applicationNotifyAllRecord);
    records.push_back(&applicationPipeNameRecord);
    records.push_back(&applicationPipeMessageSizeRecord);
    records.push_back(&applicationPipeLaunchApplicationRecord);
    records.push_back(&applicationTimeoutRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
