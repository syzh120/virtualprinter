#include <vpd_service.h>
#include <vpd_handle.h>

namespace{
  struct SCManagerDeleter{
    void operator()(SC_HANDLE manager){
      CloseServiceHandle(manager);
    }
  };

  typedef vpd::GenericHandle<SC_HANDLE, SCManagerDeleter> SCManager;
  typedef vpd::GenericHandle<SC_HANDLE, SCManagerDeleter> Service;
}

namespace vpd{

  int __stdcall startService(std::wstring const &serviceName){
    SCManager scm(OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT));
    if (!scm)
      return 0;

    Service service(OpenService(scm, serviceName.c_str(), SERVICE_START));
    if (!service)
      return 0;

    if (!StartService(service, 0, NULL) && GetLastError() != ERROR_SERVICE_ALREADY_RUNNING)
      return 0;

    return 1;
  }

  int __stdcall stopService(std::wstring const &serviceName){
    SCManager scm(OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT));
    if (!scm)
      return 0;

    Service service(OpenService(scm, serviceName.c_str(), SERVICE_STOP));
    if (!service)
      return 0;

    SERVICE_STATUS status;
    if (!ControlService(service, SERVICE_CONTROL_STOP, &status) && GetLastError() != ERROR_SERVICE_NOT_ACTIVE)
      return 0;

    return 1;
  }

  int __stdcall getServiceCurrentState(std::wstring const &serviceName, unsigned long &state){
    SCManager scm(OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT));
    if (!scm)
      return 0;

    Service service(OpenService(scm, serviceName.c_str(), SERVICE_QUERY_STATUS));
    if (!service)
      return 0;

    SERVICE_STATUS sstatus = {0};

    if (!QueryServiceStatus(service, &sstatus))
      return 0;

    state = sstatus.dwCurrentState;
    return 1;
  }

  int __stdcall enumDependentServices(std::wstring const &serviceName, ServiceInfo *&dependentServices, std::size_t &count){
    if (!serviceName.length()){
      SetLastError(ERROR_INVALID_PARAMETER);
      return 0;
    }

    SCManager scm(OpenSCManager(NULL, NULL, SC_MANAGER_ENUMERATE_SERVICE));
    if (!scm)
      return 0;

    Service service(OpenService(scm, serviceName.c_str(), SERVICE_ENUMERATE_DEPENDENTS));
    if (!service)
      return 0;

    DWORD needed = 0;
    BOOL res = EnumDependentServices(service, SERVICE_ACTIVE, NULL, 0, &needed, (DWORD *) &count);
    if (!res && GetLastError() != ERROR_MORE_DATA)
      return 0;

    if (res && count == 0)
      return 1;

    if (!needed){
      count = 0;
      return 1;
    }

    std::vector<BYTE> services;

    try{
      services.resize(needed);
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    if (!EnumDependentServices(service, SERVICE_ACTIVE, (ENUM_SERVICE_STATUS * ) &services[0], needed, &needed, (DWORD *) &count))
      return 0;

    try{
      dependentServices = new ServiceInfo[count];
    }
    catch (std::bad_alloc &){
      SetLastError(ERROR_NOT_ENOUGH_MEMORY);
      return 0;
    }

    ENUM_SERVICE_STATUS *ptr = (ENUM_SERVICE_STATUS *) &services[0];
    for (DWORD i = 0; i < count; ++i)
      wcscpy_s(dependentServices[i].mName, ServiceInfo::nameSize, ptr[i].lpServiceName);

    return 1;
  }

} // namespace vpd
