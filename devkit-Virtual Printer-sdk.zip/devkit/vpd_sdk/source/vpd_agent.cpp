#include <vpd_agent.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
      std::wstring const agentRoot = L"Agent";
      std::wstring const agentAllowGuestSession = L"Allow guest session";
      std::wstring const agentAllowDomainSession = L"Allow domain session";
      std::wstring const agentAllowSelfSession = L"Allow self session";
      std::wstring const agentPoolSize = L"Pool size";
  }

  using namespace vpd::tools;

  int __stdcall getAgentSettings(AgentSettings &settings, std::wstring const &registryKey){
    std::wstring agentEntry = registryKey + L"\\" + agentRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord agentAllowGuestSessionRecord(agentEntry, agentAllowGuestSession, 0);
    RegistryRecord agentAllowDomainSessionRecord(agentEntry, agentAllowDomainSession, 0);
    RegistryRecord agentAllowSelfSessionRecord(agentEntry, agentAllowSelfSession, 0);
    RegistryRecord agentPoolSizeRecord(agentEntry, agentPoolSize, 8);

    std::vector<RegistryRecord*> records;
    records.push_back(&agentAllowGuestSessionRecord);
    records.push_back(&agentAllowDomainSessionRecord);
    records.push_back(&agentAllowSelfSessionRecord);
    records.push_back(&agentPoolSizeRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], HKEY_LOCAL_MACHINE) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mAllowGuestSession = agentAllowGuestSessionRecord.DData;
    settings.mAllowDomainSession = agentAllowDomainSessionRecord.DData;
    settings.mAllowSelfSession = agentAllowSelfSessionRecord.DData;
    settings.mPoolSize = agentPoolSizeRecord.DData;

    return 1;
  }

  int __stdcall setAgentSettings(AgentSettings const &settings, std::wstring const &registryKey){
    std::wstring agentEntry = registryKey + L"\\" + agentRoot;

    RegistryRecord agentAllowGuestSessionRecord(agentEntry, agentAllowGuestSession, settings.mAllowGuestSession);
    RegistryRecord agentAllowDomainSessionRecord(agentEntry, agentAllowDomainSession, settings.mAllowDomainSession);
    RegistryRecord agentAllowSelfSessionRecord(agentEntry, agentAllowSelfSession, settings.mAllowSelfSession);
    RegistryRecord agentPoolSizeRecord(agentEntry, agentPoolSize, settings.mPoolSize);

    std::vector<RegistryRecord*> records;
    records.push_back(&agentAllowGuestSessionRecord);
    records.push_back(&agentAllowDomainSessionRecord);
    records.push_back(&agentAllowSelfSessionRecord);
    records.push_back(&agentPoolSizeRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if (!setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  VPD_SDK_API int __stdcall removeAgentSettings(std::wstring const &registryKey){
    std::wstring agentEntry = registryKey + L"\\" + agentRoot;

    RegistryRecord agentAllowGuestSessionRecord(agentEntry, agentAllowGuestSession, 0);
    RegistryRecord agentAllowDomainSessionRecord(agentEntry, agentAllowDomainSession, 0);
    RegistryRecord agentAllowSelfSessionRecord(agentEntry, agentAllowSelfSession, 0);
    RegistryRecord agentPoolSizeRecord(agentEntry, agentPoolSize, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&agentAllowGuestSessionRecord);
    records.push_back(&agentAllowDomainSessionRecord);
    records.push_back(&agentAllowSelfSessionRecord);
    records.push_back(&agentPoolSizeRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if (!removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

}
