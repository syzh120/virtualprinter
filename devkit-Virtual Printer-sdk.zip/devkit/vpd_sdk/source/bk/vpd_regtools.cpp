#include "vpd_regtools.h"

namespace vpd{

  namespace tools{

    static DWORD KEY_ALL = KEY_READ | KEY_WRITE | KEY_SET_VALUE | KEY_QUERY_VALUE;

    int setRegistryRecord(RegistryRecord const &record, HKEY hive){
      SetLastError(0);
      LONG errcode = 0;

      if (!hive){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      HKey key;
      if ((errcode = RegCreateKeyEx(hive, record.mKey.c_str(), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL, NULL, &key, NULL)) != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      switch (record.mType){
        case REG_SZ:{
          DWORD size = (DWORD) (record.SData.length() + 1) * sizeof(WCHAR);
          errcode = RegSetValueEx(key, record.mValue.c_str(), 0, REG_SZ, (LPBYTE)record.SData.c_str(), size);
          break;
        }

        case REG_DWORD:
          errcode = RegSetValueEx(key, record.mValue.c_str(), 0, REG_DWORD, (LPBYTE)&record.DData, sizeof(DWORD));
          break;

        case REG_BINARY:
          if (DWORD size = (DWORD) record.BData.size())
            errcode = RegSetValueEx(key, record.mValue.c_str(), 0, REG_BINARY, (LPBYTE)&record.BData[0], size);
          else
            errcode = RegSetValueEx(key, record.mValue.c_str(), 0, REG_BINARY, NULL, 0);

          break;

        default:
          errcode = ERROR_INVALID_PARAMETER;
          break;
      }

      SetLastError(errcode);
      return errcode == 0;
    }

    int getRegistryRecord(RegistryRecord &record, HKEY hive){
      DWORD needed=0;
      SetLastError(0);
      LONG errcode = 0;

      if (!hive){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      HKey key;
      if ((errcode = RegOpenKeyEx(hive, record.mKey.c_str(), 0, KEY_READ, &key)) != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      switch (record.mType){
        case REG_SZ:
          if ((errcode = RegQueryValueEx(key, record.mValue.c_str(), NULL, NULL, NULL, &needed)) == ERROR_SUCCESS){
            std::vector<WCHAR> data(needed / sizeof(WCHAR));
            if ((errcode = RegQueryValueEx(key, record.mValue.c_str(), NULL, NULL, (LPBYTE)&data[0], &needed)) == ERROR_SUCCESS)
              record.SData = data.empty() ? L"" : &data[0];
          }
          break;

        case REG_DWORD:
          needed = sizeof(DWORD);
          errcode = RegQueryValueEx(key, record.mValue.c_str(), NULL, NULL, (LPBYTE)(&record.DData), &needed);
          break;

        case REG_BINARY:
          if ((errcode = RegQueryValueEx(key, record.mValue.c_str(), NULL, NULL, NULL, &needed)) == ERROR_SUCCESS){
            try{
              record.BData.resize(needed);
            }
            catch (std::bad_alloc &){
              errcode = ERROR_NOT_ENOUGH_MEMORY;
              break;
            }
            if (needed > 0)
              errcode = RegQueryValueEx(key, record.mValue.c_str(), NULL, NULL, (LPBYTE)&record.BData[0], &needed);
          }
          break;

        default:
          errcode = ERROR_INVALID_PARAMETER;
          break;
      }

      SetLastError(errcode);
      return errcode == 0;
    }


    int removeRegistryRecord(RegistryRecord const &record, HKEY hive){
      SetLastError(0);
      LONG errcode = 0;

      if (!hive){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      HKey key;
      if ((errcode = RegOpenKeyEx(hive, record.mKey.c_str(), 0, KEY_READ | KEY_SET_VALUE, &key)) == ERROR_SUCCESS)
        errcode = RegDeleteValue(key,record.mValue.c_str());
      else if (errcode == ERROR_FILE_NOT_FOUND)
        errcode = 0;

      SetLastError(errcode);
      return errcode == 0;
    }

    int enumRegistryRecords(std::wstring const &entry, CaseInsensitiveMap &records, HKEY hive){
      if (!entry.length()){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      SetLastError(0);
      records.clear();

      HKey key;
      LONG errcode = RegOpenKeyEx(hive, entry.c_str(), 0, KEY_READ, &key);
      if (errcode != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      DWORD index = 0;
      DWORD needed = 0;
      DWORD type = 0;
      WCHAR valueName[255] = {0};
      DWORD valueNameSize = 255;
      std::vector<BYTE> value(1000);

      while (true){
        valueNameSize = 255;
        needed = 0;
        errcode = RegEnumValue(key, index, valueName, &valueNameSize, NULL, &type, &value[0], &needed);
        switch (errcode){
          case ERROR_MORE_DATA:
            break;

          case ERROR_NO_MORE_ITEMS:
            return 1;

          default:
            SetLastError(errcode);
            return 0;
        }

        if (value.size() < needed)
          value.resize(needed + 1);

        valueNameSize = 255;
        errcode = RegEnumValue(key, index, valueName, &valueNameSize, NULL, &type, &value[0], &needed);
        switch (errcode){
          case ERROR_SUCCESS:
            switch (type){
              case REG_DWORD:{
                records[valueName] = RegistryRecord(entry, valueName, (DWORD)((DWORD *)&value[0])[0]);
                break;
              }

              case REG_SZ:{
                records[valueName] = RegistryRecord(entry, valueName, std::wstring((WCHAR *)&value[0], (WCHAR*)(&value[0] + needed) - 1));
                break;
              }

              case REG_BINARY:{
                records[valueName] = RegistryRecord(entry, valueName, value);
                break;
              }

            }
            break;

          default:
            SetLastError(errcode);
            return 0;
        }

        ++index;
      }
    }

    int enumRegistryKeys(std::wstring const &entry, std::vector<std::wstring> &keys, HKEY hive){
      if (!entry.length()){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      SetLastError(0);
      keys.clear();

      HKey key;
      LONG errcode = RegOpenKeyEx(hive, entry.c_str(), 0, KEY_READ, &key);
      if (errcode != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      DWORD index = 0;
      WCHAR keyName[255] = {0};
      DWORD keyNameSize = 255;

      while (true){
        keyNameSize = 255;
        errcode = RegEnumKeyEx(key, index, keyName, &keyNameSize, NULL, NULL, NULL, NULL);
        switch (errcode){
          case ERROR_SUCCESS:
            break;

          case ERROR_NO_MORE_ITEMS:
            return 1;

          default:
            SetLastError(errcode);
            return 0;
        }

        try{
          keys.push_back(keyName);
        }
        catch (std::bad_alloc &){
          SetLastError(ERROR_NOT_ENOUGH_MEMORY);
          return 0;
        }

        ++index;
      }

      return 1;
    }

    int removeRegistryKey(std::wstring const &entry, std::wstring const &regKey, HKEY hive){
      if (!entry.length()){
        SetLastError(ERROR_INVALID_PARAMETER);
        return 0;
      }

      std::wstring subRoot = entry + L"\\" + regKey;
      std::vector<std::wstring> subKeys;

      if (!enumRegistryKeys(subRoot, subKeys, hive))
        return 0;

      for (std::size_t i = 0; i < subKeys.size(); ++i)
        if (!removeRegistryKey(subRoot, subKeys[i], hive))
          return 0;

      HKey key;
      LONG errcode = RegOpenKeyEx(hive, entry.c_str(), 0, KEY_READ, &key);
      if (errcode != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      errcode = RegDeleteKey(key, regKey.c_str());
      if (errcode != ERROR_SUCCESS){
        SetLastError(errcode);
        return 0;
      }

      return 1;
    }

  } // namespace tools

} // namespace vpd

