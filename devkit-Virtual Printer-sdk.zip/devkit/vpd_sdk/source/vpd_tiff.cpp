#include <vpd_tiff.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const tiffRoot = L"Converter\\TIFF";
    std::wstring const tiffEnabled = L"Enabled";
    std::wstring const tiffBpp = L"Bits per pixel";
    std::wstring const tiffGrayscale = L"Grayscale";
    std::wstring const tiffDithering = L"Dithering";
    std::wstring const tiffMultipage = L"Multipage";
    std::wstring const tiffCompression = L"Compression";
    std::wstring const tiffCleanup = L"Cleanup";
  }

  using namespace vpd::tools;

  int __stdcall getTiffSettings(TiffSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring tiffEntry = registryKey + L"\\" + tiffRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord tiffEnabledRecord(tiffEntry, tiffEnabled, 0);
    RegistryRecord tiffBppRecord(tiffEntry, tiffBpp, 24);
    RegistryRecord tiffGrayscaleRecord(tiffEntry, tiffGrayscale, 0);
    RegistryRecord tiffDitheringRecord(tiffEntry, tiffDithering, 0);
    RegistryRecord tiffMultipageRecord(tiffEntry, tiffMultipage, 1);
    RegistryRecord tiffCompressionRecord(tiffEntry, tiffCompression, 0);
    RegistryRecord tiffCleanupRecord(tiffEntry, tiffCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&tiffBppRecord);
    records.push_back(&tiffGrayscaleRecord);
    records.push_back(&tiffDitheringRecord);
    records.push_back(&tiffMultipageRecord);
    records.push_back(&tiffCompressionRecord);
    records.push_back(&tiffCleanupRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(tiffEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(tiffEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = tiffEnabledRecord.DData;
    settings.mBpp = (ImageBpp) tiffBppRecord.DData;
    settings.mGrayscale = tiffGrayscaleRecord.DData;
    settings.mDithering = (ImageDithering) tiffDitheringRecord.DData;
    settings.mMultipage = tiffMultipageRecord.DData;
    settings.mCompression = (ImageCompression) tiffCompressionRecord.DData;
    settings.mCleanup = tiffCleanupRecord.DData;

    return 1;
  }

  int __stdcall setTiffSettings(TiffSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring tiffEntry = registryKey + L"\\" + tiffRoot;

    RegistryRecord tiffEnabledRecord(tiffEntry, tiffEnabled, settings.mEnable);
    RegistryRecord tiffBppRecord(tiffEntry, tiffBpp, settings.mBpp);
    RegistryRecord tiffGrayscaleRecord(tiffEntry, tiffGrayscale, settings.mGrayscale);
    RegistryRecord tiffDitheringRecord(tiffEntry, tiffDithering, settings.mDithering);
    RegistryRecord tiffMultipageRecord(tiffEntry, tiffMultipage, settings.mMultipage);
    RegistryRecord tiffCompressionRecord(tiffEntry, tiffCompression, settings.mCompression);
    RegistryRecord tiffCleanupRecord(tiffEntry, tiffCleanup, settings.mCleanup);

    std::vector<RegistryRecord*> records;
    records.push_back(&tiffEnabledRecord);
    records.push_back(&tiffBppRecord);
    records.push_back(&tiffGrayscaleRecord);
    records.push_back(&tiffDitheringRecord);
    records.push_back(&tiffMultipageRecord);
    records.push_back(&tiffCompressionRecord);
    records.push_back(&tiffCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeTiffSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring tiffEntry = registryKey + L"\\" + tiffRoot;

    RegistryRecord tiffEnabledRecord(tiffEntry, tiffEnabled, 0);
    RegistryRecord tiffBppRecord(tiffEntry, tiffBpp, 24);
    RegistryRecord tiffGrayscaleRecord(tiffEntry, tiffGrayscale, 0);
    RegistryRecord tiffDitheringRecord(tiffEntry, tiffDithering, 0);
    RegistryRecord tiffMultipageRecord(tiffEntry, tiffMultipage, 1);
    RegistryRecord tiffCompressionRecord(tiffEntry, tiffCompression, 0);
    RegistryRecord tiffCleanupRecord(tiffEntry, tiffCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&tiffEnabledRecord);
    records.push_back(&tiffBppRecord);
    records.push_back(&tiffGrayscaleRecord);
    records.push_back(&tiffDitheringRecord);
    records.push_back(&tiffMultipageRecord);
    records.push_back(&tiffCompressionRecord);
    records.push_back(&tiffCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
