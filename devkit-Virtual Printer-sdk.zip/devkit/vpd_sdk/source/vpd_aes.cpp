#include "vpd_aes.h"

#include <Windows.h>
#include <aes.h>
#include <osrng.h>
#include <filters.h>
#include <files.h>
#include <hex.h>
#include <modes.h>

namespace{
  unsigned char AES_KEY[] = {0xAE, 0xAA, 0xF4, 0xCD, 0xD1, 0x95, 0x43, 0x6E, 0x2C, 0x27, 0xC8, 0xED, 0xD2, 0x13, 0x5D, 0x7E, 0xAE, 0xAA, 0xF4, 0xCD, 0xD1, 0x95, 0x43, 0x6E};
  unsigned char AES_IV[] = {0x2C, 0x27, 0xC8, 0xED, 0xD2, 0x13, 0x5D, 0x7E, 0x15, 0xDD, 0xA6, 0x09, 0x17, 0xF1, 0xC7, 0x90, 0xC3, 0x70, 0x6D, 0x8C, 0x26, 0x2D, 0xA7, 0xD8};

  struct char2wchar{
    wchar_t operator() (char ch) {return static_cast<wchar_t>(static_cast<unsigned char>(ch));}
  };
}

namespace vpd{
  namespace tools{

    bool wtom(std::wstring const &in, std::string &out, DWORD encode){
      DWORD size = WideCharToMultiByte(encode, 0, in.c_str(), -1, NULL, 0, NULL, NULL) + 1;

      std::vector<char> data;
      try{
        data.resize(size);
      }
      catch (std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return false;
      }

      memset(&data[0], 0, sizeof(char) * size);
      WideCharToMultiByte(encode, 0, in.c_str(), in.length(), &data[0], size, NULL, NULL);
      out.assign(data.begin(), data.end());
      return true;
    }

    bool mtow(std::string const &in, std::wstring &out, DWORD encode){
      DWORD size = MultiByteToWideChar(encode, 0, in.c_str(), -1, NULL, 0) + 1;

      std::vector<WCHAR> data;
      try{
        data.resize(size);
      }
      catch (std::bad_alloc &){
        SetLastError(ERROR_NOT_ENOUGH_MEMORY);
        return false;
      }

      memset(&data[0], 0, sizeof(WCHAR) * size);

      MultiByteToWideChar(encode, 0, in.c_str(), in.length(), &data[0], size);
      out.assign(data.begin(), data.end());
      return true;
    }

    void aes_encrypt(std::string const &input, std::string &output){
      using namespace CryptoPP;

      CFB_Mode<AES>::Encryption e;
      e.SetKeyWithIV(AES_KEY, AES::DEFAULT_KEYLENGTH, AES_IV);

      // CFB mode must not use padding. Specifying
      //  a scheme will result in an exception
      StringSource(input, true, 
        new StreamTransformationFilter(e,
          new HexEncoder(
            new StringSink(output)
          ) // HexEncoder
        ) // StreamTransformationFilter      
      ); // StringSource
    }

    void aes_encrypt(std::wstring const &input, std::wstring &output){
      std::string tmpInput;
      wtom(input, tmpInput, CP_UTF8);

      //std::size_t len = input.length() * sizeof(WCHAR);
      //char const *data = (char const *) (input.c_str());
      //std::string tmpInput(data, data + len);
      std::string tmpOutput;
      aes_encrypt(tmpInput, tmpOutput);

      mtow(tmpOutput, output, CP_UTF8);

      //output.assign(tmpOutput.begin(), tmpOutput.end());
    }

    void aes_decrypt(std::string const &input, std::string &output){
      using namespace CryptoPP;

      CFB_Mode<AES>::Decryption d;
      d.SetKeyWithIV(AES_KEY, AES::DEFAULT_KEYLENGTH, AES_IV);

      // The StreamTransformationFilter removes
      //  padding as required.
      StringSource s(input, true, 
        new HexDecoder(
          new StreamTransformationFilter(d,
            new StringSink(output)
          ) // StreamTransformationFilter
        ) // HexDecoder
      ); // StringSource
    }

    void aes_decrypt(std::wstring const &input, std::wstring &output){
      std::string tmpInput;
      wtom(input, tmpInput, CP_UTF8);

      //std::string tmpInput(input.begin(), input.end());
      std::string tmpOutput;
      aes_decrypt(tmpInput, tmpOutput);

      mtow(tmpOutput, output, CP_UTF8);

      //std::size_t len = tmpOutput.length() / 2;
      //WCHAR *data = (WCHAR *)(tmpOutput.c_str());
      //output.assign(data, data + len);
    }

  }// namespace tools
}// namespace vpd
