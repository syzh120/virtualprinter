#include <vpd_emf.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const emfRoot = L"Converter\\EMF";
    std::wstring const emfEnabled = L"Enabled";
    std::wstring const emfCut = L"Cut";
    std::wstring const emfCutTail = L"Cut Tail";
  }

  using namespace vpd::tools;

  int __stdcall getEmfSettings(EmfSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring emfEntry = registryKey + L"\\" + emfRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord emfEnabledRecord(emfEntry, emfEnabled, 0);
    RegistryRecord emfCutRecord(emfEntry, emfCut, 0);
    RegistryRecord emfCutTailRecord(emfEntry, emfCutTail, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&emfCutRecord);
    records.push_back(&emfCutTailRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(emfEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(emfEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = emfEnabledRecord.DData;
    settings.mCut = emfCutRecord.DData;
    settings.mCutTail = emfCutTailRecord.DData;

    return 1;
  }

  int __stdcall setEmfSettings(EmfSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring emfEntry = registryKey + L"\\" + emfRoot;

    RegistryRecord emfEnabledRecord(emfEntry, emfEnabled, settings.mEnable);
    RegistryRecord emfCutRecord(emfEntry, emfCut, settings.mCut);
    RegistryRecord emfCutTailRecord(emfEntry, emfCutTail, settings.mCutTail);

    std::vector<RegistryRecord*> records;
    records.push_back(&emfEnabledRecord);
    records.push_back(&emfCutRecord);
    records.push_back(&emfCutTailRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeEmfSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring emfEntry = registryKey + L"\\" + emfRoot;

    RegistryRecord emfEnabledRecord(emfEntry, emfEnabled, 0);
    RegistryRecord emfCutRecord(emfEntry, emfCut, 0);
    RegistryRecord emfCutTailRecord(emfEntry, emfCutTail, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&emfEnabledRecord);
    records.push_back(&emfCutRecord);
    records.push_back(&emfCutTailRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
