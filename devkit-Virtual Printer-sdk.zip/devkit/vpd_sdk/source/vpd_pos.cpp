#include <vpd_pos.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const posRoot = L"Converter\\POS";
    std::wstring const posEnabled = L"Enabled";
    std::wstring const posFontA = L"FontA";
    std::wstring const posFontASize = L"FontA Size";
    std::wstring const posFontB = L"FontB";
    std::wstring const posFontBSize = L"FontB Size";
    //std::wstring const posSingleFile = L"Single File";
    std::wstring const posSkipHeader = L"Skip Header";
    std::wstring const posDithering = L"Dithering";
  }

  using namespace vpd::tools;

  int __stdcall getPosSettings(PosSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring posEntry = registryKey + L"\\" + posRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord posEnabledRecord(posEntry, posEnabled, 0);
    RegistryRecord posFontARecord(posEntry, posFontA, L"Liberation Mono");
    RegistryRecord posFontASizeRecord(posEntry, posFontASize, 48);
    RegistryRecord posFontBRecord(posEntry, posFontB, L"Liberation Mono");
    RegistryRecord posFontBSizeRecord(posEntry, posFontBSize, 34);
    //RegistryRecord posSingleFileRecord(posEntry, posSingleFile, 0);
    RegistryRecord posSkipHeaderRecord(posEntry, posSkipHeader, 0);
    RegistryRecord posDitheringRecord(posEntry, posDithering, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&posFontARecord);
    records.push_back(&posFontASizeRecord);
    records.push_back(&posFontBRecord);
    records.push_back(&posFontBSizeRecord);
    //records.push_back(&posSingleFileRecord);
    records.push_back(&posSkipHeaderRecord);
    records.push_back(&posDitheringRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(posEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(posEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = posEnabledRecord.DData;
    wcsncpy_s(settings.mFontA, posFontARecord.SData.c_str(), PosSettings::fontNameSize - 1);
    settings.mFontASize = posFontASizeRecord.DData;
    wcsncpy_s(settings.mFontB, posFontBRecord.SData.c_str(), PosSettings::fontNameSize - 1);
    settings.mFontBSize = posFontBSizeRecord.DData;
    //settings.mSingleFile = posSingleFileRecord.DData;
    settings.mSkipHeader = posSkipHeaderRecord.DData;
    settings.mDithering = (ImageDithering) posDitheringRecord.DData;

    return 1;
  }

  int __stdcall setPosSettings(PosSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring posEntry = registryKey + L"\\" + posRoot;

    RegistryRecord posEnabledRecord(posEntry, posEnabled, settings.mEnable);
    RegistryRecord posFontARecord(posEntry, posFontA, settings.mFontA);
    RegistryRecord posFontASizeRecord(posEntry, posFontASize, settings.mFontASize);
    RegistryRecord posFontBRecord(posEntry, posFontB, settings.mFontB);
    RegistryRecord posFontBSizeRecord(posEntry, posFontBSize, settings.mFontBSize);
    //RegistryRecord posSingleFileRecord(posEntry, posSingleFile, settings.mSingleFile);
    RegistryRecord posSkipHeaderRecord(posEntry, posSkipHeader, settings.mSkipHeader);
    RegistryRecord posDitheringRecord(posEntry, posDithering, settings.mDithering);

    std::vector<RegistryRecord*> records;
    records.push_back(&posEnabledRecord);
    records.push_back(&posFontARecord);
    records.push_back(&posFontASizeRecord);
    records.push_back(&posFontBRecord);
    records.push_back(&posFontBSizeRecord);
    //records.push_back(&posSingleFileRecord);
    records.push_back(&posSkipHeaderRecord);
    records.push_back(&posDitheringRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removePosSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring posEntry = registryKey + L"\\" + posRoot;

    RegistryRecord posEnabledRecord(posEntry, posEnabled, 0);
    RegistryRecord posFontARecord(posEntry, posFontA, L"");
    RegistryRecord posFontASizeRecord(posEntry, posFontASize, 0);
    RegistryRecord posFontBRecord(posEntry, posFontB, L"");
    RegistryRecord posFontBSizeRecord(posEntry, posFontBSize, 0);
    //RegistryRecord posSingleFileRecord(posEntry, posSingleFile, 0);
    RegistryRecord posSkipHeaderRecord(posEntry, posSkipHeader, 0);
    RegistryRecord posDitheringRecord(posEntry, posDithering, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&posEnabledRecord);
    records.push_back(&posFontARecord);
    records.push_back(&posFontASizeRecord);
    records.push_back(&posFontBRecord);
    records.push_back(&posFontBSizeRecord);
    //records.push_back(&posSingleFileRecord);
    records.push_back(&posSkipHeaderRecord);
    records.push_back(&posDitheringRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
