#include <vpd_redirect.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring redirectRoot = L"Converter\\Redirect";
    std::wstring redirectEnabled = L"Enabled";
    std::wstring redirectSpool = L"Spool";
    std::wstring redirectPos = L"Pos";
    std::wstring redirectPrinter = L"Printer";
    std::wstring redirectWatermarks = L"Redirect watermarks";
    std::wstring redirectLeftCorrection = L"Left Correction";
    std::wstring redirectTopCorrection = L"Top Correction";
    std::wstring redirectRightCorrection = L"Right Correction";
    std::wstring redirectBottomCorrection = L"Bottom Correction";
    std::wstring redirectTray = L"Tray";
  }

  using namespace vpd::tools;

  int __stdcall getRedirectSettings(RedirectSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring redirectEntry = registryKey + L"\\" + redirectRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord redirectEnabledRecord(redirectEntry, redirectEnabled, 0);
    RegistryRecord redirectSpoolRecord(redirectEntry, redirectSpool, 0);
    RegistryRecord redirectPosRecord(redirectEntry, redirectPos, 0);
    RegistryRecord redirectPrinterRecord(redirectEntry, redirectPrinter, L"");
    RegistryRecord redirectWatermarksRecord(redirectEntry, redirectWatermarks, 0);
    RegistryRecord redirectLeftCorrectionRecord(redirectEntry, redirectLeftCorrection, 0);
    RegistryRecord redirectTopCorrectionRecord(redirectEntry, redirectTopCorrection, 0);
    RegistryRecord redirectRightCorrectionRecord(redirectEntry, redirectRightCorrection, 0);
    RegistryRecord redirectBottomCorrectionRecord(redirectEntry, redirectBottomCorrection, 0);
    RegistryRecord redirectTrayRecord(redirectEntry, redirectTray, L"");

    std::vector<RegistryRecord*> records;
    records.push_back(&redirectSpoolRecord);
    records.push_back(&redirectPosRecord);
    records.push_back(&redirectPrinterRecord);
    records.push_back(&redirectWatermarksRecord);
    records.push_back(&redirectLeftCorrectionRecord);
    records.push_back(&redirectTopCorrectionRecord);
    records.push_back(&redirectRightCorrectionRecord);
    records.push_back(&redirectBottomCorrectionRecord);
    records.push_back(&redirectTrayRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(redirectEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(redirectEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = redirectEnabledRecord.DData;
    settings.mRedirectSpool = redirectSpoolRecord.DData;
    settings.mRedirectPos = redirectPosRecord.DData;
    wcsncpy_s(settings.mPrinter, redirectPrinterRecord.SData.c_str(), RedirectSettings::printerNameSize - 1);
    settings.mRedirectWatermarks = redirectWatermarksRecord.DData;
    settings.mLeftCorrection = redirectLeftCorrectionRecord.DData;
    settings.mTopCorrection = redirectTopCorrectionRecord.DData;
    settings.mRightCorrection = redirectRightCorrectionRecord.DData;
    settings.mBottomCorrection = redirectBottomCorrectionRecord.DData;
    wcsncpy_s(settings.mTrayName, redirectTrayRecord.SData.c_str(), RedirectSettings::trayNameSize - 1);

    return 1;
  }

  int __stdcall setRedirectSettings(RedirectSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring redirectEntry = registryKey + L"\\" + redirectRoot;

    RegistryRecord redirectEnabledRecord(redirectEntry, redirectEnabled, settings.mEnable);
    RegistryRecord redirectSpoolRecord(redirectEntry, redirectSpool, settings.mRedirectSpool);
    RegistryRecord redirectPosRecord(redirectEntry, redirectPos, settings.mRedirectPos);
    RegistryRecord redirectPrinterRecord(redirectEntry, redirectPrinter, settings.mPrinter);
    RegistryRecord redirectWatermarksRecord(redirectEntry, redirectWatermarks, settings.mRedirectWatermarks);
    RegistryRecord redirectLeftCorrectionRecord(redirectEntry, redirectLeftCorrection, settings.mLeftCorrection);
    RegistryRecord redirectTopCorrectionRecord(redirectEntry, redirectTopCorrection, settings.mTopCorrection);
    RegistryRecord redirectRightCorrectionRecord(redirectEntry, redirectRightCorrection, settings.mRightCorrection);
    RegistryRecord redirectBottomCorrectionRecord(redirectEntry, redirectBottomCorrection, settings.mBottomCorrection);
    RegistryRecord redirectTrayRecord(redirectEntry, redirectTray, settings.mTrayName);

    std::vector<RegistryRecord*> records;
    records.push_back(&redirectEnabledRecord);
    records.push_back(&redirectSpoolRecord);
    records.push_back(&redirectPosRecord);
    records.push_back(&redirectPrinterRecord);
    records.push_back(&redirectWatermarksRecord);
    records.push_back(&redirectLeftCorrectionRecord);
    records.push_back(&redirectTopCorrectionRecord);
    records.push_back(&redirectRightCorrectionRecord);
    records.push_back(&redirectBottomCorrectionRecord);
    records.push_back(&redirectTrayRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeRedirectSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring redirectEntry = registryKey + L"\\" + redirectRoot;

    RegistryRecord redirectEnabledRecord(redirectEntry, redirectEnabled, 0);
    RegistryRecord redirectSpoolRecord(redirectEntry, redirectSpool, 0);
    RegistryRecord redirectPosRecord(redirectEntry, redirectPos, 0);
    RegistryRecord redirectPrinterRecord(redirectEntry, redirectPrinter, L"");
    RegistryRecord redirectWatermarksRecord(redirectEntry, redirectWatermarks, 0);
    RegistryRecord redirectLeftCorrectionRecord(redirectEntry, redirectLeftCorrection, 0);
    RegistryRecord redirectTopCorrectionRecord(redirectEntry, redirectTopCorrection, 0);
    RegistryRecord redirectRightCorrectionRecord(redirectEntry, redirectRightCorrection, 0);
    RegistryRecord redirectBottomCorrectionRecord(redirectEntry, redirectBottomCorrection, 0);
    RegistryRecord redirectTrayRecord(redirectEntry, redirectTray, L"");

    std::vector<RegistryRecord*> records;
    records.push_back(&redirectEnabledRecord);
    records.push_back(&redirectSpoolRecord);
    records.push_back(&redirectPosRecord);
    records.push_back(&redirectPrinterRecord);
    records.push_back(&redirectWatermarksRecord);
    records.push_back(&redirectLeftCorrectionRecord);
    records.push_back(&redirectTopCorrectionRecord);
    records.push_back(&redirectRightCorrectionRecord);
    records.push_back(&redirectBottomCorrectionRecord);
    records.push_back(&redirectTrayRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
