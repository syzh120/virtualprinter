#include <vpd_text.h>
#include <vpd_regtools.h>

namespace vpd{

  namespace{
    std::wstring const textRoot = L"Converter\\TEXT";
    std::wstring const textEnabled = L"Enabled";
    std::wstring const textMultipage = L"Multipage";
    std::wstring const textEncoding = L"Encoding";
    std::wstring const textWriteBOM = L"Write BOM";
    std::wstring const textSingleLineInterval = L"Line concatenation interval";
    std::wstring const textSingleWordInterval = L"Word separation interval";
    std::wstring const textDebug = L"Debug";
    std::wstring const textKeepFormatting = L"Keep formatting";
    std::wstring const textDefaultBidirectionalAlghoritm = L"Default Bidirectional Algorithm";
    std::wstring const textCleanup = L"Cleanup";
  }

  using namespace vpd::tools;

  int __stdcall getTextSettings(TextSettings &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring textEntry = registryKey + L"\\" + textRoot;

    memset(&settings, 0, sizeof(settings));

    RegistryRecord textEnabledRecord(textEntry, textEnabled, 0);
    RegistryRecord textMultipageRecord(textEntry, textMultipage, 1);
    RegistryRecord textEncodingRecord(textEntry, textEncoding, TextEncodingANSI);
    RegistryRecord textWriteBOMRecord(textEntry, textWriteBOM, 0);
    RegistryRecord textSingleLineIntervalRecord(textEntry, textSingleLineInterval, 5);
    RegistryRecord textSingleWordIntervalRecord(textEntry, textSingleWordInterval, 1);
    RegistryRecord textDebugRecord(textEntry, textDebug, 0);
    RegistryRecord textKeepFormattingRecord(textEntry, textKeepFormatting, 1);
    RegistryRecord textDefaultBidirectionalAlgorithmRecord(textEntry, textDefaultBidirectionalAlghoritm, 0);
    RegistryRecord textCleanupRecord(textEntry, textCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&textMultipageRecord);
    records.push_back(&textEncodingRecord);
    records.push_back(&textWriteBOMRecord);
    records.push_back(&textSingleLineIntervalRecord);
    records.push_back(&textSingleWordIntervalRecord);
    records.push_back(&textDebugRecord);
    records.push_back(&textKeepFormattingRecord);
    records.push_back(&textDefaultBidirectionalAlgorithmRecord);
    records.push_back(&textCleanupRecord);

    HKEY regHive = NULL;

    if ((hive & REGISTRY_HKCU) && getRegistryRecord(textEnabledRecord, HKEY_CURRENT_USER))
      regHive = HKEY_CURRENT_USER;
    else if ((hive & REGISTRY_HKLM) && getRegistryRecord(textEnabledRecord, HKEY_LOCAL_MACHINE))
      regHive = HKEY_LOCAL_MACHINE;
    else
      return 0;

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i)
      if (getRegistryRecord(*records[i], regHive) == 0 && GetLastError() != ERROR_FILE_NOT_FOUND && GetLastError() != ERROR_PATH_NOT_FOUND)
        return 0;

    settings.mEnable = textEnabledRecord.DData;
    settings.mMultipage = textMultipageRecord.DData;
    settings.mEncoding = (TextEncoding) textEncodingRecord.DData;
    settings.mWriteBOM = textWriteBOMRecord.DData;
    settings.mSingleLineInterval = textSingleLineIntervalRecord.DData;
    settings.mSingleWordInterval = textSingleWordIntervalRecord.DData;
    settings.mDebug = textDebugRecord.DData;
    settings.mKeepFormatting = textKeepFormattingRecord.DData;
    settings.mDefaultBidirectionalAlgorithm = textDefaultBidirectionalAlgorithmRecord.DData;
    settings.mCleanup = textCleanupRecord.DData;

    return 1;
  }

  int __stdcall setTextSettings(TextSettings const &settings, unsigned int hive, std::wstring const &registryKey){
    std::wstring textEntry = registryKey + L"\\" + textRoot;

    RegistryRecord textEnabledRecord(textEntry, textEnabled, settings.mEnable);
    RegistryRecord textMultipageRecord(textEntry, textMultipage, settings.mMultipage);
    RegistryRecord textEncodingRecord(textEntry, textEncoding, settings.mEncoding);
    RegistryRecord textWriteBOMRecord(textEntry, textWriteBOM, settings.mWriteBOM);
    RegistryRecord textSingleLineIntervalRecord(textEntry, textSingleLineInterval, settings.mSingleLineInterval);
    RegistryRecord textSingleWordIntervalRecord(textEntry, textSingleWordInterval, settings.mSingleWordInterval);
    RegistryRecord textDebugRecord(textEntry, textDebug, settings.mDebug);
    RegistryRecord textKeepFormattingRecord(textEntry, textKeepFormatting, settings.mKeepFormatting);
    RegistryRecord textDefaultBidirectionalAlgorithmRecord(textEntry, textDefaultBidirectionalAlghoritm, settings.mDefaultBidirectionalAlgorithm);
    RegistryRecord textCleanupRecord(textEntry, textCleanup, settings.mCleanup);

    std::vector<RegistryRecord*> records;
    records.push_back(&textEnabledRecord);
    records.push_back(&textMultipageRecord);
    records.push_back(&textEncodingRecord);
    records.push_back(&textWriteBOMRecord);
    records.push_back(&textSingleLineIntervalRecord);
    records.push_back(&textSingleWordIntervalRecord);
    records.push_back(&textDebugRecord);
    records.push_back(&textKeepFormattingRecord);
    records.push_back(&textDefaultBidirectionalAlgorithmRecord);
    records.push_back(&textCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !setRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !setRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
          return 0;
    }

    return 1;
  }

  int __stdcall removeTextSettings(unsigned int hive, std::wstring const &registryKey){
    std::wstring textEntry = registryKey + L"\\" + textRoot;

    RegistryRecord textEnabledRecord(textEntry, textEnabled, 0);
    RegistryRecord textMultipageRecord(textEntry, textMultipage, 0);
    RegistryRecord textEncodingRecord(textEntry, textEncoding, 0);
    RegistryRecord textWriteBOMRecord(textEntry, textWriteBOM, 0);
    RegistryRecord textSingleLineIntervalRecord(textEntry, textSingleLineInterval, 5);
    RegistryRecord textSingleWordIntervalRecord(textEntry, textSingleWordInterval, 1);
    RegistryRecord textDebugRecord(textEntry, textDebug, 0);
    RegistryRecord textKeepFormattingRecord(textEntry, textKeepFormatting, 1);
    RegistryRecord textDefaultBidirectionalAlgorithmRecord(textEntry, textDefaultBidirectionalAlghoritm, 0);
    RegistryRecord textCleanupRecord(textEntry, textCleanup, 0);

    std::vector<RegistryRecord*> records;
    records.push_back(&textEnabledRecord);
    records.push_back(&textMultipageRecord);
    records.push_back(&textEncodingRecord);
    records.push_back(&textWriteBOMRecord);
    records.push_back(&textSingleLineIntervalRecord);
    records.push_back(&textSingleWordIntervalRecord);
    records.push_back(&textDebugRecord);
    records.push_back(&textKeepFormattingRecord);
    records.push_back(&textDefaultBidirectionalAlgorithmRecord);
    records.push_back(&textCleanupRecord);

    std::size_t const size = records.size();
    for (std::size_t i = 0; i < size; ++i){
      if ((hive & REGISTRY_HKCU) && !removeRegistryRecord(*records[i], HKEY_CURRENT_USER))
        return 0;

      if ((hive & REGISTRY_HKLM) && !removeRegistryRecord(*records[i], HKEY_LOCAL_MACHINE))
        return 0;
    }

    return 1;
  }

} // namespace vpd
