#include <vpd_tools.h>
#include <rpc.h>

namespace vpd{

  double __stdcall mm2inch(double value){
    return value / 25.4f;
  }

  double __stdcall inch2mm(double value){
    return value *25.4f;
  }

  std::wstring __stdcall generateUUID(void){
    UUID uuid = {0};
    UuidCreate(&uuid);
    WCHAR *str = 0;
    UuidToString(&uuid, (RPC_WSTR*) (&str));
    std::wstring  result = str;
    RpcStringFree((RPC_WSTR *)(&str));
    return result;
  }

  void __stdcall release(void *ptr){
    delete[] ptr;
  }
} // namespace vpd
