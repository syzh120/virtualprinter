#include <vpd_handle.h>

namespace vpd{

  Handle::Handle(void)
    : mHandle(NULL),
    mCleanFunc(CloseHandle){
  }

  Handle::Handle(HANDLE handle)
    : mHandle(handle),
    mCleanFunc(CloseHandle){
  }

  Handle::Handle(HANDLE handle, BOOL (WINAPI *cleanFunc)(HANDLE))
    : mHandle(handle),
    mCleanFunc(cleanFunc){
  }

  Handle::~Handle(void){
    if (mHandle)
      mCleanFunc(mHandle);
  }

  Handle::operator HANDLE(void) const{
    return mHandle;
  }

  Handle::operator bool(void) const{
    return mHandle != NULL;
  }

  HANDLE *Handle::operator&(void){
    return &mHandle;
  }

  void Handle::reset(HANDLE handle){
    if (mHandle)
      mCleanFunc(mHandle);

    mHandle = handle;
    mCleanFunc = CloseHandle;
  }

  void Handle::reset(HANDLE handle, BOOL (WINAPI *cleanFunc)(HANDLE)){
    if (mHandle)
      mCleanFunc(mHandle);

    mHandle = handle;
    mCleanFunc = cleanFunc;
  }

  HANDLE Handle::release(void){
    HANDLE tmp = mHandle;
    mHandle = NULL;
    return tmp;
  }

}
