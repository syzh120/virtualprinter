#include "RegToolsTest.h"
#include <vpd_sdk.h>
#include <algorithm>

#if 0
TEST_F(RegToolsTest, RegToolsTest){
  using namespace vpd::tools;

  RegistryRecord record0(L"Software\\AAAKey0", L"Value0", 123);
  RegistryRecord record1(L"Software\\AAAKey0", L"Value1", L"some value 1");
  RegistryRecord record2(L"Software\\AAAKey0\\Key0", L"Value0", 0);
  RegistryRecord record3(L"Software\\AAAKey0\\Key1", L"Value1", 1);
  RegistryRecord record4(L"Software\\AAAKey0\\Key1\\Key0", L"Value0", 0);


  std::vector<RegistryRecord> original;
  original.push_back(record0);
  original.push_back(record1);

  std::vector<RegistryRecord> records;
  records.push_back(record0);
  records.push_back(record1);

  std::size_t const size = records.size();

  int result = 0;
  for (std::size_t i = 0; i < size; ++i){
    result = setRegistryRecord(records[i], HKEY_LOCAL_MACHINE);
    EXPECT_NE(result, 0);

    records[i].DData = 0;
    records[i].SData = L"";
    result = getRegistryRecord(records[i], HKEY_LOCAL_MACHINE);
    EXPECT_NE(result, 0);

    switch (records[i].mType){
      case REG_DWORD:
        EXPECT_EQ(records[i].DData, original[i].DData);
        break;

      case REG_SZ:
        EXPECT_EQ(records[i].SData, original[i].SData);
        break;
    }

    result = removeRegistryRecord(records[i], HKEY_LOCAL_MACHINE);
    EXPECT_NE(result, 0);

    result = getRegistryRecord(records[i], HKEY_LOCAL_MACHINE);
    EXPECT_EQ(result, 0);
  }

  for (std::size_t i = 0; i < size; ++i){
    result = setRegistryRecord(original[i], HKEY_LOCAL_MACHINE);
    EXPECT_NE(result, 0);
  }

  CaseInsensitiveMap recordsEnum;
  typedef CaseInsensitiveMap::const_iterator const_iterator;
  result = enumRegistryRecords(L"Software\\AAAKey0", recordsEnum, HKEY_LOCAL_MACHINE);
  EXPECT_NE(result, 0);
  EXPECT_EQ(recordsEnum.size(), size);
  for (std::size_t i = 0; i < size; ++i){
    const_iterator iter = recordsEnum.find(original[i].mValue);
    EXPECT_NE(iter, recordsEnum.end());
    EXPECT_EQ(iter->second.mType, original[i].mType);
    EXPECT_EQ(iter->second.mKey, original[i].mKey);
    EXPECT_EQ(iter->second.mValue, original[i].mValue);
    EXPECT_EQ(iter->second.DData, original[i].DData);
    EXPECT_EQ(iter->second.SData, original[i].SData);
  }

  std::vector<RegistryRecord> keyTree;
  keyTree.push_back(record0);
  keyTree.push_back(record1);
  keyTree.push_back(record2);
  keyTree.push_back(record3);
  keyTree.push_back(record4);
  for (std::size_t i = 0; i < keyTree.size(); ++i)
    setRegistryRecord(keyTree[i], HKEY_LOCAL_MACHINE);

  std::vector<std::wstring> keys;
  result = enumRegistryKeys(L"Software\\AAAKey0", keys, HKEY_LOCAL_MACHINE);
  EXPECT_NE(result, 0);
  EXPECT_EQ(keys.size(), 2);

  result = removeRegistryKey(L"Software", L"AAAKey0", HKEY_LOCAL_MACHINE);
  EXPECT_NE(result, 0);
  result = enumRegistryRecords(L"Software\\AAAKey0", recordsEnum, HKEY_LOCAL_MACHINE);
  EXPECT_EQ(result, 0);
}
#endif
