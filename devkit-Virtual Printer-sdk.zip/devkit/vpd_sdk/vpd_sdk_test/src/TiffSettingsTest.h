#pragma once
#include <gtest/gtest.h>

class TiffSettingsTest : public ::testing::Test{
public:
  virtual void SetUp(void){
  }

  virtual void TearDown(void){
  }

public:
};
