#include "ApplicationSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(ApplicationSettingsTest, ApplicationSettingsTest){
  std::wstring regKey = L"Software\\AAAAPPLICATIONTestSettings";
  vpd::ApplicationSettings settings;
  settings.mEnabled = 1;
  settings.mMessageId = 2;
  wcsncpy_s(settings.mPath, L"app path", vpd::ApplicationSettings::pathSize - 1);
  settings.mPipeLaunchApplication = 3;
  settings.mPipeMessageSize = 4;
  wcsncpy_s(settings.mPipeName, L"pipe name", vpd::ApplicationSettings::nameSize - 1);
  settings.mTimeout = 5;
  settings.mSkipMode = vpd::SkipModeNone;
  settings.mTransferMode = vpd::TransferModeCopydata;
  wcsncpy_s(settings.mWindowClass, L"window class", vpd::ApplicationSettings::nameSize - 1);
  wcsncpy_s(settings.mWindowTitle, L"window title", vpd::ApplicationSettings::nameSize - 1);

  // set settings for HKLM and HKCU hives
  int result = vpd::setApplicationSettings(vpd::ApplicationTypePostconverter, settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::ApplicationSettings readSettings;
  result = vpd::getApplicationSettings(vpd::ApplicationTypePostconverter, readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnabled, readSettings.mEnabled);
  EXPECT_EQ(settings.mMessageId, readSettings.mMessageId);
  EXPECT_STREQ(settings.mPath, readSettings.mPath);
  EXPECT_EQ(settings.mPipeLaunchApplication, readSettings.mPipeLaunchApplication);
  EXPECT_EQ(settings.mPipeMessageSize, readSettings.mPipeMessageSize);
  EXPECT_STREQ(settings.mPipeName, readSettings.mPipeName);
  EXPECT_EQ(settings.mTimeout, readSettings.mTimeout);
  EXPECT_EQ(settings.mSkipMode, readSettings.mSkipMode);
  EXPECT_EQ(settings.mTransferMode, readSettings.mTransferMode);
  EXPECT_STREQ(settings.mWindowClass, readSettings.mWindowClass);
  EXPECT_STREQ(settings.mWindowTitle, readSettings.mWindowTitle);

  // set settings for HKLM hive
  vpd::ApplicationSettings hklmSettings;
  hklmSettings.mEnabled = 11;
  hklmSettings.mMessageId = 12;
  wcsncpy_s(hklmSettings.mPath, L"app path1", vpd::ApplicationSettings::pathSize - 1);
  hklmSettings.mPipeLaunchApplication = 13;
  hklmSettings.mPipeMessageSize = 14;
  wcsncpy_s(hklmSettings.mPipeName, L"pipe name1", vpd::ApplicationSettings::nameSize - 1);
  hklmSettings.mTimeout = 15;
  hklmSettings.mSkipMode = vpd::SkipModeEmf;
  hklmSettings.mTransferMode = vpd::TransferModeCmd;
  wcsncpy_s(hklmSettings.mWindowClass, L"window class1", vpd::ApplicationSettings::nameSize - 1);
  wcsncpy_s(hklmSettings.mWindowTitle, L"window title1", vpd::ApplicationSettings::nameSize - 1);
  result = vpd::setApplicationSettings(vpd::ApplicationTypePostconverter, hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::ApplicationSettings readSettings1;
  result = vpd::getApplicationSettings(vpd::ApplicationTypePostconverter, readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnabled, readSettings1.mEnabled);
  EXPECT_EQ(settings.mMessageId, readSettings1.mMessageId);
  EXPECT_STREQ(settings.mPath, readSettings1.mPath);
  EXPECT_EQ(settings.mPipeLaunchApplication, readSettings1.mPipeLaunchApplication);
  EXPECT_EQ(settings.mPipeMessageSize, readSettings1.mPipeMessageSize);
  EXPECT_STREQ(settings.mPipeName, readSettings1.mPipeName);
  EXPECT_EQ(settings.mTimeout, readSettings1.mTimeout);
  EXPECT_EQ(settings.mSkipMode, readSettings1.mSkipMode);
  EXPECT_EQ(settings.mTransferMode, readSettings1.mTransferMode);
  EXPECT_STREQ(settings.mWindowClass, readSettings1.mWindowClass);
  EXPECT_STREQ(settings.mWindowTitle, readSettings1.mWindowTitle);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::ApplicationSettings readSettings2;
  result = vpd::getApplicationSettings(vpd::ApplicationTypePostconverter, readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnabled, readSettings2.mEnabled);
  EXPECT_EQ(hklmSettings.mMessageId, readSettings2.mMessageId);
  EXPECT_STREQ(hklmSettings.mPath, readSettings2.mPath);
  EXPECT_EQ(hklmSettings.mPipeLaunchApplication, readSettings2.mPipeLaunchApplication);
  EXPECT_EQ(hklmSettings.mPipeMessageSize, readSettings2.mPipeMessageSize);
  EXPECT_STREQ(hklmSettings.mPipeName, readSettings2.mPipeName);
  EXPECT_EQ(hklmSettings.mTimeout, readSettings2.mTimeout);
  EXPECT_EQ(hklmSettings.mSkipMode, readSettings2.mSkipMode);
  EXPECT_EQ(hklmSettings.mTransferMode, readSettings2.mTransferMode);
  EXPECT_STREQ(hklmSettings.mWindowClass, readSettings2.mWindowClass);
  EXPECT_STREQ(hklmSettings.mWindowTitle, readSettings2.mWindowTitle);

  // remove settings from HKCU hive
  result = vpd::removeApplicationSettings(vpd::ApplicationTypePostconverter, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::ApplicationSettings readSettings3;
  result = vpd::getApplicationSettings(vpd::ApplicationTypePostconverter, readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnabled, readSettings3.mEnabled);
  EXPECT_EQ(hklmSettings.mMessageId, readSettings3.mMessageId);
  EXPECT_STREQ(hklmSettings.mPath, readSettings3.mPath);
  EXPECT_EQ(hklmSettings.mPipeLaunchApplication, readSettings3.mPipeLaunchApplication);
  EXPECT_EQ(hklmSettings.mPipeMessageSize, readSettings3.mPipeMessageSize);
  EXPECT_STREQ(hklmSettings.mPipeName, readSettings3.mPipeName);
  EXPECT_EQ(hklmSettings.mTimeout, readSettings3.mTimeout);
  EXPECT_EQ(hklmSettings.mSkipMode, readSettings3.mSkipMode);
  EXPECT_EQ(hklmSettings.mTransferMode, readSettings3.mTransferMode);
  EXPECT_STREQ(hklmSettings.mWindowClass, readSettings3.mWindowClass);
  EXPECT_STREQ(hklmSettings.mWindowTitle, readSettings3.mWindowTitle);

  // remove settings from HKLM hive
  result = vpd::removeApplicationSettings(vpd::ApplicationTypePostconverter, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::ApplicationSettings readSettings4;
  result = vpd::getApplicationSettings(vpd::ApplicationTypePostconverter, readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
