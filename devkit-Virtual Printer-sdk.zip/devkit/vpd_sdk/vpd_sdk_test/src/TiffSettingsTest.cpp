#include "TiffSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(TiffSettingsTest, TiffSettingsTest){
  std::wstring regKey = L"Software\\AAATIFFTestSettings";
  vpd::TiffSettings settings;
  settings.mEnable = 1;
  settings.mBpp = vpd::ImageBpp8;
  settings.mCleanup = 1;
  settings.mDithering = vpd::ImageDitheringJarvisJudiceNinke;
  settings.mMultipage = 1;
  settings.mCompression = vpd::ImageCompressionCCITTHuffmanRLE;
  settings.mGrayscale = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setTiffSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::TiffSettings readSettings;
  result = vpd::getTiffSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBpp, readSettings.mBpp);
  EXPECT_EQ(settings.mCleanup, readSettings.mCleanup);
  EXPECT_EQ(settings.mDithering, readSettings.mDithering);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings.mGrayscale);
  EXPECT_EQ(settings.mCompression, readSettings.mCompression);
  EXPECT_EQ(settings.mMultipage, readSettings.mMultipage);

  // set settings for HKLM hive
  vpd::TiffSettings hklmSettings;
  hklmSettings.mEnable = 1;
  hklmSettings.mBpp = vpd::ImageBpp24;
  hklmSettings.mCleanup = 3;
  hklmSettings.mDithering = vpd::ImageDitheringOrderedDithering;
  hklmSettings.mMultipage = 5;
  hklmSettings.mCompression = vpd::ImageCompressionCCITTGroup3FaxEncoding;
  hklmSettings.mGrayscale = 4;
  result = vpd::setTiffSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::TiffSettings readSettings1;
  result = vpd::getTiffSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBpp, readSettings1.mBpp);
  EXPECT_EQ(settings.mCleanup, readSettings1.mCleanup);
  EXPECT_EQ(settings.mDithering, readSettings1.mDithering);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings1.mGrayscale);
  EXPECT_EQ(settings.mCompression, readSettings1.mCompression);
  EXPECT_EQ(settings.mMultipage, readSettings1.mMultipage);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::TiffSettings readSettings2;
  result = vpd::getTiffSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBpp, readSettings2.mBpp);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings2.mCleanup);
  EXPECT_EQ(hklmSettings.mDithering, readSettings2.mDithering);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings2.mGrayscale);
  EXPECT_EQ(hklmSettings.mCompression, readSettings2.mCompression);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings2.mMultipage);

  // remove settings from HKCU hive
  result = vpd::removeTiffSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::TiffSettings readSettings3;
  result = vpd::getTiffSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBpp, readSettings3.mBpp);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings3.mCleanup);
  EXPECT_EQ(hklmSettings.mDithering, readSettings3.mDithering);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings3.mGrayscale);
  EXPECT_EQ(hklmSettings.mCompression, readSettings3.mCompression);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings3.mMultipage);

  // remove settings from HKLM hive
  result = vpd::removeTiffSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::TiffSettings readSettings4;
  result = vpd::getTiffSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
