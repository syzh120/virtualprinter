#pragma once
#include <gtest/gtest.h>

class WatermarkSettingsTest : public ::testing::Test{
public:
  virtual void SetUp(void){
  }

  virtual void TearDown(void){
  }

public:
};
