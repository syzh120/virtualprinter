#include "PdfSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(PdfSettingsTest, PdfSettingsTest){
  std::wstring regKey = L"Software\\AAAPDFTestSettings";
  vpd::PdfSettings settings;
  settings.mEnable = 1;
  settings.mMultipage = 1;
  settings.mProducePdfA = 1;
  settings.mTimezone = vpd::TimezoneLocal;
  settings.mUseMthread = 1;
  settings.mPageLayout = vpd::PageLayoutOneColumn;
  settings.mPageMode = vpd::PageModeOutlines;
  settings.mSecured = 1;
  settings.mEnableUserPassword = 1;
  wcsncpy_s(settings.mUserPassword, L"User Password", vpd::PdfSettings::userPasswordSize - 1);
  settings.mEnableOwnerPassword = 1;
  wcsncpy_s(settings.mOwnerPassword, L"Owner Password", vpd::PdfSettings::ownerPasswordSize - 1);
  settings.mAllowCopying = 1;
  settings.mAllowCommenting = 1;
  settings.mAllowChanging = 1;
  settings.mAllowPrinting = 1;
  wcsncpy_s(settings.mTitle, L"Title", vpd::PdfSettings::titleSize - 1);
  wcsncpy_s(settings.mAuthor, L"Author", vpd::PdfSettings::authorSize -1);
  wcsncpy_s(settings.mProducer, L"Producer", vpd::PdfSettings::producerSize - 1);
  wcsncpy_s(settings.mCreator, L"Creator", vpd::PdfSettings::creatorSize - 1);
  wcsncpy_s(settings.mSubject, L"Subject", vpd::PdfSettings::subjectSize - 1);
  wcsncpy_s(settings.mKeywords, L"Keywords, keywords", vpd::PdfSettings::keywordsSize - 1);
  settings.mCleanup = 1;
  settings.mEncryptionLevel = vpd::EncryptionLevel128bitAES;
  settings.mUseDocumentName = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setPdfSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::PdfSettings readSettings;
  result = vpd::getPdfSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mMultipage, readSettings.mMultipage);
  EXPECT_EQ(settings.mProducePdfA, readSettings.mProducePdfA);
  EXPECT_EQ(settings.mTimezone, readSettings.mTimezone);
  EXPECT_EQ(settings.mUseMthread, readSettings.mUseMthread);
  EXPECT_EQ(settings.mPageLayout, readSettings.mPageLayout);
  EXPECT_EQ(settings.mPageMode, readSettings.mPageMode);
  EXPECT_EQ(settings.mSecured, readSettings.mSecured);
  EXPECT_EQ(settings.mEnableUserPassword, readSettings.mEnableUserPassword);
  EXPECT_STREQ(settings.mUserPassword, readSettings.mUserPassword); 
  EXPECT_EQ(settings.mEnableOwnerPassword, readSettings.mEnableOwnerPassword);
  EXPECT_STREQ(settings.mOwnerPassword, readSettings.mOwnerPassword);
  EXPECT_EQ(settings.mAllowCopying, readSettings.mAllowCopying);
  EXPECT_EQ(settings.mAllowCommenting, readSettings.mAllowCommenting);
  EXPECT_EQ(settings.mAllowChanging, readSettings.mAllowChanging);
  EXPECT_EQ(settings.mAllowPrinting, readSettings.mAllowPrinting);
  EXPECT_STREQ(settings.mTitle, readSettings.mTitle);
  EXPECT_STREQ(settings.mAuthor, readSettings.mAuthor);
  EXPECT_STREQ(settings.mProducer, readSettings.mProducer);
  EXPECT_STREQ(settings.mCreator, readSettings.mCreator);
  EXPECT_STREQ(settings.mSubject, readSettings.mSubject);
  EXPECT_STREQ(settings.mKeywords, readSettings.mKeywords);
  EXPECT_EQ(settings.mCleanup, readSettings.mCleanup);
  EXPECT_EQ(settings.mEncryptionLevel, readSettings.mEncryptionLevel);
  EXPECT_EQ(settings.mUseDocumentName, readSettings.mUseDocumentName);

  // set settings for HKLM hive
  vpd::PdfSettings hklmSettings;
  hklmSettings.mEnable = 1;
  hklmSettings.mMultipage = 0;
  hklmSettings.mProducePdfA = 0;
  hklmSettings.mTimezone = vpd::TimezoneUTC;
  hklmSettings.mUseMthread = 0;
  hklmSettings.mPageLayout = vpd::PageLayoutTwoColumnLeft;
  hklmSettings.mPageMode = vpd::PageModeThumbs;
  hklmSettings.mSecured = 0;
  hklmSettings.mEnableUserPassword = 1;
  wcsncpy_s(hklmSettings.mUserPassword, L"User Password1", vpd::PdfSettings::userPasswordSize - 1); 
  hklmSettings.mEnableOwnerPassword = 1;
  wcsncpy_s(hklmSettings.mOwnerPassword, L"Owner Password1", vpd::PdfSettings::ownerPasswordSize - 1);
  hklmSettings.mAllowCopying = 0;
  hklmSettings.mAllowCommenting = 1;
  hklmSettings.mAllowChanging = 1;
  hklmSettings.mAllowPrinting = 0;
  wcsncpy_s(hklmSettings.mTitle, L"Title1", vpd::PdfSettings::titleSize - 1);
  wcsncpy_s(hklmSettings.mAuthor, L"Author1", vpd::PdfSettings::authorSize - 1);
  wcsncpy_s(hklmSettings.mProducer, L"Producer1", vpd::PdfSettings::producerSize - 1);
  wcsncpy_s(hklmSettings.mCreator, L"Creator1", vpd::PdfSettings::creatorSize - 1);
  wcsncpy_s(hklmSettings.mSubject, L"Subject1", vpd::PdfSettings::subjectSize - 1);
  wcsncpy_s(hklmSettings.mKeywords, L"Keywords, keywords1", vpd::PdfSettings::keywordsSize - 1);
  hklmSettings.mCleanup = 0;
  hklmSettings.mEncryptionLevel = vpd::EncryptionLevel40bitRC4;
  hklmSettings.mUseDocumentName = 2;

  result = vpd::setPdfSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::PdfSettings readSettings1;
  result = vpd::getPdfSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mMultipage, readSettings1.mMultipage);
  EXPECT_EQ(settings.mProducePdfA, readSettings1.mProducePdfA);
  EXPECT_EQ(settings.mTimezone, readSettings1.mTimezone);
  EXPECT_EQ(settings.mUseMthread, readSettings1.mUseMthread);
  EXPECT_EQ(settings.mPageLayout, readSettings1.mPageLayout);
  EXPECT_EQ(settings.mPageMode, readSettings1.mPageMode);
  EXPECT_EQ(settings.mSecured, readSettings1.mSecured);
  EXPECT_EQ(settings.mEnableUserPassword, readSettings1.mEnableUserPassword);
  EXPECT_STREQ(settings.mUserPassword, readSettings1.mUserPassword); 
  EXPECT_EQ(settings.mEnableOwnerPassword, readSettings1.mEnableOwnerPassword);
  EXPECT_STREQ(settings.mOwnerPassword, readSettings1.mOwnerPassword);
  EXPECT_EQ(settings.mAllowCopying, readSettings1.mAllowCopying);
  EXPECT_EQ(settings.mAllowCommenting, readSettings1.mAllowCommenting);
  EXPECT_EQ(settings.mAllowChanging, readSettings1.mAllowChanging);
  EXPECT_EQ(settings.mAllowPrinting, readSettings1.mAllowPrinting);
  EXPECT_STREQ(settings.mTitle, readSettings1.mTitle);
  EXPECT_STREQ(settings.mAuthor, readSettings1.mAuthor);
  EXPECT_STREQ(settings.mProducer, readSettings1.mProducer);
  EXPECT_STREQ(settings.mCreator, readSettings1.mCreator);
  EXPECT_STREQ(settings.mSubject, readSettings1.mSubject);
  EXPECT_STREQ(settings.mKeywords, readSettings1.mKeywords);
  EXPECT_EQ(settings.mCleanup, readSettings1.mCleanup);
  EXPECT_EQ(settings.mEncryptionLevel, readSettings1.mEncryptionLevel);
  EXPECT_EQ(settings.mUseDocumentName, readSettings1.mUseDocumentName);


  // read settings from HKLM hive and compare with hklmSettings
  vpd::PdfSettings readSettings2;
  result = vpd::getPdfSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings2.mMultipage);
  EXPECT_EQ(hklmSettings.mProducePdfA, readSettings2.mProducePdfA);
  EXPECT_EQ(hklmSettings.mTimezone, readSettings2.mTimezone);
  EXPECT_EQ(hklmSettings.mUseMthread, readSettings2.mUseMthread);
  EXPECT_EQ(hklmSettings.mPageLayout, readSettings2.mPageLayout);
  EXPECT_EQ(hklmSettings.mPageMode, readSettings2.mPageMode);
  EXPECT_EQ(hklmSettings.mSecured, readSettings2.mSecured);
  EXPECT_EQ(hklmSettings.mEnableUserPassword, readSettings2.mEnableUserPassword);
  EXPECT_STREQ(hklmSettings.mUserPassword, readSettings2.mUserPassword); 
  EXPECT_EQ(hklmSettings.mEnableOwnerPassword, readSettings2.mEnableOwnerPassword);
  EXPECT_STREQ(hklmSettings.mOwnerPassword, readSettings2.mOwnerPassword);
  EXPECT_EQ(hklmSettings.mAllowCopying, readSettings2.mAllowCopying);
  EXPECT_EQ(hklmSettings.mAllowCommenting, readSettings2.mAllowCommenting);
  EXPECT_EQ(hklmSettings.mAllowChanging, readSettings2.mAllowChanging);
  EXPECT_EQ(hklmSettings.mAllowPrinting, readSettings2.mAllowPrinting);
  EXPECT_STREQ(hklmSettings.mTitle, readSettings2.mTitle);
  EXPECT_STREQ(hklmSettings.mAuthor, readSettings2.mAuthor);
  EXPECT_STREQ(hklmSettings.mProducer, readSettings2.mProducer);
  EXPECT_STREQ(hklmSettings.mCreator, readSettings2.mCreator);
  EXPECT_STREQ(hklmSettings.mSubject, readSettings2.mSubject);
  EXPECT_STREQ(hklmSettings.mKeywords, readSettings2.mKeywords);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings2.mCleanup);
  EXPECT_EQ(hklmSettings.mEncryptionLevel, readSettings2.mEncryptionLevel);
  EXPECT_EQ(hklmSettings.mUseDocumentName, readSettings2.mUseDocumentName);

  // remove settings from HKCU hive
  result = vpd::removePdfSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::PdfSettings readSettings3;
  result = vpd::getPdfSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings3.mMultipage);
  EXPECT_EQ(hklmSettings.mProducePdfA, readSettings3.mProducePdfA);
  EXPECT_EQ(hklmSettings.mTimezone, readSettings3.mTimezone);
  EXPECT_EQ(hklmSettings.mUseMthread, readSettings3.mUseMthread);
  EXPECT_EQ(hklmSettings.mPageLayout, readSettings3.mPageLayout);
  EXPECT_EQ(hklmSettings.mPageMode, readSettings3.mPageMode);
  EXPECT_EQ(hklmSettings.mSecured, readSettings3.mSecured);
  EXPECT_EQ(hklmSettings.mEnableUserPassword, readSettings3.mEnableUserPassword);
  EXPECT_STREQ(hklmSettings.mUserPassword, readSettings3.mUserPassword); 
  EXPECT_EQ(hklmSettings.mEnableOwnerPassword, readSettings3.mEnableOwnerPassword);
  EXPECT_STREQ(hklmSettings.mOwnerPassword, readSettings3.mOwnerPassword);
  EXPECT_EQ(hklmSettings.mAllowCopying, readSettings3.mAllowCopying);
  EXPECT_EQ(hklmSettings.mAllowCommenting, readSettings3.mAllowCommenting);
  EXPECT_EQ(hklmSettings.mAllowChanging, readSettings3.mAllowChanging);
  EXPECT_EQ(hklmSettings.mAllowPrinting, readSettings3.mAllowPrinting);
  EXPECT_STREQ(hklmSettings.mTitle, readSettings3.mTitle);
  EXPECT_STREQ(hklmSettings.mAuthor, readSettings3.mAuthor);
  EXPECT_STREQ(hklmSettings.mProducer, readSettings3.mProducer);
  EXPECT_STREQ(hklmSettings.mCreator, readSettings3.mCreator);
  EXPECT_STREQ(hklmSettings.mSubject, readSettings3.mSubject);
  EXPECT_STREQ(hklmSettings.mKeywords, readSettings3.mKeywords);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings3.mCleanup);
  EXPECT_EQ(hklmSettings.mEncryptionLevel, readSettings3.mEncryptionLevel);
  EXPECT_EQ(hklmSettings.mUseDocumentName, readSettings3.mUseDocumentName);

  // remove settings from HKLM hive
  result = vpd::removePdfSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::PdfSettings readSettings4;
  result = vpd::getPdfSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
