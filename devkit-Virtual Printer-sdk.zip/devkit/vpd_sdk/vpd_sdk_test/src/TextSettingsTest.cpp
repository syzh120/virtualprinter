#include "TextSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(TextSettingsTest, TextSettingsTest){
  std::wstring regKey = L"Software\\AAATextTestSettings";
  vpd::TextSettings settings;
  settings.mEnable = 1;
  settings.mMultipage = 1;
  settings.mEncoding = vpd::TextEncodingUTF8;
  settings.mWriteBOM = 1;
  settings.mSingleLineInterval = 1;
  settings.mDebug = 1;
  settings.mKeepFormatting = 1;
  settings.mDefaultBidirectionalAlgorithm = 1;
  settings.mCleanup = 1;
  settings.mSingleWordInterval = 2;

  // set settings for HKLM and HKCU hives
  int result = vpd::setTextSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::TextSettings readSettings;
  result = vpd::getTextSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mMultipage, readSettings.mMultipage);
  EXPECT_EQ(settings.mEncoding, readSettings.mEncoding);
  EXPECT_EQ(settings.mWriteBOM, readSettings.mWriteBOM);
  EXPECT_EQ(settings.mSingleLineInterval, readSettings.mSingleLineInterval);
  EXPECT_EQ(settings.mDebug, readSettings.mDebug);
  EXPECT_EQ(settings.mKeepFormatting, readSettings.mKeepFormatting);
  EXPECT_EQ(settings.mDefaultBidirectionalAlgorithm, readSettings.mDefaultBidirectionalAlgorithm);
  EXPECT_EQ(settings.mCleanup, readSettings.mCleanup);
  EXPECT_EQ(settings.mSingleWordInterval, readSettings.mSingleWordInterval);

  // set settings for HKLM hive
  vpd::TextSettings hklmSettings;
  hklmSettings.mEnable = 2;
  hklmSettings.mMultipage = 3;
  hklmSettings.mEncoding = vpd::TextEncodingANSI;
  hklmSettings.mWriteBOM = 2;
  hklmSettings.mSingleLineInterval = 5;
  hklmSettings.mDebug = 6;
  hklmSettings.mKeepFormatting = 7;
  hklmSettings.mDefaultBidirectionalAlgorithm = 8;
  hklmSettings.mCleanup = 2;
  hklmSettings.mSingleWordInterval = 3;
  result = vpd::setTextSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::TextSettings readSettings1;
  result = vpd::getTextSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mMultipage, readSettings1.mMultipage);
  EXPECT_EQ(settings.mEncoding, readSettings1.mEncoding);
  EXPECT_EQ(settings.mWriteBOM, readSettings1.mWriteBOM);
  EXPECT_EQ(settings.mSingleLineInterval, readSettings1.mSingleLineInterval);
  EXPECT_EQ(settings.mDebug, readSettings1.mDebug);
  EXPECT_EQ(settings.mKeepFormatting, readSettings1.mKeepFormatting);
  EXPECT_EQ(settings.mDefaultBidirectionalAlgorithm, readSettings1.mDefaultBidirectionalAlgorithm);
  EXPECT_EQ(settings.mCleanup, readSettings1.mCleanup);
  EXPECT_EQ(settings.mSingleWordInterval, readSettings1.mSingleWordInterval);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::TextSettings readSettings2;
  result = vpd::getTextSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings2.mMultipage);
  EXPECT_EQ(hklmSettings.mEncoding, readSettings2.mEncoding);
  EXPECT_EQ(hklmSettings.mWriteBOM, readSettings2.mWriteBOM);
  EXPECT_EQ(hklmSettings.mSingleLineInterval, readSettings2.mSingleLineInterval);
  EXPECT_EQ(hklmSettings.mDebug, readSettings2.mDebug);
  EXPECT_EQ(hklmSettings.mKeepFormatting, readSettings2.mKeepFormatting);
  EXPECT_EQ(hklmSettings.mDefaultBidirectionalAlgorithm, readSettings2.mDefaultBidirectionalAlgorithm);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings2.mCleanup);
  EXPECT_EQ(hklmSettings.mSingleWordInterval, readSettings2.mSingleWordInterval);

  // remove settings from HKCU hive
  result = vpd::removeTextSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::TextSettings readSettings3;
  result = vpd::getTextSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mMultipage, readSettings3.mMultipage);
  EXPECT_EQ(hklmSettings.mEncoding, readSettings3.mEncoding);
  EXPECT_EQ(hklmSettings.mWriteBOM, readSettings3.mWriteBOM);
  EXPECT_EQ(hklmSettings.mSingleLineInterval, readSettings3.mSingleLineInterval);
  EXPECT_EQ(hklmSettings.mDebug, readSettings3.mDebug);
  EXPECT_EQ(hklmSettings.mKeepFormatting, readSettings3.mKeepFormatting);
  EXPECT_EQ(hklmSettings.mDefaultBidirectionalAlgorithm, readSettings3.mDefaultBidirectionalAlgorithm);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings3.mCleanup);
  EXPECT_EQ(hklmSettings.mSingleWordInterval, readSettings3.mSingleWordInterval);

  // remove settings from HKLM hive
  result = vpd::removeTextSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::TextSettings readSettings4;
  result = vpd::getTextSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
