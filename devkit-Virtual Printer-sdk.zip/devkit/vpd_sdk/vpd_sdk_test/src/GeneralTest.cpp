#include "GeneralTest.h"
#include <vpd_sdk.h>

TEST_F(GeneralTest, PaperOrientationTest){

  vpd::PaperOrientation orientation = vpd::PaperOrientationLandscape;
  EXPECT_NE(vpd::setPaperOrientation(mPname, orientation), 0);
  vpd::PaperOrientation result;
  EXPECT_NE(vpd::getPaperOrientation(mPname, result), 0);
  EXPECT_EQ(result, orientation);

  orientation = vpd::PaperOrientationPortrait;
  vpd::setPaperOrientation(mPname, orientation);
  EXPECT_NE(vpd::getPaperOrientation(mPname, result), 0);
  EXPECT_EQ(result, orientation);
}

TEST_F(GeneralTest, PrintResolutionTest){

  vpd::PrintResolution *resolutions = 0;
  std::size_t size = 0;
  int result = vpd::enumPrintResolutions(mPname, resolutions, size);
  EXPECT_NE(result, 0);
  EXPECT_NE(size, 0);

  vpd::PrintResolution resolution;  
  for (std::size_t i = 0; i < size; ++i){
    result = vpd::setPrintResolution(mPname, resolutions[i]);
    EXPECT_NE(result, 0);

    result = vpd::getPrintResolution(mPname, resolution);
    EXPECT_NE(result, 0);

    EXPECT_EQ(resolutions[i].mDpiX, resolution.mDpiX);
    EXPECT_EQ(resolutions[i].mDpiY, resolution.mDpiY);
  }

  vpd::release(resolutions);
}

#if 1
TEST_F(GeneralTest, PaperFormTest){
  vpd::AutoReleasePtr<vpd::PaperForm> forms(0);
  std::size_t size = 0;
  int result = vpd::enumPaperForms(mPname, forms.getRef(), size, vpd::PaperSizeMeasureMetrics);
  EXPECT_NE(result, 0);
  EXPECT_NE(size, 0);

  vpd::PaperForm form;
  for (std::size_t i = 0; i < size; ++i){
    result = vpd::setPaperForm(mPname, forms[i]);
    EXPECT_NE(result, 0);

    result = vpd::getPaperForm(mPname, form);
    EXPECT_NE(result, 0);

    EXPECT_STREQ(form.mName, forms[i].mName);
    EXPECT_EQ(form.mMeasure, forms[i].mMeasure);
    EXPECT_EQ(form.mHeight, forms[i].mHeight);
    EXPECT_EQ(form.mWidth, forms[i].mWidth);
  }

  //vpd::release(forms);
  //forms = 0;
  size = 0;

  vpd::PaperForm testForm;
  wcsncpy_s(testForm.mName, L"test form 1234 x 1234 mm", vpd::PaperForm::paperFormSize - 1);
  testForm.mWidth = testForm.mHeight = 1234.0f;
  testForm.mMeasure = vpd::PaperSizeMeasureMetrics;
  testForm.mPrecision = vpd::PaperSizePrecisionNormal;
  result = vpd::addPaperForm(mPname, testForm);
  EXPECT_NE(result, 0);
  DWORD error = GetLastError();

  result = vpd::setPaperForm(mPname, testForm);
  EXPECT_NE(result, 0);

  result = vpd::getPaperForm(mPname, form);
  EXPECT_NE(result, 0);
  EXPECT_STREQ(form.mName, testForm.mName);
  EXPECT_EQ(form.mMeasure, testForm.mMeasure);
  EXPECT_EQ(form.mHeight, testForm.mHeight);
  EXPECT_EQ(form.mWidth, testForm.mWidth);

  result = vpd::removePaperForm(mPname, testForm);
  EXPECT_NE(result, 0);

  forms.release();
  result = vpd::enumPaperForms(mPname, forms.getRef(), size);
  EXPECT_NE(result, 0);
  for (std::size_t i = 0; i < size; ++i)
    EXPECT_NE(testForm.mName, forms[i].mName);
  //vpd::release(forms);
}
#endif

TEST_F(GeneralTest, BinNameTest){
  vpd::PaperBin *bins = 0;
  std::size_t size = 0;
  int result = vpd::enumPaperBins(mPname, bins, size);
  EXPECT_NE(result, 0);
  EXPECT_NE(size, 0);

  WORD bin;
  for (std::size_t i = 0; i < size; ++i){
    result = vpd::setPaperBin(mPname, bins[i].mBin);
    EXPECT_NE(result, 0);

    result = vpd::getPaperBin(mPname, bin);
    EXPECT_NE(result, 0);
    EXPECT_EQ(bin, bins[i].mBin);
  }

  vpd::release(bins);
}
