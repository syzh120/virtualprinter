#include "JpegSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(JpegSettingsTest, JpegSettingsTest){
  std::wstring regKey = L"Software\\AAAJPEGTestSettings";
  vpd::JpegSettings settings;
  settings.mEnable = 1;
  settings.mCleanup = 1;
  settings.mQuality = 80;
  settings.mGrayscale = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setJpegSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::JpegSettings readSettings;
  result = vpd::getJpegSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mCleanup, readSettings.mCleanup);
  EXPECT_EQ(settings.mQuality, readSettings.mQuality);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings.mGrayscale);

  // set settings for HKLM hive
  vpd::JpegSettings hklmSettings;
  hklmSettings.mEnable = 2;
  hklmSettings.mCleanup = 3;
  hklmSettings.mQuality = 60;
  hklmSettings.mGrayscale = 4;
  result = vpd::setJpegSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::JpegSettings readSettings1;
  result = vpd::getJpegSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mCleanup, readSettings1.mCleanup);
  EXPECT_EQ(settings.mQuality, readSettings1.mQuality);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings1.mGrayscale);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::JpegSettings readSettings2;
  result = vpd::getJpegSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings2.mCleanup);
  EXPECT_EQ(hklmSettings.mQuality, readSettings2.mQuality);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings2.mGrayscale);

  // remove settings from HKCU hive
  result = vpd::removeJpegSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::JpegSettings readSettings3;
  result = vpd::getJpegSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings3.mCleanup);
  EXPECT_EQ(hklmSettings.mQuality, readSettings3.mQuality);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings3.mGrayscale);

  // remove settings from HKLM hive
  result = vpd::removeJpegSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::JpegSettings readSettings4;
  result = vpd::getJpegSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
