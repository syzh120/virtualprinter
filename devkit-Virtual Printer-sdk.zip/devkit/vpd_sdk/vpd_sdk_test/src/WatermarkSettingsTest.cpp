#include "WatermarkSettingsTest.h"
#include <vpd_sdk.h>

TEST_F(WatermarkSettingsTest, ImageWatermarkSettingsTest){
  std::wstring regKey = L"Software\\AAAWATERMARKImgTestSettings";

  std::wstring wtmId0 = L"wtmId0";
  std::wstring wtmId1 = L"wtmId1";
  std::wstring wtmId2 = L"wtmId2";

  vpd::ImageWatermarkInfo wtm0(wtmId0, L"c:/tmp/img0", 1, 2, 3, 4, vpd::FillModeNone, vpd::PosModeLB);
  vpd::ImageWatermarkInfo wtm1(wtmId1, L"c:/tmp/img1", 3, 4, 5, 6, vpd::FillModeFill, vpd::PosModeLT);
  vpd::ImageWatermarkInfo wtm2(wtmId2, L"c:/tmp/img2", 0, 0, 0, 0, vpd::FillModeCenter, vpd::PosModeC);
  vpd::TextWatermarkInfo textWtm(L"textWtm", L"textMessage2", 0, 0, 0, 0, vpd::PosModeC, vpd::HorizontalAlignmentRight, vpd::VerticalAlignmentTop, 231, L"New Font", 23, 32, 44);
  EXPECT_NE(vpd::addTextWatermark(L"textWtm", textWtm, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);
  
  EXPECT_NE(vpd::addImageWatermark(wtmId0, wtm0, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_NE(vpd::addImageWatermark(wtmId1, wtm1, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_NE(vpd::addImageWatermark(wtmId2, wtm2, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);

  vpd::ImageWatermarkInfo wtm;
  EXPECT_NE(vpd::getImageWatermark(wtmId0, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtm, wtm0);

  EXPECT_NE(vpd::getImageWatermark(wtmId1, wtm, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtm, wtm1);

  EXPECT_NE(vpd::getImageWatermark(wtmId2, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtm, wtm2);

  EXPECT_NE(vpd::getImageWatermark(wtmId2, wtm, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtm, wtm2);

  vpd::ImageWatermarkInfo *wtms = 0;
  std::size_t wtmsCount = 0;
  EXPECT_NE(vpd::enumImageWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtmsCount, 2);
  vpd::release(wtms);
  
  EXPECT_NE(vpd::enumImageWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtmsCount, 2);
  vpd::release(wtms);

  EXPECT_NE(vpd::enumImageWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtmsCount, 4);
  vpd::release(wtms);

  EXPECT_NE(vpd::removeWatermark(wtmId0, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(vpd::getImageWatermark(wtmId0, wtm, vpd::REGISTRY_HKCU, regKey), 0);

  EXPECT_NE(vpd::removeWatermark(wtmId1, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(vpd::getImageWatermark(wtmId1, wtm, vpd::REGISTRY_HKCU, regKey), 0);

  EXPECT_NE(vpd::removeWatermark(wtmId2, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(vpd::getImageWatermark(wtmId2, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(vpd::getImageWatermark(wtmId2, wtm, vpd::REGISTRY_HKLM, regKey), 0);
}

TEST_F(WatermarkSettingsTest, TextWatermarkSettingsTest){
  std::wstring regKey = L"Software\\AAAWATERMARKTxtTestSettings";

  std::wstring wtmId0 = L"wtmId0";
  std::wstring wtmId1 = L"wtmId1";
  std::wstring wtmId2 = L"wtmId2";

  vpd::TextWatermarkInfo wtm0(wtmId0, L"textMessage0", 1, 2, 3, 4, vpd::PosModeLB, vpd::HorizontalAlignmentCenter, vpd::VerticalAlignmentCenter, 123, L"Arial", 10, 20, 30);
  vpd::TextWatermarkInfo wtm1(wtmId1, L"textMessage1", 3, 4, 5, 6, vpd::PosModeLT, vpd::HorizontalAlignmentLeft, vpd::VerticalAlignmentCenter, 324, L"Courier", 11, 22, 33);
  vpd::TextWatermarkInfo wtm2(wtmId2, L"textMessage2", 0, 0, 0, 0, vpd::PosModeC, vpd::HorizontalAlignmentRight, vpd::VerticalAlignmentTop, 231, L"New Font", 23, 32, 44);
  vpd::ImageWatermarkInfo imageWtm(L"imageWtm", L"c:/tmp/img0", 1, 2, 3, 4, vpd::FillModeNone, vpd::PosModeLB);
  EXPECT_NE(vpd::addImageWatermark(L"imageWtm", imageWtm, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);

  EXPECT_NE(vpd::addTextWatermark(wtmId0, wtm0, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_NE(vpd::addTextWatermark(wtmId1, wtm1, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_NE(vpd::addTextWatermark(wtmId2, wtm2, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);

  vpd::TextWatermarkInfo wtm;
  EXPECT_NE(vpd::getTextWatermark(wtmId0, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtm, wtm0);

  EXPECT_NE(vpd::getTextWatermark(wtmId1, wtm, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtm, wtm1);

  EXPECT_NE(vpd::getTextWatermark(wtmId2, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtm, wtm2);

  EXPECT_NE(vpd::getTextWatermark(wtmId2, wtm, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtm, wtm2);

  vpd::TextWatermarkInfo *wtms = 0;
  std::size_t wtmsCount = 0;
  EXPECT_NE(vpd::enumTextWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(wtmsCount, 2);
  vpd::release(wtms);
  
  EXPECT_NE(vpd::enumTextWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtmsCount, 2);
  vpd::release(wtms);

  EXPECT_NE(vpd::enumTextWatermarks(wtms, wtmsCount, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(wtmsCount, 4);
  vpd::release(wtms);

  EXPECT_NE(vpd::removeWatermark(wtmId0, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(vpd::getTextWatermark(wtmId0, wtm, vpd::REGISTRY_HKCU, regKey), 0);

  EXPECT_NE(vpd::removeWatermark(wtmId1, vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(vpd::getTextWatermark(wtmId1, wtm, vpd::REGISTRY_HKCU, regKey), 0);

  EXPECT_NE(vpd::removeWatermark(wtmId2, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey), 0);
  EXPECT_EQ(vpd::getTextWatermark(wtmId2, wtm, vpd::REGISTRY_HKCU, regKey), 0);
  EXPECT_EQ(vpd::getTextWatermark(wtmId2, wtm, vpd::REGISTRY_HKLM, regKey), 0);
}
