#include "ConverterSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(ConverterSettingsTest, ConverterSettingsTest){
  std::wstring regKey = L"Software\\AAACONVERTERTestSettings";
  vpd::ConverterSettings settings;
  settings.mShowProgressBar = 1;
  settings.mThreads = 2;
  wcsncpy_s(settings.mOutputDir, L"output", vpd::ConverterSettings::directorySize - 1);
  settings.mCleanupOutput = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setConverterSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::ConverterSettings readSettings;
  result = vpd::getConverterSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mShowProgressBar, readSettings.mShowProgressBar);
  EXPECT_EQ(settings.mThreads, readSettings.mThreads);
  EXPECT_STREQ(settings.mOutputDir, readSettings.mOutputDir);

  // set settings for HKLM hive
  vpd::ConverterSettings hklmSettings;
  hklmSettings.mShowProgressBar = 4;
  hklmSettings.mThreads = 3;
  wcsncpy_s(hklmSettings.mOutputDir, L"output1", vpd::ConverterSettings::directorySize - 1);
  hklmSettings.mCleanupOutput = 3;
  result = vpd::setConverterSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::ConverterSettings readSettings1;
  result = vpd::getConverterSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mShowProgressBar, readSettings1.mShowProgressBar);
  EXPECT_EQ(settings.mThreads, readSettings1.mThreads);
  EXPECT_STREQ(settings.mOutputDir, readSettings1.mOutputDir);
  EXPECT_EQ(settings.mCleanupOutput, readSettings1.mCleanupOutput);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::ConverterSettings readSettings2;
  result = vpd::getConverterSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mShowProgressBar, readSettings2.mShowProgressBar);
  EXPECT_EQ(hklmSettings.mThreads, readSettings2.mThreads);
  EXPECT_STREQ(hklmSettings.mOutputDir, readSettings2.mOutputDir);
  EXPECT_EQ(hklmSettings.mCleanupOutput, readSettings2.mCleanupOutput);

  // remove settings from HKCU hive
  result = vpd::removeConverterSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::ConverterSettings readSettings3;
  result = vpd::getConverterSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mShowProgressBar, readSettings3.mShowProgressBar);
  EXPECT_EQ(hklmSettings.mThreads, readSettings3.mThreads);
  EXPECT_STREQ(hklmSettings.mOutputDir, readSettings3.mOutputDir);
  EXPECT_EQ(hklmSettings.mCleanupOutput, readSettings3.mCleanupOutput);

  // remove settings from HKLM hive
  result = vpd::removeConverterSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::ConverterSettings readSettings4;
  result = vpd::getConverterSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 1);
}
#endif
