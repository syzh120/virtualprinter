#include "PosSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(PosSettingsTest, PosSettingsTest){
  std::wstring regKey = L"Software\\AAAPOSTestSettings";
  vpd::PosSettings settings;
  settings.mEnable = 1;
  wcsncpy_s(settings.mFontA, L"fontA", vpd::PosSettings::fontNameSize - 1);
  settings.mFontASize = 12;
  wcsncpy_s(settings.mFontB, L"fontB", vpd::PosSettings::fontNameSize - 1);
  settings.mFontBSize = 23;
  /*settings.mSingleFile = 1 */;
  settings.mSkipHeader = 32;

  // set settings for HKLM and HKCU hives
  int result = vpd::setPosSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::PosSettings readSettings;
  result = vpd::getPosSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_STREQ(settings.mFontA, readSettings.mFontA);
  EXPECT_EQ(settings.mFontASize, readSettings.mFontASize);
  EXPECT_STREQ(settings.mFontB, readSettings.mFontB);
  EXPECT_EQ(settings.mFontBSize, readSettings.mFontBSize);
  //EXPECT_EQ(settings.mSingleFile, readSettings.mSingleFile);
  EXPECT_EQ(settings.mSkipHeader, readSettings.mSkipHeader);

  // set settings for HKLM hive
  vpd::PosSettings hklmSettings;
  hklmSettings.mEnable = 2;
  wcsncpy_s(hklmSettings.mFontA, L"fontA1", vpd::PosSettings::fontNameSize - 1);
  hklmSettings.mFontASize = 123;
  wcsncpy_s(hklmSettings.mFontB, L"fontB1", vpd::PosSettings::fontNameSize - 1);
  hklmSettings.mFontBSize = 231;
  //hklmSettings.mSingleFile = 12;
  hklmSettings.mSkipHeader = 332;
  result = vpd::setPosSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::PosSettings readSettings1;
  result = vpd::getPosSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_STREQ(settings.mFontA, readSettings1.mFontA);
  EXPECT_EQ(settings.mFontASize, readSettings1.mFontASize);
  EXPECT_STREQ(settings.mFontB, readSettings1.mFontB);
  EXPECT_EQ(settings.mFontBSize, readSettings1.mFontBSize);
  //EXPECT_EQ(settings.mSingleFile, readSettings1.mSingleFile);
  EXPECT_EQ(settings.mSkipHeader, readSettings1.mSkipHeader);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::PosSettings readSettings2;
  result = vpd::getPosSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_STREQ(hklmSettings.mFontA, readSettings2.mFontA);
  EXPECT_EQ(hklmSettings.mFontASize, readSettings2.mFontASize);
  EXPECT_STREQ(hklmSettings.mFontB, readSettings2.mFontB);
  EXPECT_EQ(hklmSettings.mFontBSize, readSettings2.mFontBSize);
  //EXPECT_EQ(hklmSettings.mSingleFile, readSettings2.mSingleFile);
  EXPECT_EQ(hklmSettings.mSkipHeader, readSettings2.mSkipHeader);

  // remove settings from HKCU hive
  result = vpd::removePosSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::PosSettings readSettings3;
  result = vpd::getPosSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_STREQ(hklmSettings.mFontA, readSettings3.mFontA);
  EXPECT_EQ(hklmSettings.mFontASize, readSettings3.mFontASize);
  EXPECT_STREQ(hklmSettings.mFontB, readSettings3.mFontB);
  EXPECT_EQ(hklmSettings.mFontBSize, readSettings3.mFontBSize);
  //EXPECT_EQ(hklmSettings.mSingleFile, readSettings3.mSingleFile);
  EXPECT_EQ(hklmSettings.mSkipHeader, readSettings3.mSkipHeader);

  // remove settings from HKLM hive
  result = vpd::removePosSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::PosSettings readSettings4;
  result = vpd::getPosSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
