#include "BmpSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(BmpSettingsTest, BmpSettingsTest){
  std::wstring regKey = L"Software\\AAABMPTestSettings";
  vpd::BmpSettings settings;
  settings.mEnable = 1;
  settings.mBpp = vpd::ImageBpp8;
  settings.mCleanup = 1;
  settings.mDithering = vpd::ImageDitheringJarvisJudiceNinke;
  settings.mGrayscale = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setBmpSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::BmpSettings readSettings;
  result = vpd::getBmpSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBpp, readSettings.mBpp);
  EXPECT_EQ(settings.mCleanup, readSettings.mCleanup);
  EXPECT_EQ(settings.mDithering, readSettings.mDithering);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings.mGrayscale);

  // set settings for HKLM hive
  vpd::BmpSettings hklmSettings;
  hklmSettings.mEnable = 2;
  hklmSettings.mBpp = vpd::ImageBpp24;
  hklmSettings.mCleanup = 2;
  hklmSettings.mDithering = vpd::ImageDitheringBurkes;
  hklmSettings.mGrayscale = 3;
  result = vpd::setBmpSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::BmpSettings readSettings1;
  result = vpd::getBmpSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBpp, readSettings1.mBpp);
  EXPECT_EQ(settings.mCleanup, readSettings1.mCleanup);
  EXPECT_EQ(settings.mDithering, readSettings1.mDithering);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mGrayscale, readSettings1.mGrayscale);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::BmpSettings readSettings2;
  result = vpd::getBmpSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBpp, readSettings2.mBpp);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings2.mCleanup);
  EXPECT_EQ(hklmSettings.mDithering, readSettings2.mDithering);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings2.mGrayscale);

  // remove settings from HKCU hive
  result = vpd::removeBmpSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::BmpSettings readSettings3;
  result = vpd::getBmpSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBpp, readSettings3.mBpp);
  EXPECT_EQ(hklmSettings.mCleanup, readSettings3.mCleanup);
  EXPECT_EQ(hklmSettings.mDithering, readSettings3.mDithering);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mGrayscale, readSettings3.mGrayscale);

  // remove settings from HKLM hive
  result = vpd::removeBmpSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::BmpSettings readSettings4;
  result = vpd::getBmpSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
