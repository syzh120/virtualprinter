#include "PrinterTest.h"
#include <vpd_sdk.h>

TEST_F(PrinterTest, EnumPrinterTest){
  vpd::AutoReleasePtr<vpd::PrinterInfo> printers(0);
  std::size_t count = 0;
  int result = vpd::enumPrinters(vpd::PrinterLocationLocal, printers.getRef(), count);
  EXPECT_NE(result, 0);
  DWORD error = GetLastError();
}
