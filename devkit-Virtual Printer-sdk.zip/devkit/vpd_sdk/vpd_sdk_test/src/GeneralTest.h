#pragma once
#include <gtest/gtest.h>

class GeneralTest : public ::testing::Test{
public:
  virtual void SetUp(void){
    mPname = L"Two Pilots Demo Printer";
  }

  virtual void TearDown(void){
  }

public:
  std::wstring mPname;
};
