#pragma once
#include <gtest/gtest.h>

class ApplicationSettingsTest : public ::testing::Test{
public:
  virtual void SetUp(void){
  }

  virtual void TearDown(void){
  }

public:
};
