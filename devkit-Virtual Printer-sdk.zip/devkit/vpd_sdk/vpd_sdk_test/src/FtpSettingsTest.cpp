#include "FtpSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(FtpSettingsTest, FtpSettingsTest){
  std::wstring regKey = L"Software\\AAAFTPTestSettings";
  vpd::FtpSettings settings;
  settings.mEnable = 1;
  settings.mAttempts = 1;
  settings.mEncrypted = 1;
  wcsncpy_s(settings.mPassword, L"password", vpd::FtpSettings::passwordSize - 1);
  wcsncpy_s(settings.mUploadConfig, L"asdf", vpd::FtpSettings::uploadConfigSize - 1);
  wcsncpy_s(settings.mUrl, L"url", vpd::FtpSettings::urlSize - 1);
  wcsncpy_s(settings.mUserName, L"username", vpd::FtpSettings::userNameSize - 1);

  // set settings for HKLM and HKCU hives
  int result = vpd::setFtpSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::FtpSettings readSettings;
  result = vpd::getFtpSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mAttempts, readSettings.mAttempts);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mEncrypted, readSettings.mEncrypted);
  EXPECT_STREQ(settings.mPassword, readSettings.mPassword);
  EXPECT_STREQ(settings.mUploadConfig, readSettings.mUploadConfig);
  EXPECT_STREQ(settings.mUrl, readSettings.mUrl);
  EXPECT_STREQ(settings.mUserName, readSettings.mUserName);

  // set settings for HKLM hive
  vpd::FtpSettings hklmSettings;
  hklmSettings.mEnable = 2;
  hklmSettings.mAttempts = 3;
  hklmSettings.mEncrypted = 4;
  wcsncpy_s(hklmSettings.mPassword, L"132password", vpd::FtpSettings::passwordSize - 1);
  wcsncpy_s(hklmSettings.mUploadConfig, L"234asdf", vpd::FtpSettings::uploadConfigSize - 1);
  wcsncpy_s(hklmSettings.mUrl, L"324url", vpd::FtpSettings::urlSize - 1);
  wcsncpy_s(hklmSettings.mUserName, L"1324username", vpd::FtpSettings::userNameSize - 1);
  result = vpd::setFtpSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::FtpSettings readSettings1;
  result = vpd::getFtpSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mAttempts, readSettings1.mAttempts);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mEncrypted, readSettings1.mEncrypted);
  EXPECT_STREQ(settings.mPassword, readSettings1.mPassword);
  EXPECT_STREQ(settings.mUploadConfig, readSettings1.mUploadConfig);
  EXPECT_STREQ(settings.mUrl, readSettings1.mUrl);
  EXPECT_STREQ(settings.mUserName, readSettings1.mUserName);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::FtpSettings readSettings2;
  result = vpd::getFtpSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mAttempts, readSettings2.mAttempts);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mEncrypted, readSettings2.mEncrypted);
  EXPECT_STREQ(hklmSettings.mPassword, readSettings2.mPassword);
  EXPECT_STREQ(hklmSettings.mUploadConfig, readSettings2.mUploadConfig);
  EXPECT_STREQ(hklmSettings.mUrl, readSettings2.mUrl);
  EXPECT_STREQ(hklmSettings.mUserName, readSettings2.mUserName);

  // remove settings from HKCU hive
  result = vpd::removeFtpSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::FtpSettings readSettings3;
  result = vpd::getFtpSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mAttempts, readSettings3.mAttempts);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mEncrypted, readSettings3.mEncrypted);
  EXPECT_STREQ(hklmSettings.mPassword, readSettings3.mPassword);
  EXPECT_STREQ(hklmSettings.mUploadConfig, readSettings3.mUploadConfig);
  EXPECT_STREQ(hklmSettings.mUrl, readSettings3.mUrl);
  EXPECT_STREQ(hklmSettings.mUserName, readSettings3.mUserName);

  // remove settings from HKLM hive
  result = vpd::removeFtpSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::FtpSettings readSettings4;
  result = vpd::getFtpSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
