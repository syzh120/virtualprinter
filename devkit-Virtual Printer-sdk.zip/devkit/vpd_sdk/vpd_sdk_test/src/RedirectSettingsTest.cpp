#include "RedirectSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(RedirectSettingsTest, RedirectSettingsTest){
  std::wstring regKey = L"Software\\AAAREDIRECT TestSettings";
  vpd::RedirectSettings settings;
  settings.mEnable = 1;
  settings.mBottomCorrection = 1;
  settings.mLeftCorrection = 2;
  wcsncpy_s(settings.mPrinter, L"printer0", vpd::RedirectSettings::printerNameSize - 1);
  settings.mRedirectSpool = 1;
  settings.mRedirectWatermarks = 1;
  settings.mRightCorrection = 2;
  settings.mTopCorrection = 3;

  // set settings for HKLM and HKCU hives
  int result = vpd::setRedirectSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::RedirectSettings readSettings;
  result = vpd::getRedirectSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBottomCorrection, readSettings.mBottomCorrection);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);
  EXPECT_EQ(settings.mLeftCorrection, readSettings.mLeftCorrection);
  EXPECT_STREQ(settings.mPrinter, readSettings.mPrinter);
  EXPECT_EQ(settings.mRedirectSpool, readSettings.mRedirectSpool);
  EXPECT_EQ(settings.mRedirectWatermarks, readSettings.mRedirectWatermarks);
  EXPECT_EQ(settings.mRightCorrection, readSettings.mRightCorrection);
  EXPECT_EQ(settings.mTopCorrection, readSettings.mTopCorrection);

  // set settings for HKLM hive
  vpd::RedirectSettings hklmSettings;
  hklmSettings.mEnable = 2;
  hklmSettings.mBottomCorrection = 3;
  hklmSettings.mLeftCorrection = 4;
  wcsncpy_s(hklmSettings.mPrinter, L"printer1", vpd::RedirectSettings::printerNameSize - 1);
  hklmSettings.mRedirectSpool = 5;
  hklmSettings.mRedirectWatermarks = 6;
  hklmSettings.mRightCorrection = 7;
  hklmSettings.mTopCorrection = 8;

  result = vpd::setRedirectSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::RedirectSettings readSettings1;
  result = vpd::getRedirectSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mBottomCorrection, readSettings1.mBottomCorrection);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);
  EXPECT_EQ(settings.mLeftCorrection, readSettings1.mLeftCorrection);
  EXPECT_STREQ(settings.mPrinter, readSettings1.mPrinter);
  EXPECT_EQ(settings.mRedirectSpool, readSettings1.mRedirectSpool);
  EXPECT_EQ(settings.mRedirectWatermarks, readSettings1.mRedirectWatermarks);
  EXPECT_EQ(settings.mRightCorrection, readSettings1.mRightCorrection);
  EXPECT_EQ(settings.mTopCorrection, readSettings1.mTopCorrection);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::RedirectSettings readSettings2;
  result = vpd::getRedirectSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBottomCorrection, readSettings2.mBottomCorrection);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);
  EXPECT_EQ(hklmSettings.mLeftCorrection, readSettings2.mLeftCorrection);
  EXPECT_STREQ(hklmSettings.mPrinter, readSettings2.mPrinter);
  EXPECT_EQ(hklmSettings.mRedirectSpool, readSettings2.mRedirectSpool);
  EXPECT_EQ(hklmSettings.mRedirectWatermarks, readSettings2.mRedirectWatermarks);
  EXPECT_EQ(hklmSettings.mRightCorrection, readSettings2.mRightCorrection);
  EXPECT_EQ(hklmSettings.mTopCorrection, readSettings2.mTopCorrection);

  // remove settings from HKCU hive
  result = vpd::removeRedirectSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::RedirectSettings readSettings3;
  result = vpd::getRedirectSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mBottomCorrection, readSettings3.mBottomCorrection);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);
  EXPECT_EQ(hklmSettings.mLeftCorrection, readSettings3.mLeftCorrection);
  EXPECT_STREQ(hklmSettings.mPrinter, readSettings3.mPrinter);
  EXPECT_EQ(hklmSettings.mRedirectSpool, readSettings3.mRedirectSpool);
  EXPECT_EQ(hklmSettings.mRedirectWatermarks, readSettings3.mRedirectWatermarks);
  EXPECT_EQ(hklmSettings.mRightCorrection, readSettings3.mRightCorrection);
  EXPECT_EQ(hklmSettings.mTopCorrection, readSettings3.mTopCorrection);

  // remove settings from HKLM hive
  result = vpd::removeRedirectSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::RedirectSettings readSettings4;
  result = vpd::getRedirectSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
