#include "RawSettingsTest.h"
#include <vpd_sdk.h>

#if 1
TEST_F(RawSettingsTest, RawSettingsTest){
  std::wstring regKey = L"Software\\AAARAWTestSettings";
  vpd::RawSettings settings;
  settings.mEnable = 1;

  // set settings for HKLM and HKCU hives
  int result = vpd::setRawSettings(settings, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU and compare with original settings
  vpd::RawSettings readSettings;
  readSettings.mEnable = 0;
  result = vpd::getRawSettings(readSettings, vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings.mEnable);

  // set settings for HKLM hive
  vpd::RawSettings hklmSettings;
  result = vpd::setRawSettings(hklmSettings, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hive and compare with original settings
  vpd::RawSettings readSettings1;
  result = vpd::getRawSettings(readSettings1, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(settings.mEnable, readSettings1.mEnable);

  // read settings from HKLM hive and compare with hklmSettings
  vpd::RawSettings readSettings2;
  result = vpd::getRawSettings(readSettings2, vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings2.mEnable);

  // remove settings from HKCU hive
  result = vpd::removeRawSettings(vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);

  // read settings from HKCU | HKLM hives and compare with hklmSettings
  vpd::RawSettings readSettings3;
  result = vpd::getRawSettings(readSettings3, vpd::REGISTRY_HKLM | vpd::REGISTRY_HKCU, regKey);
  EXPECT_NE(result, 0);
  EXPECT_EQ(hklmSettings.mEnable, readSettings3.mEnable);

  // remove settings from HKLM hive
  result = vpd::removeRawSettings(vpd::REGISTRY_HKLM, regKey);
  EXPECT_NE(result, 0);

  // read settins from HKLM | HKCU hives and it should be failed
  vpd::RawSettings readSettings4;
  result = vpd::getRawSettings(readSettings4, vpd::REGISTRY_HKCU | vpd::REGISTRY_HKLM, regKey);
  EXPECT_EQ(result, 0);
}
#endif
